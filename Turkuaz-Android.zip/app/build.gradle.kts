plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

// Sürüm numarası kök klasördeki VERSION dosyasından okunur (ör. 1.0.1)
val surum: String = rootProject.file("VERSION").readText().trim()
val surumKodu: Int = surum.split(".").let { it[0].toInt() * 10000 + it[1].toInt() * 100 + it[2].toInt() }

android {
    namespace = "com.turkuaz.tarayici"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.turkuaz.tarayici"
        minSdk = 29
        targetSdk = 34
        versionCode = surumKodu
        versionName = surum
    }

    signingConfigs {
        create("yayin") {
            storeFile = file("turkuaz.jks")
            storePassword = "8oP8BfQkFQBBXk595aGa"
            keyAlias = "turkuaz"
            keyPassword = "8oP8BfQkFQBBXk595aGa"
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("yayin")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("androidx.webkit:webkit:1.11.0")
    implementation("androidx.swiperefreshlayout:swiperefreshlayout:1.1.0")
}
