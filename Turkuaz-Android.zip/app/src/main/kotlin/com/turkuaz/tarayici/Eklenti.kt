package com.turkuaz.tarayici

import android.annotation.SuppressLint
import android.app.Activity
import android.app.Dialog
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.util.Base64
import android.util.Log
import android.view.Gravity
import android.view.ViewGroup
import android.view.View
import android.view.Window
import android.webkit.ConsoleMessage
import android.webkit.CookieManager
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.webkit.WebViewAssetLoader
import androidx.webkit.WebViewCompat
import androidx.webkit.WebViewFeature
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.ExecutorService
import java.util.zip.ZipInputStream

class SekmeBilgi(val id: Int, val url: String, val baslik: String, val aktif: Boolean)
class Ext(val key: String, val ad: String, val surum: String, val dir: File, val mf: JSONObject)
class EkCtx(val id: Int, val key: String, val tur: String, val web: WebView, val tabId: Int)
class EkBekle(val kaynak: EkCtx, val cb: Int, var kalan: Int, var bitti: Boolean)

/**
 * Chrome eklentileri için küçük bir uyumluluk katmanı.
 * Sunucudan atanan eklenti paketini (zip) indirir, açılır menüsünü (popup) bir WebView'da gösterir,
 * arka plan betiğini gizli bir WebView'da çalıştırır ve içerik betiklerini sayfalara ekler.
 * chrome.storage / runtime / tabs / scripting / alarms gibi sık kullanılan arayüzler taklit edilir.
 */
class EklentiMotoru(
    // NOT: Activity değil Context — böylece bu motor hem bir Activity ile (normal kullanım,
    // popup/widget önizleme gibi UI özellikleri de çalışır) hem de yalnızca bir Service ile
    // (uygulama tamamen kapalıyken arka planda eklenti çalıştırmak için, bkz. EklentiServisi)
    // oluşturulabilir. Yalnızca gerçekten Activity gerektiren birkaç yer (popup penceresi,
    // widget canlı önizleme) `act as? Activity` ile korunuyor; Activity yoksa o özellik
    // sessizce atlanıyor, ama arka plan betikleri/chrome.alarms/ağ isteği gibi asıl eklenti
    // mantığı Context yeterli olduğu için her iki modda da aynı şekilde çalışıyor.
    private val act: Context,
    private val ui: Handler,
    private val io: ExecutorService,
    private val fToken: () -> String,
    private val fSurum: () -> String,
    private val fListe: () -> List<SekmeBilgi>,
    private val fWeb: (Int) -> WebView?,
    private val fSekmeAc: (String) -> Unit,
    private val fSekmeGit: (Int, String) -> Unit,
    private val fTum: () -> List<WebView>
) {
    companion object {
        const val ORIGIN = "https://appassets.androidplatform.net"
        // Sayfanın gerçek içerik yüksekliğini (CSS px) ölçer
        const val OLC_JS = "(function(){try{var m=0,sy=window.pageYOffset||0,l=document.body?document.body.getElementsByTagName('*'):[];var n=Math.min(l.length,3000);for(var i=0;i<n;i++){var e=l[i];var r=e.getBoundingClientRect();if(r.height<=0||r.width<=0)continue;var cs=getComputedStyle(e);if(cs.position==='fixed'||cs.display==='none'||cs.visibility==='hidden')continue;var b=r.bottom+sy;if(b>m)m=b;}var bs=document.body?parseFloat(getComputedStyle(document.body).marginBottom)||0:0;return Math.ceil(m+bs);}catch(e){return 0}})()"
    }

    private val kok = File(act.filesDir, "ext")
    private val loader: WebViewAssetLoader
    private val hazir = ConcurrentHashMap<String, Ext>()
    private val indiriliyor = HashSet<String>()
    private val bekleyen = HashMap<String, ArrayList<(Ext?) -> Unit>>()
    private val ctxler = ArrayList<EkCtx>()
    private var ctxSayac = 0
    private val bgler = HashMap<String, WebView>()
    private val bagli = java.util.WeakHashMap<WebView, HashSet<String>>()
    // Masaüstü (Turkuaz Kurulum) aynı hesapta açıkken Android'de eklenti arka plan
    // sayfaları duraklatılır; sunucu her esitle.php yanıtında "eklentiCalisabilir"
    // bayrağını gönderir, bkz. MainActivity.senkron().
    @Volatile private var calisabilir = true
    private val nonce = java.lang.Long.toString(Math.abs(java.util.Random().nextLong()), 36)
    private val kilit = Any()
    private val oturum = HashMap<String, JSONObject>()
    private val bekle = HashMap<Int, EkBekle>()
    private var jeton = 0
    private val popuplar = HashMap<Int, Dialog>()

    init {
        kok.mkdirs()
        loader = WebViewAssetLoader.Builder()
            .addPathHandler("/ext/", WebViewAssetLoader.InternalStoragePathHandler(act, kok))
            .build()
    }

    private fun dp(v: Int): Int = (v * act.resources.displayMetrics.density).toInt()
    private fun q(s: String): String = JSONObject.quote(s)
    private fun san(k: String): String = k.replace(Regex("[^A-Za-z0-9]"), "_") + Integer.toHexString(k.hashCode())
    private fun ad2(k: String): String = san(k) + "_" + nonce
    private fun arabirim(k: String): String = "__tzK_" + ad2(k)

    // ------------------------------------------------------------ elle (dosyadan) ekleme
    @Volatile var sonHata: String = ""

    fun yerelMi(key: String): Boolean = File(File(kok, key), ".yerel").exists()

    /** Daha önce elle eklenmiş eklentileri yükler. */
    fun yerelYukle() {
        io.execute {
            val l = ArrayList<Ext>()
            try {
                for (d in kok.listFiles() ?: emptyArray()) {
                    if (!d.isDirectory || !File(d, ".yerel").exists()) continue
                    try {
                        val mf = JSONObject(File(d, "manifest.json").readText().trim('\uFEFF'))
                        l.add(Ext(d.name, adBul(mf, d), "yerel", d, mf))
                    } catch (e: Exception) { }
                }
            } catch (e: Exception) { }
            ui.post { for (x in l) { hazir[x.key] = x; baslat(x) }; if (l.isNotEmpty()) { listeYaz(); dinleyici?.invoke() } }
        }
    }

    private fun adBul(mf: JSONObject, dir: File): String {
        var ad = mf.optString("name")
        if (ad.startsWith("__MSG_")) {
            try {
                val ad0 = ad.removePrefix("__MSG_").removeSuffix("__")
                val dil = mf.optString("default_locale", "en")
                var f = File(dir, "_locales/$dil/messages.json")
                if (!f.isFile) f = File(dir, "_locales/en/messages.json")
                if (!f.isFile) f = File(dir, "_locales/tr/messages.json")
                val m = JSONObject(f.readText().trim('\uFEFF'))
                var o = m.optJSONObject(ad0)
                if (o == null) {
                    val it = m.keys()
                    while (it.hasNext()) { val k = it.next(); if (k.equals(ad0, true)) { o = m.optJSONObject(k); break } }
                }
                val t = o?.optString("message").orEmpty()
                if (t.isNotEmpty()) ad = t
            } catch (e: Exception) { }
        }
        return if (ad.isEmpty() || ad.startsWith("__MSG_")) dir.name else ad
    }

    /** .zip veya .crx dosyasından eklenti ekler. */
    fun yerelEkle(uri: android.net.Uri, bitti: (String?) -> Unit) {
        io.execute {
            var ad: String? = null
            var hata = ""
            try {
                var b = act.contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: throw Exception("dosya okunamadı")
                // CRX başlığını atla
                if (b.size > 16 && b[0] == 'C'.code.toByte() && b[1] == 'r'.code.toByte() && b[2] == '2'.code.toByte() && b[3] == '4'.code.toByte()) {
                    fun u32(o: Int): Int = (b[o].toInt() and 255) or ((b[o + 1].toInt() and 255) shl 8) or ((b[o + 2].toInt() and 255) shl 16) or ((b[o + 3].toInt() and 255) shl 24)
                    val sur = u32(4)
                    val bas = if (sur >= 3) 12 + u32(8) else 16 + u32(8) + u32(12)
                    if (bas in 1 until b.size) b = b.copyOfRange(bas, b.size)
                }
                val tmp = File(kok, "yerel.yeni")
                tmp.deleteRecursively(); tmp.mkdirs()
                unzip(b, tmp)
                val kokDizin: File? = manifestKoku(tmp)
                if (kokDizin == null) throw Exception("pakette manifest.json yok")
                val mf = JSONObject(File(kokDizin, "manifest.json").readText().trim('\uFEFF'))
                val a = adBul(mf, kokDizin)
                val key = "yerel_" + Integer.toHexString((a + mf.optString("version")).hashCode()).replace("-", "")
                val dir = File(kok, key)
                dir.deleteRecursively()
                if (!kokDizin.renameTo(dir)) throw Exception("kaydedilemedi")
                tmp.deleteRecursively()
                File(dir, ".yerel").writeText("1")
                File(dir, ".surum").writeText("yerel")
                val x = Ext(key, a, "yerel", dir, mf)
                ui.post { kaldirSessiz(key); hazir[key] = x; baslat(x); listeYaz(); dinleyici?.invoke() }
                ad = a
            } catch (e: Exception) {
                hata = e.message ?: "hata"
                Log.e("Eklenti", "yerelEkle: " + hata)
            }
            sonHata = hata
            val son = ad
            ui.post { bitti(son) }
        }
    }

    private fun kaldirSessiz(key: String) {
        bgler.remove(key)?.let { try { it.destroy() } catch (e: Exception) { } }
    }

    fun yerelSil(key: String) {
        kaldir(key)
        io.execute { File(kok, key).deleteRecursively() }
    }

    // ------------------------------------------------------------ paket yönetimi
    fun hazirMi(key: String): Boolean = hazir.containsKey(key)

    /** Eklenti listesi değişince (indirildi / kaldırıldı) çağrılır. */
    var dinleyici: (() -> Unit)? = null

    // Panelde "listede görünmesin" denen eklentiler (arka planda yine çalışır)
    private val gizliSet = HashSet<String>()
    fun gizliMi(key: String): Boolean = gizliSet.contains(key)

    /** Widget eklenti seçme ekranı uygulama kapalıyken de çalışsın diye pencereli eklentilerin listesi saklanır. */
    private fun listeYaz() {
        try {
            val a = org.json.JSONArray()
            for (x in liste()) if (popupYolu(x).isNotEmpty()) a.put(org.json.JSONObject().put("k", x.key).put("a", x.ad))
            act.getSharedPreferences("widget", 0).edit().putString("liste", a.toString()).apply()
            EklentiWidget.yuvalariAyarla(act)
        } catch (e: Exception) { }
    }

    fun liste(): List<Ext> = hazir.values.filter { !gizliSet.contains(it.key) }.sortedBy { it.ad }

    fun popupYolu(x: Ext): String {
        val mf = x.mf
        var yol = mf.optJSONObject("action")?.optString("default_popup").orEmpty()
        if (yol.isEmpty()) yol = mf.optJSONObject("browser_action")?.optString("default_popup").orEmpty()
        if (yol.isEmpty()) yol = mf.optJSONObject("page_action")?.optString("default_popup").orEmpty()
        return yol
    }

    private fun enBuyuk(o: JSONObject): String {
        var best = -1
        var yol = ""
        val it = o.keys()
        while (it.hasNext()) {
            val k = it.next()
            val n = k.toIntOrNull() ?: 0
            if (n >= best) { best = n; yol = o.optString(k) }
        }
        return yol
    }

    /** Eklentinin kendi simgesi (araç çubuğunda gösterilir). */
    fun ikon(x: Ext): Bitmap? {
        try {
            var yol = ""
            val a = x.mf.optJSONObject("action") ?: x.mf.optJSONObject("browser_action")
            val di = a?.opt("default_icon")
            if (di is String) yol = di
            else if (di is JSONObject) yol = enBuyuk(di)
            if (yol.isEmpty()) {
                val ic = x.mf.optJSONObject("icons")
                if (ic != null) yol = enBuyuk(ic)
            }
            if (yol.isEmpty()) return null
            val f = File(x.dir, yol.trimStart('/'))
            if (!f.isFile) return null
            return BitmapFactory.decodeFile(f.path)
        } catch (e: Exception) {
            return null
        }
    }

    fun senkron(liste: JSONArray) {
        if (fToken().isEmpty()) {
            for (k in ArrayList(hazir.keys)) if (!yerelMi(k)) kaldir(k)
            return
        }
        val anahtarlar = HashSet<String>()
        val yeniGizli = HashSet<String>()
        for (i in 0 until liste.length()) {
            val e = liste.optJSONObject(i) ?: continue
            anahtarlar.add(e.optString("anahtar"))
            if (e.optJSONObject("bayraklar")?.optBoolean("gorunur", true) == false) yeniGizli.add(e.optString("anahtar"))
            hazirla(e, null)
        }
        for (k in ArrayList(hazir.keys)) if (!anahtarlar.contains(k) && !yerelMi(k)) kaldir(k)
        gizliSet.clear(); gizliSet.addAll(yeniGizli)
        ui.post { dinleyici?.invoke() }
    }

    fun hazirla(e: JSONObject, bitti: ((Ext?) -> Unit)?) {
        val key = e.optString("anahtar")
        val sur = e.optString("surum")
        if (key.isEmpty()) { bitti?.invoke(null); return }
        val var0 = hazir[key]
        if (var0 != null && var0.surum == sur) { bitti?.invoke(var0); return }
        if (bitti != null) bekleyen.getOrPut(key) { ArrayList() }.add(bitti)
        if (!indiriliyor.add(key)) return
        io.execute {
            var sonuc: Ext? = null
            try {
                val dir = File(kok, key)
                val isaret = File(dir, ".surum")
                if (!(isaret.exists() && isaret.readText() == sur && File(dir, "manifest.json").exists())) {
                    val b = Net.dosya("indir.php?anahtar=" + key, fToken(), fSurum()) ?: throw Exception(Net.sonHata.ifEmpty { "indirilemedi" })
                    val tmp = File(kok, "$key.yeni")
                    tmp.deleteRecursively()
                    tmp.mkdirs()
                    unzip(b, tmp)
                    val kokDizin: File? = manifestKoku(tmp)
                    if (kokDizin == null) throw Exception("pakette manifest.json yok")
                    dir.deleteRecursively()
                    if (!kokDizin.renameTo(dir)) throw Exception("kaydedilemedi")
                    tmp.deleteRecursively()
                    File(dir, ".surum").writeText(sur)
                }
                val mf = JSONObject(File(dir, "manifest.json").readText().trim('﻿'))
                sonuc = Ext(key, e.optString("ad"), sur, dir, mf)
            } catch (x: Exception) {
                Log.e("Eklenti", "hazirla: " + x.message)
                sonHata = x.message ?: "bilinmeyen hata"
            }
            val s = sonuc
            ui.post {
                indiriliyor.remove(key)
                if (s != null) { hazir[key] = s; baslat(s); listeYaz(); dinleyici?.invoke() }
                val l = bekleyen.remove(key)
                if (l != null) for (f in l) f(s)
            }
        }
    }

    private fun manifestKoku(d: File, derin: Int = 0): File? {
        if (File(d, "manifest.json").exists()) return d
        if (derin >= 3) return null
        for (a in d.listFiles() ?: emptyArray()) {
            if (a.isDirectory && !a.name.startsWith("__MACOSX")) { val r = manifestKoku(a, derin + 1); if (r != null) return r }
        }
        return null
    }

    private fun unzip(b: ByteArray, hedef: File) {
        val kanon = hedef.canonicalPath + File.separator
        ZipInputStream(b.inputStream()).use { z ->
            while (true) {
                val e = z.nextEntry ?: break
                val f = File(hedef, e.name)
                if (!f.canonicalPath.startsWith(kanon)) continue
                if (e.isDirectory) { f.mkdirs(); continue }
                f.parentFile?.mkdirs()
                f.outputStream().use { o -> z.copyTo(o) }
            }
        }
    }

    private fun kaldir(key: String) {
        hazir.remove(key)
        ui.post { dinleyici?.invoke() }
        bgler.remove(key)?.let { try { it.destroy() } catch (e: Exception) { } }
        synchronized(ctxler) {
            val l = ctxler.filter { it.key == key }
            for (c in l) {
                if (c.tur == "content") try { c.web.removeJavascriptInterface(arabirim(key)) } catch (e: Exception) { }
            }
            ctxler.removeAll(l.toSet())
        }
        for (s in bagli.values) s.remove(key)
    }

    private fun baslat(x: Ext) {
        if (calisabilir) arkaPlan(x)
        for (w in fTum()) icerikBagla(w, x)
    }

    /**
     * Sunucudan gelen "eklentiCalisabilir" bayrağına göre arka plan betiklerini
     * duraklatır/devam ettirir. Masaüstü (Turkuaz Kurulum) aynı hesapla açıkken
     * false gelir; böylece aynı eklenti hem masaüstünde hem telefonda birden aynı
     * anda (örn. aynı siteye iki kez istek atarak) çalışmaz. Sekmelerdeki içerik
     * betikleri (popup, chrome.tabs vb.) bundan etkilenmez — yalnızca arka plan
     * sayfaları (chrome.alarms zamanlayıcıları, otomatik tarama/eşleştirme) durur.
     */
    fun calismaDurumuAyarla(acikMi: Boolean) {
        if (acikMi == calisabilir) return
        calisabilir = acikMi
        if (!calisabilir) {
            for (k in ArrayList(bgler.keys)) {
                val w = bgler.remove(k) ?: continue
                synchronized(ctxler) { ctxler.removeAll { it.web === w } }
                try { w.destroy() } catch (e: Exception) { }
            }
        } else {
            for (x in hazir.values) arkaPlan(x)
        }
        ui.post { dinleyici?.invoke() }
    }

    fun calisabilirMi(): Boolean = calisabilir

    // ------------------------------------------------------------ arka plan
    @SuppressLint("SetJavaScriptEnabled")
    private fun ayarla(w: WebView) {
        val s = w.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = true
        s.allowFileAccess = false
        s.allowContentAccess = false
        s.userAgentString = Cfg.UA_MOBIL
        w.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(v: WebView, r: WebResourceRequest): WebResourceResponse? {
                val yanit = loader.shouldInterceptRequest(r.url) ?: return null
                try {
                    val yol = (r.url.path ?: "").lowercase()
                    val tur = when {
                        yol.endsWith(".html") || yol.endsWith(".htm") -> "text/html"
                        yol.endsWith(".js") || yol.endsWith(".mjs") -> "application/javascript"
                        yol.endsWith(".css") -> "text/css"
                        yol.endsWith(".json") -> "application/json"
                        yol.endsWith(".svg") -> "image/svg+xml"
                        yol.endsWith(".wasm") -> "application/wasm"
                        else -> ""
                    }
                    if (tur.isNotEmpty() && yanit.mimeType != tur) {
                        val enc = if (tur.startsWith("image") || tur.endsWith("wasm")) null else "utf-8"
                        val n = WebResourceResponse(tur, enc, yanit.data)
                        n.responseHeaders = yanit.responseHeaders
                        return n
                    }
                } catch (e: Exception) { }
                return yanit
            }
            override fun onReceivedError(v: WebView, r: WebResourceRequest, er: android.webkit.WebResourceError) {
                if (r.isForMainFrame) {
                    Toast.makeText(act, "Eklenti sayfası açılamadı: " + er.description + " (" + r.url.path + ")", Toast.LENGTH_LONG).show()
                }
            }
            override fun onReceivedHttpError(v: WebView, r: WebResourceRequest, er: WebResourceResponse) {
                if (r.isForMainFrame) {
                    Toast.makeText(act, "Eklenti dosyası bulunamadı (" + er.statusCode + "): " + r.url.path, Toast.LENGTH_LONG).show()
                }
            }
            override fun shouldOverrideUrlLoading(v: WebView, r: WebResourceRequest): Boolean {
                val u = r.url.toString()
                if (!u.startsWith(ORIGIN)) { fSekmeAc(u); return true }
                return false
            }
        }
        w.setDownloadListener { url, _, _, _, _ ->
            Toast.makeText(act, "Eklenti bir dosya indirmek istedi: " + url.take(70), Toast.LENGTH_LONG).show()
        }
        w.webChromeClient = object : WebChromeClient() {
            override fun onConsoleMessage(m: ConsoleMessage): Boolean {
                Log.d("Eklenti", m.message())
                return true
            }
        }
    }

    private fun kopruKur(w: WebView, x: Ext, c: EkCtx, tur: String) {
        w.addJavascriptInterface(Kopru(x.key, c), arabirim(x.key))
        if (WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT)) {
            try { WebViewCompat.addDocumentStartJavaScript(w, shim(x, tur), setOf(ORIGIN)) } catch (e: Exception) { Log.e("Eklenti", "shim: " + e.message) }
        }
    }

    private fun arkaPlan(x: Ext) {
        val eski = bgler.remove(x.key)
        if (eski != null) {
            synchronized(ctxler) { ctxler.removeAll { it.web === eski } }
            try { eski.destroy() } catch (e: Exception) { }
        }
        val b = x.mf.optJSONObject("background") ?: return
        var url: String
        val sayfa = b.optString("page")
        if (sayfa.isNotEmpty()) {
            url = ORIGIN + "/ext/" + x.key + "/" + sayfa.trimStart('/')
        } else {
            val betikler = ArrayList<String>()
            val sw = b.optString("service_worker")
            if (sw.isNotEmpty()) betikler.add(sw)
            val dz = b.optJSONArray("scripts")
            if (dz != null) for (i in 0 until dz.length()) betikler.add(dz.getString(i))
            if (betikler.isEmpty()) return
            val mod = b.optString("type") == "module"
            val html = StringBuilder("<!doctype html><meta charset=\"utf-8\">")
            for (s in betikler) {
                html.append("<script")
                if (mod) html.append(" type=\"module\"")
                html.append(" src=\"").append(s.trimStart('/')).append("\"></script>")
            }
            try { File(x.dir, "__tzbg.html").writeText(html.toString()) } catch (e: Exception) { return }
            url = ORIGIN + "/ext/" + x.key + "/__tzbg.html"
        }
        val w = WebView(act)
        ayarla(w)
        val c = EkCtx(++ctxSayac, x.key, "bg", w, -1)
        synchronized(ctxler) { ctxler.add(c) }
        kopruKur(w, x, c, "bg")
        bgler[x.key] = w
        w.loadUrl(url)
    }

    // ------------------------------------------------------------ içerik betikleri
    fun sekmeBagla(w: WebView) {
        for (x in hazir.values) icerikBagla(w, x)
    }

    fun sekmeKapandi(w: WebView) {
        synchronized(ctxler) { ctxler.removeAll { it.web === w } }
        bagli.remove(w)
    }

    private fun kural(p: String): List<String> {
        if (p == "<all_urls>") return listOf("*")
        val m = Regex("^(\\*|https?)://([^/]*)/.*$").find(p) ?: return emptyList()
        val sch = m.groupValues[1]
        val host = m.groupValues[2]
        if (host == "*") return listOf("*")
        val semalar = if (sch == "*") listOf("https", "http") else listOf(sch)
        return semalar.map { it + "://" + host }
    }

    private fun icerikBagla(w: WebView, x: Ext) {
        val cs = x.mf.optJSONArray("content_scripts") ?: return
        if (cs.length() == 0) return
        if (!WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT)) return
        val set = bagli.getOrPut(w) { HashSet() }
        if (!set.add(x.key)) return
        val s2 = ad2(x.key)
        val kod = StringBuilder(shim(x, "content"))
        val kurallar = HashSet<String>()
        for (i in 0 until cs.length()) {
            val e = cs.optJSONObject(i) ?: continue
            val eslesme = e.optJSONArray("matches") ?: continue
            for (j in 0 until eslesme.length()) kurallar.addAll(kural(eslesme.getString(j)))
            val js = StringBuilder()
            val jd = e.optJSONArray("js")
            if (jd != null) for (j in 0 until jd.length()) {
                val f = File(x.dir, jd.getString(j))
                if (f.isFile) js.append(f.readText()).append("\n;\n")
            }
            val css = StringBuilder()
            val cd = e.optJSONArray("css")
            if (cd != null) for (j in 0 until cd.length()) {
                val f = File(x.dir, cd.getString(j))
                if (f.isFile) css.append(f.readText()).append("\n")
            }
            val tum = e.optBoolean("all_frames", false)
            val runAt = e.optString("run_at", "document_idle")
            kod.append(";(function(){try{")
            kod.append("if(window!==window.top&&!").append(tum).append(")return;")
            kod.append("var mt=window['__tzMt_").append(s2).append("'];var mk=window['__tzMk_").append(s2).append("'];if(!mt||!mk)return;")
            kod.append("var ok=false;var m=").append(eslesme.toString()).append(";m.forEach(function(p){if(mt(p,location.href))ok=true;});if(!ok)return;")
            kod.append("var chrome=mk(),browser=chrome;")
            kod.append("function run(){")
            if (css.isNotBlank()) {
                kod.append("try{var st=document.createElement('style');st.textContent=").append(q(css.toString()))
                kod.append(";(document.head||document.documentElement).appendChild(st);}catch(e){}")
            }
            kod.append("try{\n").append(js).append("\n}catch(e){console.error(e);}")
            kod.append("}")
            if (runAt == "document_start") kod.append("run();")
            else kod.append("if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',run);else run();")
            kod.append("}catch(e){}})();\n")
        }
        if (kurallar.isEmpty()) return
        val c = EkCtx(++ctxSayac, x.key, "content", w, System.identityHashCode(w))
        synchronized(ctxler) { ctxler.add(c) }
        w.addJavascriptInterface(KopruIcerik(x.key, c), arabirim(x.key))
        val izinli: Set<String> = if (kurallar.contains("*")) setOf("*") else kurallar
        try {
            WebViewCompat.addDocumentStartJavaScript(w, kod.toString(), izinli)
            // eşleşmeyen sitelerde köprü nesnesini sayfalardan gizle
            WebViewCompat.addDocumentStartJavaScript(w, "(function(){try{delete window['" + arabirim(x.key) + "'];}catch(e){}})();", setOf("*"))
        } catch (e: Exception) {
            Log.e("Eklenti", "icerik: " + e.message)
        }
    }

    // ------------------------------------------------------------ açılır menü (popup)
    fun ac(e: JSONObject) {
        val key = e.optString("anahtar")
        val x = hazir[key]
        if (x != null && x.surum == e.optString("surum")) { popupAc(x); return }
        Toast.makeText(act, "Eklenti hazırlanıyor…", Toast.LENGTH_SHORT).show()
        hazirla(e) { s ->
            if (s != null) popupAc(s)
            else Toast.makeText(act, "Eklenti indirilemedi: " + sonHata + "\nDosyadan elle de ekleyebilirsin (Eklentiler > Dosyadan ekle).", Toast.LENGTH_LONG).show()
        }
    }

    /** Görüntünün sağında boş (beyaz/saydam) şerit kalmışsa keser; widget'ta yarım beyaz görünmesin. */
    private fun sagBosluguKirp(bmp: Bitmap): Bitmap {
        try {
            val gen = bmp.width
            val yuk = bmp.height
            val px = IntArray(gen)
            val say = IntArray(gen)
            var ornek = 0
            var y = 0
            while (y < yuk) {
                bmp.getPixels(px, 0, gen, 0, y, gen, 1)
                for (x in 0 until gen) {
                    val p = px[x]
                    val r = (p shr 16) and 0xFF
                    val g = (p shr 8) and 0xFF
                    val b = p and 0xFF
                    // beyaza yakın veya saydam olmayan (dolu) pikseller sayılır
                    if ((p ushr 24) > 16 && (r < 235 || g < 235 || b < 235)) say[x]++
                }
                ornek++
                y += 4
            }
            // sağdan sola: sütunun en az %20'si doluysa içerik sınırı odur (ince kaydırma çubuğu sayılmaz)
            val esik = Math.max(1, (ornek * 0.2f).toInt())
            var xr = gen - 1
            while (xr > 0 && say[xr] < esik) xr--
            if (xr > gen / 5 && xr < (gen * 0.92f).toInt()) return Bitmap.createBitmap(bmp, 0, 0, xr + 1, yuk)
        } catch (e: Exception) { }
        return bmp
    }

    private fun goruntu(w: WebView): Bitmap? {
        try {
            if (w.width <= 0 || w.height <= 0) return null
            val bmp = Bitmap.createBitmap(w.width, w.height, Bitmap.Config.ARGB_8888)
            w.draw(Canvas(bmp))
            return sagBosluguKirp(bmp)
        } catch (e: Exception) {
            return null
        }
    }

    /** Ana ekrana eklentiye doğrudan açılan kısayol ekler. */
    fun kisayolEkle(x: Ext) {
        try {
            val sm = act.getSystemService(android.content.pm.ShortcutManager::class.java)
            if (sm == null || !sm.isRequestPinShortcutSupported) {
                Toast.makeText(act, "Bu cihazın ana ekranı kısayol eklemeyi desteklemiyor", Toast.LENGTH_LONG).show()
                return
            }
            val i = Intent(act, MainActivity::class.java)
            i.action = "com.turkuaz.tarayici.EKLENTI"
            i.putExtra("ek", x.key)
            val b = ikon(x)
            val ic = if (b != null) android.graphics.drawable.Icon.createWithBitmap(Bitmap.createScaledBitmap(b, 192, 192, true))
                else android.graphics.drawable.Icon.createWithResource(act, R.mipmap.ic_launcher)
            val si = android.content.pm.ShortcutInfo.Builder(act, "ek_" + x.key)
                .setShortLabel(x.ad).setLongLabel(x.ad).setIcon(ic).setIntent(i).build()
            sm.requestPinShortcut(si, null)
        } catch (e: Exception) {
            Toast.makeText(act, "Kısayol eklenemedi", Toast.LENGTH_LONG).show()
        }
    }

    private fun popupYukle(w: WebView, x: Ext) {
        val yol = popupYolu(x)
        val temiz = yol.removePrefix("./").trimStart('/')
        val adres = ORIGIN + "/ext/" + x.key + "/" + temiz
        val dosya = File(x.dir, temiz.substringBefore('?').substringBefore('#'))
        if (dosya.isFile && (dosya.name.endsWith(".html", true) || dosya.name.endsWith(".htm", true))) {
            // Sayfayı doğrudan metin olarak ver: dosya türü yüzünden "indirme"ye düşmesin
            w.loadDataWithBaseURL(adres, dosya.readText(), "text/html", "utf-8", null)
        } else {
            w.loadUrl(adres)
        }
    }

    // ------------------------------------------------------------ widget canlı yenileme
    // Uygulama açıkken (pencere kapalı olsa da) widget'taki eklentinin görüntüsü periyodik yenilenir.
    private var canliWeb: WebView? = null
    private var canliCtx: EkCtx? = null
    private var canliAcik = false
    private var canliSira = 0
    private val canliDongu = object : Runnable {
        override fun run() {
            if (!canliAcik) return
            try { canliAdim() } catch (e: Exception) { }
            ui.postDelayed(this, 3000)
        }
    }

    fun widgetCanli(ac: Boolean) {
        if (ac == canliAcik) return
        canliAcik = ac
        ui.removeCallbacks(canliDongu)
        if (ac) ui.postDelayed(canliDongu, 1000) else canliKapat()
    }

    private fun canliKapat() {
        val w = canliWeb ?: return
        canliWeb = null
        canliCtx?.let { c -> synchronized(ctxler) { ctxler.removeAll { it.id == c.id } } }
        canliCtx = null
        try { (w.parent as? ViewGroup)?.removeView(w); w.destroy() } catch (e: Exception) { }
    }

    private fun canliAdim() {
        // Widget canlı önizlemesi bir Activity penceresine (decorView) ihtiyaç duyar; yalnızca
        // Service'ten (uygulama kapalıyken) çalışıyorsak bu adımı sessizce atla.
        val etkinlik = act as? Activity ?: run { canliKapat(); return }
        val keys = EklentiWidget.anahtarlar(act).filter { k -> hazir[k]?.let { popupYolu(it).isNotEmpty() } == true }
        if (keys.isEmpty()) { canliKapat(); return }
        val key = keys[canliSira % keys.size]
        val x = hazir[key]!!
        if (canliCtx != null && canliCtx!!.key != key) canliKapat()
        if (popuplar.isNotEmpty()) return
        val dm = act.resources.displayMetrics
        val w = canliWeb
        if (w == null) {
            val yeni = WebView(act)
            ayarla(yeni)
            yeni.setBackgroundColor(Color.WHITE)
            val c = EkCtx(++ctxSayac, x.key, "popup", yeni, -1)
            synchronized(ctxler) { ctxler.add(c) }
            kopruKur(yeni, x, c, "popup")
            val dv = etkinlik.window.decorView as ViewGroup
            dv.addView(yeni, 0, FrameLayout.LayoutParams((dm.widthPixels * 0.94).toInt(), (dm.heightPixels * 0.5).toInt()))
            popupYukle(yeni, x)
            canliWeb = yeni
            canliCtx = c
            return
        }
        w.evaluateJavascript(OLC_JS) { r ->
            val cssPx = r?.trim('"')?.toDoubleOrNull()
            if (cssPx != null && cssPx > 0) {
                val hedef = Math.max(dp(120), Math.min((dm.heightPixels * 0.8).toInt(), (cssPx * dm.density).toInt() + dp(4)))
                val lp = w.layoutParams
                if (lp != null && Math.abs(lp.height - hedef) > dp(6)) { lp.height = hedef; w.layoutParams = lp }
            }
            ui.postDelayed({
                if (canliWeb === w) {
                    val b = goruntu(w)
                    if (b != null) EklentiWidget.kaydet(act, x.key, x.ad, b)
                    canliSira++
                }
            }, 500)
        }
    }

    /** Eklentiye bağlanmamış bir widget'a hangi eklentinin gösterileceğini seçtirir. */
    fun widgetSec(wid: Int) {
        val etkinlik = act as? Activity ?: return
        val l = liste().filter { popupYolu(it).isNotEmpty() }
        if (l.isEmpty()) { Toast.makeText(act, "Pencereli eklenti bulunamadı", Toast.LENGTH_LONG).show(); return }
        val ad = Array(l.size) { l[it].ad }
        android.app.AlertDialog.Builder(etkinlik).setTitle("Widget için eklenti seç")
            .setItems(ad) { _, i ->
                EklentiWidget.bagla(act, wid, l[i].key)
                popupAc(l[i])
            }
            .setNegativeButton("Vazgeç", null).show()
    }

    fun popupAc(x: Ext) {
        // Popup penceresi bir Activity/Dialog penceresi gerektirir; Service'ten (uygulama
        // kapalıyken) tetiklenemez — zaten kullanıcı bir simgeye dokunarak açtığı için bu
        // yalnızca uygulama zaten açıkken çağrılır, ama tip güvenliği için yine de koruyoruz.
        val etkinlik = act as? Activity ?: return
        val yol = popupYolu(x)
        if (yol.isEmpty()) {
            Toast.makeText(act, x.ad + ": açılır menüsü yok, arka planda çalışıyor.", Toast.LENGTH_LONG).show()
            return
        }
        val w = WebView(act)
        ayarla(w)
        w.setBackgroundColor(Color.WHITE)
        val c = EkCtx(++ctxSayac, x.key, "popup", w, -1)
        synchronized(ctxler) { ctxler.add(c) }
        kopruKur(w, x, c, "popup")

        val pal = MainActivity.paletteOf(act, Store(act))
        val dm = act.resources.displayMetrics
        val azami = (dm.heightPixels * 0.80).toInt()
        val d = Dialog(etkinlik)
        d.requestWindowFeature(Window.FEATURE_NO_TITLE)
        val kutu = LinearLayout(act)
        kutu.orientation = LinearLayout.VERTICAL
        val arka = GradientDrawable()
        arka.setColor(pal.bar)
        arka.cornerRadius = dp(26).toFloat()
        kutu.background = arka
        kutu.clipToOutline = true
        kutu.elevation = dp(12).toFloat()

        val ust = LinearLayout(act)
        ust.orientation = LinearLayout.HORIZONTAL
        ust.gravity = Gravity.CENTER_VERTICAL
        ust.setPadding(dp(14), dp(10), dp(10), dp(10))
        ust.setBackgroundColor(pal.bar)
        val simge = ikon(x)
        val kart = FrameLayout(act)
        val kartBg = GradientDrawable()
        kartBg.cornerRadius = dp(10).toFloat()
        kartBg.setColor(pal.field)
        kart.background = kartBg
        if (simge != null) {
            val iv = ImageView(act)
            iv.setImageBitmap(simge)
            iv.setPadding(dp(4), dp(4), dp(4), dp(4))
            kart.addView(iv, FrameLayout.LayoutParams(-1, -1))
        } else {
            val iv = ImageView(act)
            iv.setImageResource(R.drawable.ic_eklenti)
            iv.setColorFilter(pal.accent)
            iv.setPadding(dp(7), dp(7), dp(7), dp(7))
            kart.addView(iv, FrameLayout.LayoutParams(-1, -1))
        }
        ust.addView(kart, LinearLayout.LayoutParams(dp(36), dp(36)))
        val kol = LinearLayout(act)
        kol.orientation = LinearLayout.VERTICAL
        val ad = TextView(act)
        ad.text = x.ad
        ad.setTextColor(pal.fg)
        ad.textSize = 15f
        ad.typeface = Typeface.DEFAULT_BOLD
        ad.setSingleLine()
        ad.ellipsize = android.text.TextUtils.TruncateAt.END
        kol.addView(ad)
        val alt = TextView(act)
        alt.text = "Eklenti"
        alt.setTextColor(pal.muted)
        alt.textSize = 11.5f
        kol.addView(alt)
        val kolLp = LinearLayout.LayoutParams(0, -2, 1f)
        kolLp.leftMargin = dp(12)
        ust.addView(kol, kolLp)
        fun duz(res: Int, f: () -> Unit) {
            val fl = FrameLayout(act)
            val bg = GradientDrawable()
            bg.shape = GradientDrawable.OVAL
            bg.setColor(pal.field)
            fl.background = bg
            val iv = ImageView(act)
            iv.setImageResource(res)
            iv.setColorFilter(pal.fg)
            fl.addView(iv, FrameLayout.LayoutParams(dp(18), dp(18), Gravity.CENTER))
            fl.setOnClickListener { f() }
            val lp = LinearLayout.LayoutParams(dp(36), dp(36))
            lp.leftMargin = dp(8)
            ust.addView(fl, lp)
        }
        duz(R.drawable.ic_widget) {
            val bmp = goruntu(w)
            if (bmp == null) {
                Toast.makeText(act, "Görüntü alınamadı", Toast.LENGTH_SHORT).show()
            } else {
                EklentiWidget.kaydet(act, x.key, x.ad, bmp)
                EklentiWidget.ekle(act, x.key)
                Toast.makeText(act, "Bu eklenti için widget eklenebilir; görünüm uygulama açıkken kendiliğinden yenilenir", Toast.LENGTH_LONG).show()
            }
        }
        duz(R.drawable.ic_eve) { kisayolEkle(x) }
        duz(R.drawable.ic_kapat) { d.dismiss() }
        kutu.addView(ust, LinearLayout.LayoutParams(-1, -2))
        val ayr = View(act)
        ayr.setBackgroundColor(pal.field)
        kutu.addView(ayr, LinearLayout.LayoutParams(-1, dp(1)))
        kutu.addView(w, LinearLayout.LayoutParams(-1, dp(160)))
        // pencere yüksekliği eklentinin içeriğine göre ayarlanır
        val olc = object : Runnable {
            override fun run() {
                if (!d.isShowing) return
                w.evaluateJavascript(OLC_JS) { r ->
                    val cssPx = r?.trim('"')?.toDoubleOrNull()
                    if (cssPx != null && cssPx > 0) {
                        val hedef = Math.max(dp(120), Math.min(azami - dp(60), (cssPx * dm.density).toInt() + dp(4)))
                        val lp = w.layoutParams
                        if (lp != null && Math.abs(lp.height - hedef) > dp(6)) { lp.height = hedef; w.layoutParams = lp }
                    }
                }
                ui.postDelayed(this, 450)
            }
        }
        ui.postDelayed(olc, 500)
        kutu.scaleX = 0.94f; kutu.scaleY = 0.94f; kutu.alpha = 0f
        kutu.animate().scaleX(1f).scaleY(1f).alpha(1f).setDuration(170).start()
        d.setContentView(kutu)
        d.setOnDismissListener {
            synchronized(ctxler) { ctxler.removeAll { it.id == c.id } }
            popuplar.remove(c.id)
            try { (w.parent as? ViewGroup)?.removeView(w); w.destroy() } catch (e: Exception) { }
        }
        d.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        d.window?.setDimAmount(0.5f)
        d.window?.setLayout((dm.widthPixels * 0.94).toInt(), ViewGroup.LayoutParams.WRAP_CONTENT)
        d.window?.setGravity(Gravity.TOP)
        val lp = d.window?.attributes
        if (lp != null) { lp.y = dp(64); d.window?.attributes = lp }
        popuplar[c.id] = d
        d.show()
        popupYukle(w, x)
        // widget bu eklentiye bağlıysa pencere açıkken görüntüsünü yenile
        val yenile = object : Runnable {
            override fun run() {
                if (!d.isShowing) return
                if (EklentiWidget.bagliMi(act, x.key)) {
                    val b = goruntu(w)
                    if (b != null) EklentiWidget.kaydet(act, x.key, x.ad, b)
                }
                ui.postDelayed(this, 4000)
            }
        }
        ui.postDelayed(yenile, 1800)
    }

    // ------------------------------------------------------------ depolama
    private fun depoAl(key: String, alan: String): JSONObject {
        return synchronized(kilit) {
            if (alan == "session") {
                JSONObject(oturum.getOrPut(key) { JSONObject() }.toString())
            } else {
                try {
                    JSONObject(act.getSharedPreferences("ext_$key", 0).getString("a_$alan", "{}") ?: "{}")
                } catch (e: Exception) { JSONObject() }
            }
        }
    }

    private fun depoKaydet(key: String, alan: String, o: JSONObject) {
        synchronized(kilit) {
            if (alan == "session") oturum[key] = o
            else act.getSharedPreferences("ext_$key", 0).edit().putString("a_$alan", o.toString()).apply()
        }
    }

    private fun depoYaz(key: String, alan: String, json: String) {
        val yeni = try { JSONObject(json) } catch (e: Exception) { return }
        synchronized(kilit) {
            val o = depoAl(key, alan)
            val ch = JSONObject()
            val it = yeni.keys()
            while (it.hasNext()) {
                val k = it.next()
                val d = JSONObject()
                if (o.has(k)) d.put("oldValue", o.get(k))
                d.put("newValue", yeni.get(k))
                ch.put(k, d)
                o.put(k, yeni.get(k))
            }
            depoKaydet(key, alan, o)
            depoYayin(key, alan, ch)
        }
    }

    private fun depoSil(key: String, alan: String, anahtarlar: String) {
        val l = try { JSONArray(anahtarlar) } catch (e: Exception) { return }
        synchronized(kilit) {
            val o = depoAl(key, alan)
            val ch = JSONObject()
            for (i in 0 until l.length()) {
                val k = l.optString(i)
                if (o.has(k)) {
                    val d = JSONObject()
                    d.put("oldValue", o.get(k))
                    ch.put(k, d)
                    o.remove(k)
                }
            }
            depoKaydet(key, alan, o)
            depoYayin(key, alan, ch)
        }
    }

    private fun depoTemizle(key: String, alan: String) {
        synchronized(kilit) {
            val o = depoAl(key, alan)
            val ch = JSONObject()
            val it = o.keys()
            while (it.hasNext()) {
                val k = it.next()
                val d = JSONObject()
                d.put("oldValue", o.get(k))
                ch.put(k, d)
            }
            depoKaydet(key, alan, JSONObject())
            depoYayin(key, alan, ch)
        }
    }

    private fun ctxListe(key: String): List<EkCtx> = synchronized(ctxler) { ctxler.filter { it.key == key } }

    private fun js(w: WebView, kod: String) {
        ui.post { try { w.evaluateJavascript(kod, null) } catch (e: Exception) { } }
    }

    private fun depoYayin(key: String, alan: String, ch: JSONObject) {
        val s2 = ad2(key)
        val kod = "window['__tzSt_" + s2 + "']&&window['__tzSt_" + s2 + "'](" + q(ch.toString()) + "," + q(alan) + ")"
        for (c in ctxListe(key)) js(c.web, kod)
    }

    // ------------------------------------------------------------ mesajlaşma
    private fun yanitYolla(c: EkCtx, cb: Int, json: String) {
        val s2 = ad2(c.key)
        js(c.web, "window['__tzR_" + s2 + "']&&window['__tzR_" + s2 + "'](" + cb + "," + q(json) + ")")
    }

    private fun mesajGonder(kaynak: EkCtx, msg: String, cb: Int, tabHedef: Int) {
        ui.post {
            val hedefler = ctxListe(kaynak.key).filter {
                it !== kaynak && (if (tabHedef >= 0) (it.tur == "content" && it.tabId == tabHedef) else it.tur != "content")
            }
            if (hedefler.isEmpty()) {
                yanitYolla(kaynak, cb, "null")
            } else {
                val tk = ++jeton
                bekle[tk] = EkBekle(kaynak, cb, hedefler.size, false)
                val sender = JSONObject()
                sender.put("id", kaynak.key)
                if (kaynak.tur == "content") {
                    val tb = JSONObject()
                    tb.put("id", kaynak.tabId)
                    val u = try { kaynak.web.url ?: "" } catch (e: Exception) { "" }
                    tb.put("url", u)
                    sender.put("tab", tb)
                    sender.put("url", u)
                }
                val s2 = ad2(kaynak.key)
                val kod = "window['__tzIn_" + s2 + "']&&window['__tzIn_" + s2 + "'](" + q(msg) + "," + q(sender.toString()) + "," + tk + ")"
                for (h in hedefler) js(h.web, kod)
            }
        }
    }

    private fun yanitAl(tk: Int, resp: String) {
        ui.post {
            val b = bekle[tk]
            if (b != null && !b.bitti) {
                if (resp == "__YOK__") {
                    b.kalan--
                    if (b.kalan <= 0) { b.bitti = true; bekle.remove(tk); yanitYolla(b.kaynak, b.cb, "null") }
                } else {
                    b.bitti = true
                    bekle.remove(tk)
                    yanitYolla(b.kaynak, b.cb, resp)
                }
            }
        }
    }

    // ------------------------------------------------------------ ağ (CORS'suz fetch)
    private fun agFetch(c: EkCtx, cb: Int, url: String, opts: String) {
        io.execute {
            val sonuc = JSONObject()
            try {
                val o = JSONObject(opts)
                val bag = URL(url).openConnection() as HttpURLConnection
                bag.connectTimeout = 20000
                bag.readTimeout = 60000
                val metot = o.optString("method", "GET").uppercase()
                bag.requestMethod = metot
                var cerezVar = false
                val h = o.optJSONObject("headers")
                if (h != null) {
                    val it = h.keys()
                    while (it.hasNext()) {
                        val k = it.next()
                        bag.setRequestProperty(k, h.optString(k))
                        if (k.equals("cookie", true)) cerezVar = true
                    }
                }
                if (!cerezVar) {
                    val ck = CookieManager.getInstance().getCookie(url)
                    if (ck != null) bag.setRequestProperty("Cookie", ck)
                }
                bag.setRequestProperty("User-Agent", Cfg.UA_MOBIL)
                if (!o.isNull("body") && metot != "GET" && metot != "HEAD") {
                    bag.doOutput = true
                    bag.outputStream.use { os -> os.write(o.optString("body").toByteArray(Charsets.UTF_8)) }
                }
                val kod = bag.responseCode
                val ak = if (kod in 200..399) bag.inputStream else bag.errorStream
                val veri = if (ak != null) ak.use { it.readBytes() } else ByteArray(0)
                val hh = JSONObject()
                for ((k, v) in bag.headerFields) {
                    if (k == null) continue
                    if (k.equals("Set-Cookie", true)) { for (sc in v) CookieManager.getInstance().setCookie(url, sc) }
                    else if (v.isNotEmpty()) hh.put(k, v.joinToString(", "))
                }
                sonuc.put("status", kod)
                sonuc.put("st", bag.responseMessage ?: "")
                sonuc.put("h", hh)
                sonuc.put("b64", Base64.encodeToString(veri, Base64.NO_WRAP))
                bag.disconnect()
            } catch (x: Exception) {
                sonuc.put("err", x.message ?: "hata")
            }
            yanitYolla(c, cb, sonuc.toString())
        }
    }

    // ------------------------------------------------------------ JavaScript köprüleri
    /** İçerik betikleri için kısıtlı köprü (web sayfalarına açık olan kısım). */
    open inner class KopruIcerik(val key: String, val c: EkCtx) {
        @JavascriptInterface fun kimlik(): Int = c.id
        @JavascriptInterface fun tabKimlik(): Int = c.tabId
        @JavascriptInterface fun manifest(): String = hazir[key]?.mf?.toString() ?: "{}"
        @JavascriptInterface fun depoOku(alan: String): String = depoAl(key, alan).toString()
        @JavascriptInterface fun depoYaz(alan: String, json: String) { this@EklentiMotoru.depoYaz(key, alan, json) }
        @JavascriptInterface fun depoSil(alan: String, anahtarlar: String) { this@EklentiMotoru.depoSil(key, alan, anahtarlar) }
        @JavascriptInterface fun depoTemizle(alan: String) { this@EklentiMotoru.depoTemizle(key, alan) }
        @JavascriptInterface fun mesaj(msg: String, cb: Int, tab: Int) { mesajGonder(c, msg, cb, tab) }
        @JavascriptInterface fun cevapAl(tk: Int, resp: String) { yanitAl(tk, resp) }
    }

    /** Açılır menü ve arka plan için tam köprü. */
    inner class Kopru(key: String, c: EkCtx) : KopruIcerik(key, c) {
        @JavascriptInterface fun sekmeler(): String {
            val a = JSONArray()
            try {
                for ((i, t) in fListe().withIndex()) {
                    val o = JSONObject()
                    o.put("id", t.id); o.put("url", t.url); o.put("title", t.baslik)
                    o.put("active", t.aktif); o.put("windowId", 1); o.put("index", i)
                    a.put(o)
                }
            } catch (e: Exception) { }
            return a.toString()
        }
        @JavascriptInterface fun sekmeAc(url: String) { ui.post { fSekmeAc(url) } }
        @JavascriptInterface fun sekmeGit(id: Int, url: String) { ui.post { fSekmeGit(id, url) } }
        @JavascriptInterface fun calistir(cb: Int, tab: Int, kod: String) {
            ui.post {
                val id = if (tab >= 0) tab else (fListe().firstOrNull { it.aktif }?.id ?: -1)
                val w = fWeb(id)
                if (w == null) yanitYolla(c, cb, "null")
                else try {
                    w.evaluateJavascript(kod) { v -> yanitYolla(c, cb, v ?: "null") }
                } catch (e: Exception) { yanitYolla(c, cb, "null") }
            }
        }
        @JavascriptInterface fun fetch(cb: Int, url: String, opts: String) { agFetch(c, cb, url, opts) }
        @JavascriptInterface fun bildir(m: String) {
            ui.post {
                Toast.makeText(act, m, Toast.LENGTH_LONG).show()
                // chrome.notifications.create() yalnızca anlık bir Toast değil, gerçek bir sistem
                // bildirimi de göstersin: uygulama arka plandayken de (Toast aksine) görünür kalır.
                // Her eklenti KENDİ bildirim kanalına sahip olsun: Ayarlar > Uygulamalar > Turkuaz >
                // Bildirimler altında, kullanıcı her eklentiyi ayrı ayrı açıp kapatabilsin.
                try {
                    val nm = act.getSystemService(android.app.NotificationManager::class.java)
                    val x = hazir[key]
                    val ad = x?.ad ?: key
                    val kanalId = "eklenti_" + san(key)
                    nm.createNotificationChannel(
                        android.app.NotificationChannel(kanalId, ad, android.app.NotificationManager.IMPORTANCE_DEFAULT)
                    )
                    val ac = android.app.PendingIntent.getActivity(
                        act, 0,
                        Intent(act, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
                        android.app.PendingIntent.FLAG_IMMUTABLE or android.app.PendingIntent.FLAG_UPDATE_CURRENT
                    )
                    val nb = android.app.Notification.Builder(act, kanalId)
                        .setSmallIcon(R.drawable.ic_eklenti)
                        .setContentTitle(ad)
                        .setContentText(m)
                        .setContentIntent(ac)
                        .setAutoCancel(true)
                    // Bildirimde genel Turkuaz rozeti yerine eklentinin KENDİ ikonu görünsün
                    // (manifest.json'daki icons/default_icon'dan okunur, aynı ikon ana listede
                    // ve popup'ta da kullanılıyor).
                    val simge = x?.let { ikon(it) }
                    if (simge != null) {
                        nb.setLargeIcon(simge)
                        try { nb.setSmallIcon(android.graphics.drawable.Icon.createWithBitmap(simge)) } catch (e: Exception) { }
                    }
                    val n = nb.build()
                    nm.notify((kanalId + m + System.currentTimeMillis()).hashCode(), n)
                } catch (e: Exception) { }
            }
        }
        @JavascriptInterface fun cerezler(url: String): String = CookieManager.getInstance().getCookie(url) ?: ""
        @JavascriptInterface fun cerezYaz(url: String, ck: String) { CookieManager.getInstance().setCookie(url, ck) }
        @JavascriptInterface fun kurulum(): String {
            val p = act.getSharedPreferences("ext_$key", 0)
            val son = p.getString("surum_son", null)
            val sur = hazir[key]?.surum ?: ""
            if (son == sur) return ""
            p.edit().putString("surum_son", sur).apply()
            return if (son == null) "install" else "update"
        }
        @JavascriptInterface fun kapat() { ui.post { popuplar[c.id]?.dismiss() } }
    }

    // ------------------------------------------------------------ chrome.* uyumluluk betiği
    private fun shim(x: Ext, tur: String): String {
        return SHIM
            .replace("@@S@@", ad2(x.key))
            .replace("@@N@@", arabirim(x.key))
            .replace("@@KEY@@", x.key)
            .replace("@@TUR@@", tur)
            .replace("@@ORI@@", ORIGIN)
    }

    private val SHIM = """
(function(){
var S='@@S@@',KEY='@@KEY@@',TUR='@@TUR@@',ORI='@@ORI@@';
var K=window['@@N@@'];
if(!K||window['__tzMk_'+S])return;
var CB={},cbn=0;
function cb(f){var i=++cbn;CB[i]=f;return i;}
window['__tzR_'+S]=function(i,s){var f=CB[i];delete CB[i];if(f){var v=null;try{v=JSON.parse(s);}catch(e){}f(v);}};
function api(fn){return function(){var a=[].slice.call(arguments);var f=(a.length&&typeof a[a.length-1]==='function')?a.pop():null;var p=new Promise(function(res){try{fn(a,res);}catch(e){console.error(e);res();}});if(f){p.then(function(v){f(v);});return undefined;}return p;};}
function Ev(){var L=[];return{addListener:function(f){if(L.indexOf(f)<0)L.push(f);},removeListener:function(f){var i=L.indexOf(f);if(i>=0)L.splice(i,1);},hasListener:function(f){return L.indexOf(f)>=0;},hasListeners:function(){return L.length>0;},_L:L,_f:function(){var a=arguments;L.slice().forEach(function(f){try{f.apply(null,a);}catch(e){console.error(e);}});}};}
function stub(){var f=function(){};return new Proxy(f,{get:function(t,p){if(typeof p==='symbol'||p==='then')return undefined;if(p==='addListener'||p==='removeListener'||p==='hasListener'||p==='hasListeners')return function(){return false;};return stub();},apply:function(t,th,a){var l=a[a.length-1];if(typeof l==='function'){try{l();}catch(e){}return undefined;}return Promise.resolve();}});}
function mt(p,u){
 if(p==='<all_urls>')return /^(https?|file|ftp):/.test(u);
 var r=/^(\*|https?|file|ftp):\/\/([^\/]*)(\/.*)${'$'}/.exec(p);if(!r)return false;
 var m=/^([a-z]+):\/\/([^\/]*)(\/.*)?${'$'}/i.exec(u);if(!m)return false;
 if(r[1]==='*'){if(m[1]!=='http'&&m[1]!=='https')return false;}else if(r[1]!==m[1])return false;
 var h=r[2],uh=m[2].replace(/:\d+${'$'}/,'');
 if(h!=='*'){if(h.indexOf('*.')===0){var b=h.slice(2);if(uh!==b&&!(uh.length>b.length&&uh.slice(-(b.length+1))==='.'+b))return false;}else if(h!==uh&&h!==m[2])return false;}
 var re=new RegExp('^'+r[3].replace(/[.+?^()|[\]{}\\]/g,function(c){return '\\'+c;}).replace(/\*/g,'.*')+'\x24');
 return re.test(m[3]||'/');
}
window['__tzMt_'+S]=mt;
var ev_msg=Ev(),ev_inst=Ev(),ev_start=Ev(),ev_st=Ev(),areas={};
function area(n){var ev=Ev();areas[n]=ev;return{onChanged:ev,
 get:api(function(a,res){var all=JSON.parse(K.depoOku(n)),keys=a[0],out={};
  if(keys==null){out=all;}
  else if(typeof keys==='string'){if(keys in all)out[keys]=all[keys];}
  else if(Array.isArray(keys)){keys.forEach(function(k){if(k in all)out[k]=all[k];});}
  else{for(var k in keys){out[k]=(k in all)?all[k]:keys[k];}}
  res(out);}),
 set:api(function(a,res){K.depoYaz(n,JSON.stringify(a[0]||{}));res();}),
 remove:api(function(a,res){var ks=a[0];if(typeof ks==='string')ks=[ks];K.depoSil(n,JSON.stringify(ks||[]));res();}),
 clear:api(function(a,res){K.depoTemizle(n);res();}),
 getBytesInUse:api(function(a,res){res(0);}),
 setAccessLevel:api(function(a,res){res();})};}
window['__tzSt_'+S]=function(s,n){var ch=JSON.parse(s);if(areas[n])areas[n]._f(ch);ev_st._f(ch,n);};
function sendMsg(tabId,args){
 var a=[].slice.call(args);var f=(a.length&&typeof a[a.length-1]==='function')?a.pop():null;var msg=a[0];
 if(tabId<0&&a.length>=2&&typeof a[0]==='string'&&a[1]!==null&&typeof a[1]==='object'&&!('includeTlsChannelId' in a[1]))msg=a[1];
 var p=new Promise(function(res){var id=cb(function(v){res(v===null?undefined:v);});K.mesaj(JSON.stringify(msg===undefined?null:msg),id,tabId);});
 if(f){p.then(function(v){f(v);});return undefined;}return p;}
window['__tzIn_'+S]=function(m,s,tk){
 var msg=JSON.parse(m),sender=JSON.parse(s),replied=false,asy=false;
 function send(r){if(replied)return;replied=true;K.cevapAl(tk,JSON.stringify(r===undefined?null:r));}
 ev_msg._L.slice().forEach(function(f){if(replied)return;try{var r=f(msg,sender,send);if(r===true)asy=true;else if(r&&typeof r.then==='function'){asy=true;r.then(send);}}catch(e){console.error(e);}});
 if(!replied&&!asy)K.cevapAl(tk,'__YOK__');};
var runtime={id:KEY,lastError:undefined,
 getManifest:function(){return JSON.parse(K.manifest());},
 getURL:function(p){return ORI+'/ext/'+KEY+'/'+String(p||'').replace(/^\//,'');},
 sendMessage:function(){return sendMsg(-1,arguments);},
 onMessage:ev_msg,onMessageExternal:Ev(),onInstalled:ev_inst,onStartup:ev_start,onConnect:Ev(),
 connect:function(){return{name:'',postMessage:function(){},disconnect:function(){},onMessage:Ev(),onDisconnect:Ev()};},
 sendNativeMessage:function(){return Promise.resolve();},
 getPlatformInfo:function(){return Promise.resolve({os:'android',arch:'arm'});},
 openOptionsPage:function(){return Promise.resolve();},reload:function(){}};
var base={runtime:runtime,
 extension:{getURL:runtime.getURL,getBackgroundPage:function(){return null;},inIncognitoContext:false},
 storage:{local:area('local'),sync:area('sync'),session:area('session'),managed:area('managed'),onChanged:ev_st},
 i18n:{getMessage:function(k){return k;},getUILanguage:function(){return 'tr';}},
 permissions:{contains:function(){return Promise.resolve(true);},request:function(){return Promise.resolve(true);},getAll:function(){return Promise.resolve({permissions:[],origins:[]});},onAdded:Ev(),onRemoved:Ev()}};
if(TUR!=='content'){
 function runCode(tabId,code,cbk){var id=cb(function(v){cbk({result:v});});K.calistir(id,tabId==null?-1:tabId,code);}
 base.tabs={
  query:api(function(a,res){var l=JSON.parse(K.sekmeler());var q=a[0]||{};res(l.filter(function(t){if(q.active!=null&&!!q.active!==t.active)return false;if(q.url){var us=[].concat(q.url);if(!us.some(function(p){return mt(p,t.url);}))return false;}return true;}));}),
  get:api(function(a,res){var l=JSON.parse(K.sekmeler());res(l.filter(function(t){return t.id===a[0];})[0]);}),
  getCurrent:api(function(a,res){res(undefined);}),
  create:api(function(a,res){var o=a[0]||{};if(o.url)K.sekmeAc(o.url);res({id:0,url:o.url||''});}),
  update:api(function(a,res){var id=a[0],o=a[1];if(typeof id==='object'){o=id;id=null;}
   if(id==null){var l=JSON.parse(K.sekmeler());var t=l.filter(function(x){return x.active;})[0];id=t?t.id:null;}
   if(id!=null&&o&&o.url)K.sekmeGit(id,o.url);res({id:id});}),
  remove:api(function(a,res){res();}),reload:api(function(a,res){res();}),
  sendMessage:function(){var a=[].slice.call(arguments);var id=a.shift();return sendMsg(id,a);},
  executeScript:api(function(a,res){var id=a[0],d=a[1];if(typeof id==='object'){d=id;id=null;}runCode(id,(d&&d.code)||'',function(v){res([v]);});}),
  onUpdated:Ev(),onActivated:Ev(),onRemoved:Ev(),onCreated:Ev()};
 base.windows={getCurrent:function(){return Promise.resolve({id:1,focused:true,type:'normal'});},getAll:function(){return Promise.resolve([{id:1,focused:true,type:'normal'}]);},
  create:function(o){o=o||{};var u=[].concat(o.url||[]);if(u[0])K.sekmeAc(u[0]);return Promise.resolve({id:1});},update:function(){return Promise.resolve({id:1});},remove:function(){return Promise.resolve();},onCreated:Ev(),onRemoved:Ev(),onFocusChanged:Ev(),WINDOW_ID_NONE:-1,WINDOW_ID_CURRENT:-2};
 base.scripting={
  executeScript:api(function(a,res){var o=a[0]||{};var tid=o.target&&o.target.tabId;
   function go(code){runCode(tid==null?null:tid,code,function(r){res([r]);});}
   if(o.func){go('(function(){return ('+o.func.toString()+').apply(null,'+JSON.stringify(o.args||[])+');})()');}
   else if(o.files){Promise.all(o.files.map(function(f){return fetch(ORI+'/ext/'+KEY+'/'+f.replace(/^\//,'')).then(function(r){return r.text();});})).then(function(t){go(t.join('\n;'));});}
   else res([]);}),
  insertCSS:api(function(a,res){var o=a[0]||{};var tid=o.target&&o.target.tabId;runCode(tid==null?null:tid,'(function(){var s=document.createElement("style");s.textContent='+JSON.stringify(o.css||'')+';document.documentElement.appendChild(s);})()',function(){res();});}),
  removeCSS:api(function(a,res){res();})};
 var al={},alEv=Ev();
 base.alarms={
  create:function(){var a=[].slice.call(arguments);var name='',info;if(typeof a[0]==='string'){name=a[0];info=a[1]||{};}else{info=a[0]||{};}
   if(al[name]){clearTimeout(al[name].t);clearInterval(al[name].i);}
   var d=info.when?Math.max(0,info.when-Date.now()):(info.delayInMinutes!=null?info.delayInMinutes*60000:(info.periodInMinutes||0)*60000);
   var rec={name:name,scheduledTime:Date.now()+d,periodInMinutes:info.periodInMinutes};al[name]=rec;
   function fire(){alEv._f({name:name,scheduledTime:Date.now(),periodInMinutes:info.periodInMinutes});}
   rec.t=setTimeout(function(){fire();if(info.periodInMinutes){rec.i=setInterval(fire,info.periodInMinutes*60000);}else delete al[name];},d);
   return Promise.resolve();},
  clear:api(function(a,res){var n=a[0]||'';var r=al[n];if(r){clearTimeout(r.t);clearInterval(r.i);delete al[n];res(true);}else res(false);}),
  clearAll:api(function(a,res){for(var n in al){clearTimeout(al[n].t);clearInterval(al[n].i);}al={};res(true);}),
  get:api(function(a,res){var r=al[a[0]||''];res(r?{name:r.name,scheduledTime:r.scheduledTime,periodInMinutes:r.periodInMinutes}:undefined);}),
  getAll:api(function(a,res){res(Object.keys(al).map(function(n){return{name:n,scheduledTime:al[n].scheduledTime,periodInMinutes:al[n].periodInMinutes};}));}),
  onAlarm:alEv};
 base.notifications={create:function(){var a=[].slice.call(arguments);var o=typeof a[0]==='string'?a[1]:a[0];var f=a[a.length-1];K.bildir((o&&o.title?o.title+': ':'')+((o&&o.message)||''));if(typeof f==='function')f('n');return Promise.resolve('n');},clear:function(){return Promise.resolve(true);},onClicked:Ev(),onClosed:Ev()};
 function ck(url){var d='';try{d=new URL(url).hostname;}catch(e){}return(K.cerezler(url)||'').split(';').map(function(x){x=x.trim();var i=x.indexOf('=');return i<0?null:{name:x.slice(0,i),value:x.slice(i+1),domain:d,path:'/',secure:true,httpOnly:false,session:true};}).filter(Boolean);}
 base.cookies={
  get:api(function(a,res){var o=a[0]||{};res(ck(o.url).filter(function(c){return c.name===o.name;})[0]||null);}),
  getAll:api(function(a,res){var o=a[0]||{};var l=o.url?ck(o.url):[];if(o.name)l=l.filter(function(c){return c.name===o.name;});res(l);}),
  set:api(function(a,res){var o=a[0]||{};K.cerezYaz(o.url,o.name+'='+(o.value||'')+'; path='+(o.path||'/'));res(o);}),
  remove:api(function(a,res){var o=a[0]||{};K.cerezYaz(o.url,o.name+'=; Max-Age=0; path=/');res(o);}),
  onChanged:Ev()};
 var of=window.fetch.bind(window);
 window.fetch=function(input,init){try{
  var req=(input&&typeof input==='object'&&input.url)?input:null;
  var url=req?req.url:String(input);
  var u=new URL(url,location.href);
  if(u.origin===location.origin||(u.protocol!=='http:'&&u.protocol!=='https:'))return of(input,init);
  init=init||{};
  var method=(init.method||(req&&req.method)||'GET').toUpperCase();
  var hd={};var h=init.headers||(req&&req.headers);
  if(h){if(typeof h.forEach==='function'&&!Array.isArray(h)){h.forEach(function(v,k){hd[k]=v;});}else if(Array.isArray(h)){h.forEach(function(p){hd[p[0]]=p[1];});}else{for(var k in h)hd[k]=h[k];}}
  var body=init.body;var bp;
  if(body==null)bp=Promise.resolve(null);
  else if(typeof body==='string')bp=Promise.resolve(body);
  else if(body instanceof URLSearchParams){if(!hd['Content-Type']&&!hd['content-type'])hd['Content-Type']='application/x-www-form-urlencoded;charset=UTF-8';bp=Promise.resolve(body.toString());}
  else if(body instanceof FormData)return of(input,init);
  else bp=new Response(body).text();
  return bp.then(function(b){
   if(typeof b==='string'&&method!=='GET'&&!hd['Content-Type']&&!hd['content-type'])hd['Content-Type']='text/plain;charset=UTF-8';
   return new Promise(function(res,rej){
    var id=cb(function(r){
     if(!r||r.err){rej(new TypeError('Failed to fetch'+(r&&r.err?': '+r.err:'')));return;}
     var bin=atob(r.b64||'');var arr=new Uint8Array(bin.length);for(var i=0;i<bin.length;i++)arr[i]=bin.charCodeAt(i);
     var nb=(r.status===204||r.status===205||r.status===304||method==='HEAD')?null:arr;
     try{res(new Response(nb,{status:r.status,statusText:r.st||'',headers:r.h||{}}));}catch(e){rej(e);}
    });
    K.fetch(id,u.href,JSON.stringify({method:method,headers:hd,body:b}));
   });
  });
 }catch(e){return of(input,init);}};
}
var chrome=new Proxy(base,{get:function(t,p){if(p in t)return t[p];if(typeof p==='symbol'||p==='then')return undefined;return stub();}});
window['__tzMk_'+S]=function(){return chrome;};
if(TUR!=='content'){
 try{Object.defineProperty(window,'chrome',{value:chrome,configurable:true,writable:true});}catch(e){window.chrome=chrome;}
 window.browser=chrome;
 window.close=function(){K.kapat();};
 if(TUR==='bg'){
  window.importScripts=function(){for(var i=0;i<arguments.length;i++){var x=new XMLHttpRequest();x.open('GET',new URL(arguments[i],location.href).href,false);x.send();(0,eval)(x.responseText);}};
  self.skipWaiting=function(){return Promise.resolve();};
  self.clients={claim:function(){return Promise.resolve();},matchAll:function(){return Promise.resolve([]);}};
  window.addEventListener('load',function(){
   // Gerçek Chrome'da chrome.storage.session, arka plan (service worker) her yeniden
   // başladığında sıfırlanır — eklentiler "şu an tarama/işlem sürüyor mu" gibi geçici
   // kilitleri bu varsayıma göre yazar. Bu Android katmanında 'session' alanı da 'local'
   // gibi KALICI depoya yazıldığından, arka plan WebView'i herhangi bir sebeple yeniden
   // yüklenirse (uygulama yeniden başlatma, bellek temizliği, masaüstü önceliği duraklatması
   // vb.) önceki oturumdan kalan bir kilit (örn. "tarama kilidi") saatlerce/günlerce askıda
   // kalıp yeni oturumdaki TÜM taramaları sessizce "zaten çalışıyor" diye engelleyebiliyordu.
   // Gerçek Chrome davranışını taklit etmek için her yeni oturumda session'ı temizliyoruz.
   try{K.depoTemizle('session');}catch(e){}
   var r=K.kurulum();if(r)ev_inst._f({reason:r});setTimeout(function(){ev_start._f();},0);
  });
 }else{
  document.addEventListener('DOMContentLoaded',function(){if(!document.querySelector('meta[name=viewport]')){var m=document.createElement('meta');m.name='viewport';m.content='width=device-width,initial-scale=1';document.head.appendChild(m);}});
 }
}else{
 try{delete window['@@N@@'];}catch(e){}
}
})();
"""
}
