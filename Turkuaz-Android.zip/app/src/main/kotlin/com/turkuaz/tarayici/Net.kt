package com.turkuaz.tarayici

import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

object Net {
    // Sunucu API'sine istek atar (arka plan iş parçacığında çağrılmalı). Hata olsa bile JSONObject döner.
    fun call(path: String, body: JSONObject?, token: String, surum: String): JSONObject {
        var conn: HttpURLConnection? = null
        try {
            val c = URL(Cfg.API + "/" + path).openConnection() as HttpURLConnection
            conn = c
            c.connectTimeout = 15000
            c.readTimeout = 20000
            c.requestMethod = if (body != null) "POST" else "GET"
            c.setRequestProperty("Content-Type", "application/json")
            c.setRequestProperty("X-Tarayici-Token", token)
            c.setRequestProperty("X-Tarayici-Surum", surum)
            if (body != null) {
                c.doOutput = true
                c.outputStream.use { os -> os.write(body.toString().toByteArray(Charsets.UTF_8)) }
            }
            val code = c.responseCode
            val stream = if (code in 200..299) c.inputStream else c.errorStream
            val text = if (stream != null) stream.bufferedReader().use { r -> r.readText() } else ""
            return try {
                val j = JSONObject(text)
                j.put("_kod", code)
                j
            } catch (e: Exception) {
                val j = JSONObject()
                j.put("ok", false)
                j.put("hata", "Sunucudan geçersiz yanıt ($code)")
                j
            }
        } catch (e: Exception) {
            val j = JSONObject()
            j.put("ok", false)
            j.put("hata", "Sunucuya ulaşılamadı")
            j.put("cevrimdisi", true)
            return j
        } finally {
            conn?.disconnect()
        }
    }

    fun bytes(u: String): ByteArray? {
        try {
            val c = URL(u).openConnection() as HttpURLConnection
            c.connectTimeout = 10000
            c.readTimeout = 15000
            if (c.responseCode != 200) return null
            return c.inputStream.use { it.readBytes() }
        } catch (e: Exception) {
            return null
        }
    }

    // Giriş yapmış kullanıcıya özel dosya indirir (eklenti paketi gibi)
    fun dosya(path: String, token: String, surum: String): ByteArray? {
        try {
            val c = URL(Cfg.API + "/" + path).openConnection() as HttpURLConnection
            c.connectTimeout = 15000
            c.readTimeout = 60000
            c.setRequestProperty("X-Tarayici-Token", token)
            c.setRequestProperty("X-Tarayici-Surum", surum)
            if (c.responseCode != 200) return null
            return c.inputStream.use { it.readBytes() }
        } catch (e: Exception) {
            return null
        }
    }
}
