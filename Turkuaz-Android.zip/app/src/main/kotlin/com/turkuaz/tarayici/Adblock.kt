package com.turkuaz.tarayici

import android.content.Context

object Adblock {
    private val hosts = HashSet<String>()

    fun load(ctx: Context) {
        try {
            ctx.assets.open("hosts.txt").bufferedReader().use { r ->
                for (line in r.readLines()) {
                    val t = line.trim().lowercase()
                    if (t.isNotEmpty() && !t.startsWith("#")) hosts.add(t)
                }
            }
        } catch (e: Exception) {
            // liste yoksa engelleme yapılmaz
        }
    }

    // Alan adı ya da üst alan adlarından biri listede ise engelle
    fun blocked(host: String?): Boolean {
        if (host == null) return false
        var h = host.lowercase()
        while (true) {
            if (hosts.contains(h)) return true
            val i = h.indexOf('.')
            if (i < 0) return false
            h = h.substring(i + 1)
        }
    }
}
