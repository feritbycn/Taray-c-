package com.turkuaz.tarayici

import android.app.Activity
import android.appwidget.AppWidgetManager
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.TextView
import org.json.JSONArray

/**
 * Ana ekrana widget eklenirken açılır: hangi eklentinin widget'ı olacağını sorar.
 * Kartlar sağa kaydırılarak gezilir, dokunulan eklentiye widget bağlanır.
 */
class WidgetSecActivity : Activity() {
    private var wid = AppWidgetManager.INVALID_APPWIDGET_ID

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        setResult(RESULT_CANCELED)
        wid = intent?.getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, AppWidgetManager.INVALID_APPWIDGET_ID)
            ?: AppWidgetManager.INVALID_APPWIDGET_ID
        if (wid == AppWidgetManager.INVALID_APPWIDGET_ID) { finish(); return }

        val p = getSharedPreferences("widget", 0)
        // Eklentinin kendi penceresindeki "widget" düğmesinden gelindiyse soru sormadan bağla
        val bekleyen = p.getString("bekleyen", "") ?: ""
        if (bekleyen.isNotEmpty()) {
            p.edit().remove("bekleyen").apply()
            bitir(bekleyen, false)
            return
        }

        val liste = JSONArray()
        for (x in EklentiWidget.listeAl(this)) liste.put(org.json.JSONObject().put("k", x.first).put("a", x.second))

        val kok = LinearLayout(this)
        kok.orientation = LinearLayout.VERTICAL
        kok.setBackgroundColor(Color.parseColor("#FFF4F6FA"))
        kok.setPadding(0, dp(40), 0, dp(24))

        val baslik = TextView(this)
        baslik.text = "Hangi eklentinin widget'ı eklensin?"
        baslik.textSize = 20f
        baslik.setTextColor(Color.parseColor("#FF111D30"))
        baslik.typeface = android.graphics.Typeface.DEFAULT_BOLD
        baslik.setPadding(dp(24), 0, dp(24), dp(6))
        kok.addView(baslik)

        val alt = TextView(this)
        alt.text = if (liste.length() > 1) "Sağa kaydırarak diğer eklentileri görebilirsin." else ""
        alt.textSize = 13f
        alt.setTextColor(Color.parseColor("#FF5B6B82"))
        alt.setPadding(dp(24), 0, dp(24), dp(20))
        kok.addView(alt)

        if (liste.length() == 0) {
            val t = TextView(this)
            t.text = "Pencereli eklenti bulunamadı. Turkuaz'ı bir kez açıp eklentilerin yüklenmesini bekleyin, sonra tekrar deneyin."
            t.textSize = 15f
            t.setTextColor(Color.parseColor("#FF111D30"))
            t.setPadding(dp(24), dp(12), dp(24), dp(12))
            kok.addView(t)
        } else {
            val hs = HorizontalScrollView(this)
            hs.isHorizontalScrollBarEnabled = false
            val sira = LinearLayout(this)
            sira.orientation = LinearLayout.HORIZONTAL
            sira.setPadding(dp(16), 0, dp(16), 0)
            val genislik = (resources.displayMetrics.widthPixels * 0.72f).toInt()
            for (i in 0 until liste.length()) {
                val o = liste.getJSONObject(i)
                val key = o.optString("k")
                val ad = o.optString("a")
                val kart = LinearLayout(this)
                kart.orientation = LinearLayout.VERTICAL
                kart.gravity = Gravity.CENTER
                val bg = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(Color.parseColor("#FF111D30"), Color.parseColor("#FF0B3A45")))
                bg.cornerRadius = dp(24).toFloat()
                kart.background = bg
                kart.setPadding(dp(20), dp(28), dp(20), dp(28))
                val harf = TextView(this)
                harf.text = if (ad.isNotEmpty()) ad.substring(0, 1).uppercase() else "?"
                harf.textSize = 30f
                harf.gravity = Gravity.CENTER
                harf.setTextColor(Color.parseColor("#FF111D30"))
                harf.typeface = android.graphics.Typeface.DEFAULT_BOLD
                val hb = GradientDrawable(); hb.shape = GradientDrawable.OVAL; hb.setColor(Color.parseColor("#FF1FD1C1"))
                harf.background = hb
                kart.addView(harf, LinearLayout.LayoutParams(dp(64), dp(64)))
                val ismi = TextView(this)
                ismi.text = ad
                ismi.textSize = 17f
                ismi.gravity = Gravity.CENTER
                ismi.setTextColor(Color.WHITE)
                ismi.typeface = android.graphics.Typeface.DEFAULT_BOLD
                ismi.setPadding(0, dp(14), 0, dp(6))
                kart.addView(ismi)
                val ek = TextView(this)
                ek.text = "Widget olarak ekle"
                ek.textSize = 12f
                ek.gravity = Gravity.CENTER
                ek.setTextColor(Color.parseColor("#FFB5C3D9"))
                kart.addView(ek)
                kart.setOnClickListener { bitir(key, true) }
                val lp = LinearLayout.LayoutParams(genislik, dp(190))
                lp.rightMargin = dp(12)
                sira.addView(kart, lp)
            }
            hs.addView(sira)
            kok.addView(hs, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))
        }

        val vazgec = TextView(this)
        vazgec.text = "Vazgeç"
        vazgec.textSize = 15f
        vazgec.gravity = Gravity.CENTER
        vazgec.setTextColor(Color.parseColor("#FF5B6B82"))
        vazgec.setPadding(0, dp(28), 0, dp(12))
        vazgec.setOnClickListener { finish() }
        kok.addView(vazgec)

        setContentView(kok)
    }

    private fun bitir(key: String, uygulamayiAc: Boolean) {
        EklentiWidget.bagla(this, wid, key)
        val r = Intent()
        r.putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, wid)
        setResult(RESULT_OK, r)
        if (uygulamayiAc) {
            // Görüntünün ilk kez alınması için eklenti penceresi bir kez açılır
            try {
                val i = Intent(this, MainActivity::class.java)
                i.action = "com.turkuaz.tarayici.EKLENTI"
                i.putExtra("ek", key)
                i.putExtra("wid", wid)
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                startActivity(i)
            } catch (e: Exception) { }
        }
        finish()
    }
}
