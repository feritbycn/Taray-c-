package com.turkuaz.tarayici

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONObject

class Store(ctx: Context) {
    private val sp: SharedPreferences = ctx.getSharedPreferences("turkuaz", Context.MODE_PRIVATE)

    fun str(k: String, d: String): String = sp.getString(k, d) ?: d
    fun put(k: String, v: String) { sp.edit().putString(k, v).apply() }
    fun bool(k: String, d: Boolean): Boolean = sp.getBoolean(k, d)
    fun putBool(k: String, v: Boolean) { sp.edit().putBoolean(k, v).apply() }

    fun arr(k: String): JSONArray {
        return try { JSONArray(str(k, "[]")) } catch (e: Exception) { JSONArray() }
    }
    fun putArr(k: String, a: JSONArray) { put(k, a.toString()) }

    fun obj(k: String): JSONObject? {
        val s = str(k, "")
        if (s.isEmpty()) return null
        return try { JSONObject(s) } catch (e: Exception) { null }
    }

    // ---- ayarlar ----
    var temaModu: String
        get() = str("temaModu", "sistem")
        set(v) { put("temaModu", v) }
    var takim: String
        get() = str("takim", "")
        set(v) { put("takim", v) }
    var webKoyu: Boolean
        get() = bool("webKoyu", false)
        set(v) { putBool("webKoyu", v) }
    var reklamEngel: Boolean
        get() = bool("reklamEngel", true)
        set(v) { putBool("reklamEngel", v) }
    var seritGoster: Boolean
        get() = bool("seritGoster2", true)
        set(v) { putBool("seritGoster2", v) }
    var token: String
        get() = str("token", "")
        set(v) { put("token", v) }
    var kullaniciAdi: String
        get() = str("kullaniciAdi", "")
        set(v) { put("kullaniciAdi", v) }
    var girisAtla: Boolean
        get() = bool("girisAtla", false)
        set(v) { putBool("girisAtla", v) }
    var vpnAcik: Boolean
        get() = bool("vpnAcik", false)
        set(v) { putBool("vpnAcik", v) }
    var vpnSecili: String
        get() = str("vpnSecili", "")
        set(v) { put("vpnSecili", v) }

    var aramaMotoru: String
        get() = str("aramaMotoru", "google")
        set(v) { put("aramaMotoru", v) }
    var anaSayfa: String
        get() = str("anaSayfa", "turkuaz://yeni")
        set(v) { put("anaSayfa", v) }
    var masaustuVarsayilan: Boolean
        get() = bool("masaustuVarsayilan", false)
        set(v) { putBool("masaustuVarsayilan", v) }
    var yaziBoyutu: Int
        get() = str("yaziBoyutu", "100").toIntOrNull() ?: 100
        set(v) { put("yaziBoyutu", v.toString()) }

    // ---- kisayollar ----
    fun apps(): JSONArray {
        val a = arr("apps")
        if (a.length() > 0) return a
        val d = JSONArray()
        d.put(app("WhatsApp", "https://web.whatsapp.com/", "#25D366", "W", true).put("ikon", "wp"))
        d.put(app("Telegram", "https://web.telegram.org/", "#229ED9", "T", false))
        d.put(app("Instagram", "https://www.instagram.com/", "#E1306C", "I", false))
        d.put(app("X", "https://x.com/", "#222222", "X", false))
        d.put(app("YouTube", "https://www.youtube.com/", "#FF0000", "Y", false))
        return d
    }
    private fun app(ad: String, url: String, renk: String, harf: String, masaustu: Boolean): JSONObject {
        val o = JSONObject()
        o.put("ad", ad); o.put("url", url); o.put("renk", renk); o.put("harf", harf); o.put("masaustu", masaustu)
        return o
    }

    // ---- yer imleri / gecmis ----
    fun bookmarks(): JSONArray = arr("yerimleri")
    fun isBookmarked(url: String): Boolean {
        val a = bookmarks()
        for (i in 0 until a.length()) if (a.getJSONObject(i).optString("u") == url) return true
        return false
    }
    fun toggleBookmark(title: String, url: String): Boolean {
        val a = bookmarks()
        val out = JSONArray()
        var found = false
        for (i in 0 until a.length()) {
            val o = a.getJSONObject(i)
            if (o.optString("u") == url) found = true else out.put(o)
        }
        if (!found) {
            val o = JSONObject()
            o.put("t", if (title.isEmpty()) url else title); o.put("u", url)
            out.put(o)
        }
        putArr("yerimleri", out)
        return !found
    }
    fun removeFrom(key: String, index: Int) {
        val a = arr(key)
        val out = JSONArray()
        for (i in 0 until a.length()) if (i != index) out.put(a.get(i))
        putArr(key, out)
    }

    fun history(): JSONArray = arr("gecmis")
    fun addHistory(title: String, url: String) {
        val a = history()
        if (a.length() > 0 && a.getJSONObject(0).optString("u") == url) return
        val out = JSONArray()
        val o = JSONObject()
        o.put("t", if (title.isEmpty()) url else title); o.put("u", url); o.put("d", System.currentTimeMillis())
        out.put(o)
        var i = 0
        while (i < a.length() && out.length() < 500) { out.put(a.get(i)); i++ }
        putArr("gecmis", out)
    }
}
