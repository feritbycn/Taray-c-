package com.turkuaz.tarayici

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder

/**
 * Uygulama arka plana alındığında (ana ekrana dönüldüğünde / başka uygulamaya geçildiğinde)
 * işlemi canlı tutmak için düşük öncelikli, kalıcı bir bildirimle süren ön plan (foreground)
 * servisi. Amaç: eklentilerin arka plan betiklerindeki chrome.alarms zamanlayıcıları ve genel
 * senkronizasyon, Android'in pil optimizasyonu/Doze kısıtlamaları yüzünden erken durdurulmasın.
 *
 * ÖNEMLİ SINIR (dürüstçe belirtilmeli): Bu servis yalnızca uygulamanın İŞLEMİNİ canlı tutar.
 * Kullanıcı uygulamayı "Son kullanılanlar" listesinden kaydırıp tamamen kapatırsa, Android
 * MainActivity'yi (ve onunla birlikte eklenti motorunun WebView'lerini) yine de yok eder — bu
 * servis o durumu kapsamaz. Tam "uygulama tamamen kapalıyken de çalışsın" davranışı, eklenti
 * motorunun Activity'den tamamen bağımsız bir yapıya taşınmasını gerektirir (ayrı, çok daha
 * büyük bir değişiklik).
 */
class EklentiServisi : Service() {
    companion object {
        const val KANAL = "eklenti_arkaplan"
        const val KANAL_BILDIRIM = "eklenti_bildirim"

        fun baslat(ctx: Context) {
            try { ctx.startForegroundService(Intent(ctx, EklentiServisi::class.java)) } catch (e: Exception) { }
        }

        fun durdur(ctx: Context) {
            try { ctx.stopService(Intent(ctx, EklentiServisi::class.java)) } catch (e: Exception) { }
        }
    }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        try {
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(NotificationChannel(KANAL, "Arka planda çalışma", NotificationManager.IMPORTANCE_MIN))
            val ac = PendingIntent.getActivity(
                this, 0,
                Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_NEW_TASK),
                PendingIntent.FLAG_IMMUTABLE
            )
            val n = Notification.Builder(this, KANAL)
                .setSmallIcon(R.drawable.ic_eklenti)
                .setContentTitle("Turkuaz arka planda çalışıyor")
                .setContentText("Eklentiler ve senkronizasyon açık kalırken sürüyor")
                .setContentIntent(ac)
                .setOngoing(true)
                .setVisibility(Notification.VISIBILITY_PUBLIC)
                .build()
            if (Build.VERSION.SDK_INT >= 34) {
                startForeground(78, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
            } else {
                startForeground(78, n)
            }
        } catch (e: Exception) {
            stopSelf()
        }
        return START_STICKY
    }
}
