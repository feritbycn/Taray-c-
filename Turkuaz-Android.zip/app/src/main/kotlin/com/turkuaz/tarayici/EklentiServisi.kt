package com.turkuaz.tarayici

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.wifi.WifiManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

/**
 * Uygulama arka plana alındığında veya "Son kullanılanlar"dan tamamen kapatıldığında bile
 * eklentilerin arka plan betiklerinin (chrome.alarms zamanlayıcıları, otomatik tarama/eşleştirme,
 * bildirimler) çalışmaya devam etmesi için düşük öncelikli, kalıcı bir bildirimle süren ön plan
 * (foreground) servisi.
 *
 * Bunu sağlamak için bu servis, MainActivity'nin kendi `motor` nesnesini KULLANMAZ — tamamen
 * BAĞIMSIZ, kendi `EklentiMotoru` örneğini oluşturur (bkz. `motorBaslat()`), Context olarak
 * Activity değil bu servisin kendisini kullanarak. Bu yüzden `EklentiMotoru`'nun Activity'ye
 * bağlı birkaç özelliği (popup penceresi, widget canlı önizlemesi) burada devreye girmez —
 * `EklentiMotoru` bunu kendi içinde güvenli şekilde atlıyor — ama arka plan sayfaları,
 * chrome.alarms, ağ istekleri ve bildirimler aynı şekilde çalışır. Jeton ve atanmış eklenti
 * listesi, uygulamanın en son MainActivity'deyken yazdığı kalıcı depodan (`Store`) okunur.
 *
 * Ekran/tuş kilidi kilitliyken Android, Wi-Fi radyosunu da düşük güç moduna alabiliyor; bu da
 * arka plandaki fetch() isteklerinin "Unable to resolve host" diye DNS hatası vermesine yol
 * açıyor. Bunu önlemek için servis çalışırken bir WakeLock (CPU uyanık) + WifiLock (Wi-Fi
 * radyosu tam güçte) tutuyoruz.
 *
 * SINIRLAR (dürüstçe belirtilmeli):
 * - Masaüstü önceliği (eklentiCalisabilir) bayrağı burada YENİDEN sorgulanmaz — servis yalnızca
 *   uygulama en son açıkken senkronize edilmiş son durumu kullanır; uygulama tamamen kapalıyken
 *   masaüstü sonradan açılırsa telefon bunu ancak uygulama bir sonraki açılışında fark eder.
 * - Android işletim sistemi yine de, pil tasarrufu çok agresif bir telefonda, bu servisi
 *   zorla durdurabilir — foreground servis + WakeLock + WifiLock, bunu engelleyen en güçlü
 *   araçlar ama %100 garanti değil, özellikle bazı telefon üreticilerinde (Xiaomi/Honor/
 *   Huawei/Oppo vb.) kendi pil yöneticilerinde uygulamayı ayrıca "Otomatik başlatma"/
 *   "Kısıtlama yok" listesine kullanıcının elle eklemesi gerekebilir — bu, uygulama koduyla
 *   değil yalnızca telefon ayarlarından çözülür.
 * - Gerçek bir cihazda test edilmedi; yalnızca kod incelemesiyle doğrulandı.
 */
class EklentiServisi : Service() {
    companion object {
        const val KANAL = "eklenti_arkaplan"
        const val KANAL_BILDIRIM = "eklenti_bildirim"

        fun baslat(ctx: Context) {
            try { ctx.startForegroundService(Intent(ctx, EklentiServisi::class.java)) } catch (e: Exception) { }
        }

        fun durdur(ctx: Context) {
            try { ctx.stopService(Intent(ctx, EklentiServisi::class.java)) } catch (e: Exception) { }
        }
    }

    private var uyanikTutucu: PowerManager.WakeLock? = null
    private var wifiTutucu: WifiManager.WifiLock? = null
    private var motor: EklentiMotoru? = null
    private val ui: Handler by lazy { Handler(Looper.getMainLooper()) }
    private val io: ExecutorService by lazy { Executors.newCachedThreadPool() }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        try {
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(NotificationChannel(KANAL, "Arka planda çalışma", NotificationManager.IMPORTANCE_MIN))
            val ac = PendingIntent.getActivity(
                this, 0,
                Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_NEW_TASK),
                PendingIntent.FLAG_IMMUTABLE
            )
            val n = Notification.Builder(this, KANAL)
                .setSmallIcon(R.drawable.ic_eklenti)
                .setContentTitle("Turkuaz arka planda çalışıyor")
                .setContentText("Eklentiler ve senkronizasyon açık kalırken sürüyor")
                .setContentIntent(ac)
                .setOngoing(true)
                .setVisibility(Notification.VISIBILITY_PUBLIC)
                .build()
            if (Build.VERSION.SDK_INT >= 34) {
                startForeground(78, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
            } else {
                startForeground(78, n)
            }
            tutucalariAl()
            motorBaslat()
        } catch (e: Exception) {
            stopSelf()
        }
        return START_STICKY
    }

    private fun motorBaslat() {
        if (motor != null) return
        try {
            val st = Store(applicationContext)
            if (st.token.isEmpty()) { stopSelf(); return }
            val eklentiler = st.arr("eklentiListe")
            if (eklentiler.length() == 0) { stopSelf(); return }
            val surum = try { packageManager.getPackageInfo(packageName, 0).versionName ?: "0.0.0" } catch (e: Exception) { "0.0.0" }
            val m = EklentiMotoru(
                applicationContext, ui, io,
                { st.token }, { surum },
                { emptyList() },
                { null },
                { },
                { _, _ -> },
                { emptyList() }
            )
            motor = m
            m.senkron(eklentiler)
        } catch (e: Exception) { }
    }

    private fun tutucalariAl() {
        try {
            if (uyanikTutucu == null) {
                val pm = getSystemService(Context.POWER_SERVICE) as? PowerManager
                uyanikTutucu = pm?.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "Turkuaz:eklentiCpu")
                uyanikTutucu?.setReferenceCounted(false)
            }
            // Süresiz tutuyoruz: servis zaten durdur()/onDestroy() ile düzgün bırakılıyor
            // (uygulama kapanınca, masaüstü önceliği devreye girince ya da eklenti kalmayınca).
            uyanikTutucu?.acquire()

            if (wifiTutucu == null) {
                val wm = applicationContext.getSystemService(Context.WIFI_SERVICE) as? WifiManager
                val tur = if (Build.VERSION.SDK_INT >= 29) WifiManager.WIFI_MODE_FULL_LOW_LATENCY else WifiManager.WIFI_MODE_FULL_HIGH_PERF
                wifiTutucu = wm?.createWifiLock(tur, "Turkuaz:eklentiWifi")
                wifiTutucu?.setReferenceCounted(false)
            }
            wifiTutucu?.acquire()
        } catch (e: Exception) { }
    }

    private fun tutucalariBirak() {
        try { if (uyanikTutucu?.isHeld == true) uyanikTutucu?.release() } catch (e: Exception) { }
        try { if (wifiTutucu?.isHeld == true) wifiTutucu?.release() } catch (e: Exception) { }
    }

    override fun onDestroy() {
        try { motor?.calismaDurumuAyarla(false) } catch (e: Exception) { }
        motor = null
        tutucalariBirak()
        super.onDestroy()
    }
}
