package com.turkuaz.tarayici

import android.graphics.Color

class Pal(
    val dark: Boolean,
    val page: Int,
    val bar: Int,
    val fg: Int,
    val muted: Int,
    val field: Int,
    val accent: Int,
    val takim: String?,
    val bandA: Int,
    val bandB: Int,
    val bandText: Int
)

object Themes {
    private val INK = Color.rgb(16, 17, 24)

    val TAKIMLAR: List<Array<String>> = listOf(
        arrayOf("galatasaray", "Galatasaray", "#A90432", "#FDB913", "#A90432", "#FDB913"),
        arrayOf("fenerbahce", "Fenerbahçe", "#0B1F5B", "#FFE000", "#0B1F5B", "#FFE000"),
        arrayOf("besiktas", "Beşiktaş", "#151515", "#FFFFFF", "#000000", "#3A3A3A"),
        arrayOf("trabzonspor", "Trabzonspor", "#7A1F3D", "#4FB3E8", "#7A1F3D", "#4FB3E8")
    )

    private fun lin(v: Int): Double {
        val s = v / 255.0
        return if (s <= 0.03928) s / 12.92 else Math.pow((s + 0.055) / 1.055, 2.4)
    }
    fun lum(c: Int): Double = 0.2126 * lin(Color.red(c)) + 0.7152 * lin(Color.green(c)) + 0.0722 * lin(Color.blue(c))
    fun contrast(a: Int, b: Int): Double {
        val la = lum(a)
        val lb = lum(b)
        return (Math.max(la, lb) + 0.05) / (Math.min(la, lb) + 0.05)
    }
    fun mix(a: Int, b: Int, t: Float): Int {
        val r = (Color.red(a) * (1 - t) + Color.red(b) * t).toInt()
        val g = (Color.green(a) * (1 - t) + Color.green(b) * t).toInt()
        val bl = (Color.blue(a) * (1 - t) + Color.blue(b) * t).toInt()
        return Color.rgb(r, g, bl)
    }
    fun textOn(bg: Int): Int = if (contrast(Color.WHITE, bg) >= contrast(INK, bg)) Color.WHITE else INK

    // fg, bg üzerinde yeterli kontrasta ulaşana kadar zıt renge kaydırılır (okunabilirlik)
    fun ensure(fg: Int, bg: Int, min: Double): Int {
        if (contrast(fg, bg) >= min) return fg
        val target = textOn(bg)
        var t = 0.1f
        while (t <= 1.0f) {
            val c = mix(fg, target, t)
            if (contrast(c, bg) >= min) return c
            t += 0.1f
        }
        return target
    }

    fun temel(dark: Boolean): Pal {
        return if (dark) Pal(
            true, Color.parseColor("#081615"), Color.parseColor("#0F2220"), Color.parseColor("#E8F6F4"),
            Color.parseColor("#8FB0AC"), Color.parseColor("#17302D"), Color.parseColor("#1FBFB1"),
            null, 0, 0, 0
        ) else Pal(
            false, Color.parseColor("#F4FBFA"), Color.parseColor("#FFFFFF"), Color.parseColor("#0D2422"),
            Color.parseColor("#587471"), Color.parseColor("#E6F3F1"), Color.parseColor("#0A9D93"),
            null, 0, 0, 0
        )
    }

    fun takim(id: String): Pal? {
        for (t in TAKIMLAR) {
            if (t[0] != id) continue
            val bg = Color.parseColor(t[2])
            val dark = contrast(Color.WHITE, bg) > contrast(Color.BLACK, bg)
            val fg = textOn(bg)
            val accent = ensure(Color.parseColor(t[3]), bg, 3.0)
            val page = if (dark) mix(bg, Color.BLACK, 0.35f) else mix(bg, Color.BLACK, 0.06f)
            val field = mix(bg, fg, if (dark) 0.12f else 0.07f)
            val muted = ensure(mix(fg, bg, 0.4f), bg, 3.0)
            val a = Color.parseColor(t[4])
            val b = Color.parseColor(t[5])
            val samples = intArrayOf(a, mix(a, b, 0.5f), b)
            var wScore = 99.0
            var iScore = 99.0
            for (s in samples) {
                wScore = Math.min(wScore, contrast(Color.WHITE, s))
                iScore = Math.min(iScore, contrast(INK, s))
            }
            val bandText = if (wScore >= iScore) Color.WHITE else INK
            return Pal(dark, page, bg, fg, muted, field, accent, t[1].uppercase(), a, b, bandText)
        }
        return null
    }
}
