package com.turkuaz.tarayici

import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Outline
import android.os.Handler
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.view.WindowManager
import android.webkit.WebView
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView

/**
 * Uygulamadan çıkınca videoyu, diğer uygulamaların üstünde sürüklenebilen küçük bir pencerede gösterir.
 * Video penceresi görünür kaldığı için sayfa "arka plan" sayılmaz; oynatma kesilmez.
 */
class MiniPencere(private val ctx: Context, private val ui: Handler) {
    private val wm = ctx.applicationContext.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private var kok: FrameLayout? = null
    private var web: WebView? = null
    private var p: WindowManager.LayoutParams? = null
    private var taniTv: TextView? = null

    fun yaz(t: String) { try { taniTv?.text = t } catch (e: Exception) { } }

    val acik: Boolean get() = kok != null

    private fun dp(v: Int): Int = (v * ctx.resources.displayMetrics.density).toInt()

    fun izinVar(): Boolean = try { Settings.canDrawOverlays(ctx) } catch (e: Exception) { false }

    fun ac(w: WebView, onGenislet: () -> Unit, onOynat: () -> Unit, onKapat: () -> Unit): Boolean {
        if (kok != null) return true
        if (!izinVar()) return false
        try {
            val gW = dp(264)
            val gH = dp(149)
            (w.parent as? ViewGroup)?.removeView(w)
            w.visibility = View.VISIBLE

            val k = FrameLayout(ctx)
            k.setBackgroundColor(Color.BLACK)
            k.outlineProvider = object : ViewOutlineProvider() {
                override fun getOutline(v: View, o: Outline) { o.setRoundRect(0, 0, v.width, v.height, dp(12).toFloat()) }
            }
            k.clipToOutline = true
            k.addView(w, FrameLayout.LayoutParams(gW, gH))

            // sürükleme + dokununca düğmeleri göster
            val tut = View(ctx)
            k.addView(tut, FrameLayout.LayoutParams(gW, gH))

            val bar = LinearLayout(ctx)
            bar.orientation = LinearLayout.HORIZONTAL
            bar.setBackgroundColor(0x99000000.toInt())
            bar.gravity = Gravity.CENTER
            fun dugme(t: String, f: () -> Unit) {
                val tv = TextView(ctx)
                tv.text = t
                tv.textSize = 18f
                tv.setTextColor(Color.WHITE)
                tv.gravity = Gravity.CENTER
                tv.setOnClickListener { f() }
                bar.addView(tv, LinearLayout.LayoutParams(0, dp(34), 1f))
            }
            dugme("⤢") { onGenislet() }
            dugme("⏯") { onOynat() }
            dugme("✕") { onKapat() }
            k.addView(bar, FrameLayout.LayoutParams(gW, dp(34), Gravity.TOP))
            if (Tani.acik) {
                val tt = TextView(ctx)
                tt.textSize = 6f
                tt.setTextColor(0xFF00FF88.toInt())
                tt.setBackgroundColor(0xAA000000.toInt())
                tt.typeface = android.graphics.Typeface.MONOSPACE
                k.addView(tt, FrameLayout.LayoutParams(gW, -2, Gravity.BOTTOM))
                taniTv = tt
            }
            val gizle = Runnable { bar.visibility = View.GONE }

            val dm = ctx.resources.displayMetrics
            val lp = WindowManager.LayoutParams(
                gW, gH,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT
            )
            lp.gravity = Gravity.TOP or Gravity.START
            lp.x = dm.widthPixels - gW - dp(10)
            lp.y = dm.heightPixels - gH - dp(150)

            var dx = 0f; var dy = 0f; var bx = 0; var by = 0; var hareket = false
            tut.setOnTouchListener { _, e ->
                when (e.actionMasked) {
                    MotionEvent.ACTION_DOWN -> { dx = e.rawX; dy = e.rawY; bx = lp.x; by = lp.y; hareket = false }
                    MotionEvent.ACTION_MOVE -> {
                        val mx = (e.rawX - dx).toInt(); val my = (e.rawY - dy).toInt()
                        if (Math.abs(mx) > dp(6) || Math.abs(my) > dp(6)) hareket = true
                        if (hareket) {
                            lp.x = (bx + mx).coerceIn(0, dm.widthPixels - gW)
                            lp.y = (by + my).coerceIn(0, dm.heightPixels - gH)
                            try { wm.updateViewLayout(k, lp) } catch (x: Exception) { }
                        }
                    }
                    MotionEvent.ACTION_UP -> if (!hareket) {
                        ui.removeCallbacks(gizle)
                        bar.visibility = View.VISIBLE
                        ui.postDelayed(gizle, 3000)
                    }
                }
                true
            }

            wm.addView(k, lp)
            kok = k; web = w; p = lp
            ui.postDelayed(gizle, 3000)

            // sayfada sadece video tüm pencereyi kaplasın
            for (d in longArrayOf(50, 300, 800, 1600)) ui.postDelayed({
                web?.evaluateJavascript(Cfg.PIP_ON_JS + "window.dispatchEvent(new Event('resize'));", null)
            }, d)
            return true
        } catch (e: Exception) {
            kok = null; web = null
            return false
        }
    }

    /** Pencereyi kapatır, içindeki WebView'i geri verir (ana ekrana yeniden eklemek çağırana ait). */
    fun kapat(): WebView? {
        val k = kok ?: return null
        val w = web
        try { wm.removeView(k) } catch (e: Exception) { }
        try { if (w != null) k.removeView(w) } catch (e: Exception) { }
        try { w?.evaluateJavascript(Cfg.PIP_OFF_JS, null) } catch (e: Exception) { }
        kok = null; web = null; p = null; taniTv = null
        return w
    }
}
