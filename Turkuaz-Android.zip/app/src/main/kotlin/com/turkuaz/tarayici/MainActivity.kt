package com.turkuaz.tarayici

import android.app.Activity
import android.app.AlertDialog
import android.app.DownloadManager
import android.content.Context
import android.content.Intent
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.content.res.ColorStateList
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import android.webkit.*
import android.widget.*
import androidx.webkit.ProxyConfig
import androidx.webkit.ProxyController
import androidx.webkit.WebViewCompat
import androidx.webkit.WebViewFeature
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.Executors

class Tab(val web: WebView) {
    var title: String = "Yeni sekme"
    var url: String = ""
    var masaustu: Boolean = false
}

class MainActivity : Activity() {
    companion object {
        fun paletteOf(ctx: Context, st: Store): Pal {
            if (st.takim.isNotEmpty()) Themes.takim(st.takim)?.let { return it }
            val sistemKoyu = (ctx.resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
            val koyu = when (st.temaModu) { "koyu" -> true; "acik" -> false; else -> sistemKoyu }
            return Themes.temel(koyu)
        }
        const val ANA = "https://www.google.com/"
    }

    private lateinit var st: Store
    private lateinit var pal: Pal
    private val io = Executors.newSingleThreadExecutor()
    private val ui = Handler(Looper.getMainLooper())
    private val tabs = ArrayList<Tab>()
    private var cur = -1
    private var surum = "0.0.0"

    private lateinit var rootView: LinearLayout
    private lateinit var band: TextView
    private lateinit var urlBar: EditText
    private lateinit var prog: ProgressBar
    private lateinit var holder: FrameLayout
    private lateinit var shortcuts: LinearLayout
    private lateinit var shortcutScroll: HorizontalScrollView
    private lateinit var banner: TextView
    private var tabBtn: Button? = null

    private var duyurular = JSONArray()
    private var vpnSunucular = JSONArray()

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        st = Store(this)
        Adblock.load(this)
        surum = try { packageManager.getPackageInfo(packageName, 0).versionName ?: "0.0.0" } catch (e: Exception) { "0.0.0" }
        pal = paletteOf(this, st)
        vpnSunucular = st.arr("vpnListe")
        kur()
        val link = intent?.data?.toString()
        yeniSekme(link ?: ANA)
        vpnUygula()
        if (st.token.isEmpty() && !st.girisAtla) girisGoster()
        senkron()
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    // ---------------- arayüz ----------------
    private fun kur() {
        window.statusBarColor = pal.bar
        window.navigationBarColor = pal.bar
        val lightBars = !pal.dark
        window.decorView.systemUiVisibility = if (lightBars && Build.VERSION.SDK_INT >= 26)
            View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        else if (lightBars) View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR else 0

        rootView = LinearLayout(this)
        rootView.orientation = LinearLayout.VERTICAL
        rootView.setBackgroundColor(pal.page)

        // takım bandı
        band = TextView(this)
        band.gravity = Gravity.CENTER
        band.textSize = 11f
        band.setTextColor(pal.bandText)
        if (pal.takim != null) {
            band.text = pal.takim
            val g = android.graphics.drawable.GradientDrawable(
                android.graphics.drawable.GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(pal.bandA, pal.bandB))
            band.background = g
            rootView.addView(band, LinearLayout.LayoutParams(-1, dp(18)))
        }

        // üst çubuk
        val top = LinearLayout(this)
        top.orientation = LinearLayout.HORIZONTAL
        top.setBackgroundColor(pal.bar)
        top.gravity = Gravity.CENTER_VERTICAL
        top.setPadding(dp(8), dp(6), dp(8), dp(6))

        urlBar = EditText(this)
        urlBar.setSingleLine()
        urlBar.hint = "Ara veya adres yaz"
        urlBar.setTextColor(pal.fg)
        urlBar.setHintTextColor(pal.muted)
        urlBar.setBackgroundColor(pal.field)
        urlBar.setPadding(dp(12), dp(8), dp(12), dp(8))
        urlBar.textSize = 14f
        urlBar.imeOptions = EditorInfo.IME_ACTION_GO
        urlBar.setOnEditorActionListener { _, _, _ -> git(urlBar.text.toString()); true }
        urlBar.setOnFocusChangeListener { _, f -> if (f) urlBar.selectAll() }
        top.addView(urlBar, LinearLayout.LayoutParams(0, -2, 1f))

        tabBtn = ikon("1") { sekmeler() }
        top.addView(tabBtn)
        top.addView(ikon("⋮") { menu() })
        rootView.addView(top, LinearLayout.LayoutParams(-1, -2))

        prog = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal)
        prog.max = 100
        prog.progressTintList = android.content.res.ColorStateList.valueOf(pal.accent)
        rootView.addView(prog, LinearLayout.LayoutParams(-1, dp(3)))

        banner = TextView(this)
        banner.setBackgroundColor(pal.accent)
        banner.setTextColor(Themes.textOn(pal.accent))
        banner.setPadding(dp(12), dp(8), dp(12), dp(8))
        banner.visibility = View.GONE
        rootView.addView(banner, LinearLayout.LayoutParams(-1, -2))

        holder = FrameLayout(this)
        rootView.addView(holder, LinearLayout.LayoutParams(-1, 0, 1f))

        // kısayol şeridi
        shortcutScroll = HorizontalScrollView(this)
        shortcutScroll.setBackgroundColor(pal.bar)
        shortcutScroll.isHorizontalScrollBarEnabled = false
        shortcuts = LinearLayout(this)
        shortcuts.orientation = LinearLayout.HORIZONTAL
        shortcuts.setPadding(dp(6), dp(4), dp(6), dp(4))
        shortcutScroll.addView(shortcuts)
        rootView.addView(shortcutScroll, LinearLayout.LayoutParams(-1, -2))
        kisayollariCiz()

        setContentView(rootView)
    }

    private fun ikon(t: String, f: () -> Unit): Button {
        val bt = Button(this)
        bt.text = t
        bt.setTextColor(pal.fg)
        bt.setBackgroundColor(Color.TRANSPARENT)
        bt.minWidth = dp(44)
        bt.minimumWidth = dp(44)
        bt.setOnClickListener { f() }
        return bt
    }

    private fun kisayollariCiz() {
        shortcuts.removeAllViews()
        shortcutScroll.visibility = if (st.seritGoster) View.VISIBLE else View.GONE
        val a = st.apps()
        for (i in 0 until a.length()) {
            val o = a.getJSONObject(i)
            val renk = try { Color.parseColor(o.optString("renk", "#0A9D93")) } catch (e: Exception) { pal.accent }
            val bg = GradientDrawable()
            bg.shape = GradientDrawable.OVAL
            bg.setColor(renk)
            val fl = FrameLayout(this)
            fl.background = bg
            fl.clipToOutline = true
            val tv = TextView(this)
            tv.text = o.optString("harf", "?")
            tv.gravity = Gravity.CENTER
            tv.textSize = 16f
            tv.setTextColor(Themes.textOn(renk))
            val iv = ImageView(this)
            iv.scaleType = ImageView.ScaleType.FIT_CENTER
            iv.setPadding(dp(7), dp(7), dp(7), dp(7))
            fl.addView(tv, FrameLayout.LayoutParams(-1, -1))
            fl.addView(iv, FrameLayout.LayoutParams(-1, -1))
            ikonYukle(o.optString("url"), iv, tv, bg)
            val lp = LinearLayout.LayoutParams(dp(42), dp(42))
            lp.setMargins(dp(6), dp(2), dp(6), dp(2))
            fl.setOnClickListener {
                val t = cur()
                if (t != null && (t.url.isEmpty() || t.url == ANA)) {
                    sekmeGit(t, o.optString("url"), o.optBoolean("masaustu", false))
                } else {
                    yeniSekme(o.optString("url"), o.optBoolean("masaustu", false))
                }
            }
            fl.setOnLongClickListener { Toast.makeText(this, o.optString("ad"), Toast.LENGTH_SHORT).show(); true }
            shortcuts.addView(fl, lp)
        }
    }

    // Sitenin gerçek logosunu indirip önbelleğe alır
    private fun ikonYukle(url: String, iv: ImageView, tv: TextView, bg: GradientDrawable) {
        val host = Uri.parse(url).host ?: return
        val f = java.io.File(filesDir, "ikon_" + host + ".png")
        io.execute {
            var bmp: Bitmap? = null
            try {
                if (f.exists() && f.length() > 0) bmp = BitmapFactory.decodeFile(f.path)
                if (bmp == null) {
                    val b = Net.bytes("https://www.google.com/s2/favicons?domain=" + host + "&sz=128")
                    if (b != null) {
                        bmp = BitmapFactory.decodeByteArray(b, 0, b.size)
                        if (bmp != null) f.writeBytes(b)
                    }
                }
            } catch (e: Exception) { }
            val r = bmp
            if (r != null) ui.post {
                iv.setImageBitmap(r)
                tv.visibility = View.GONE
                bg.setColor(Color.WHITE)
            }
        }
    }

    // ---------------- sekmeler ----------------
    private fun cur(): Tab? = if (cur in 0 until tabs.size) tabs[cur] else null

    private fun webOlustur(masaustu: Boolean): Tab {
        val w = WebView(this)
        val tab = Tab(w)
        tab.masaustu = masaustu
        val s = w.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = true
        s.databaseEnabled = true
        s.mediaPlaybackRequiresUserGesture = false
        s.setSupportMultipleWindows(true)
        s.javaScriptCanOpenWindowsAutomatically = true
        s.useWideViewPort = true
        s.loadWithOverviewMode = true
        s.builtInZoomControls = true
        s.displayZoomControls = false
        s.userAgentString = if (masaustu) Cfg.UA_MASAUSTU else Cfg.UA_MOBIL
        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(w, true)
        if (WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT)) {
            try {
                WebViewCompat.addDocumentStartJavaScript(w, Cfg.YT_JS, setOf("https://*.youtube.com"))
            } catch (e: Exception) { }
        }

        w.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(v: WebView, r: WebResourceRequest): WebResourceResponse? {
                if (st.reklamEngel && Adblock.blocked(r.url.host)) {
                    return WebResourceResponse("text/plain", "utf-8", java.io.ByteArrayInputStream(ByteArray(0)))
                }
                return null
            }
            override fun shouldOverrideUrlLoading(v: WebView, r: WebResourceRequest): Boolean {
                val u = r.url
                val sch = u.scheme ?: ""
                if (r.isForMainFrame && u.host == "accounts.google.com" && v.settings.userAgentString != Cfg.UA_FIREFOX) {
                    v.settings.userAgentString = Cfg.UA_FIREFOX
                    v.loadUrl(u.toString())
                    return true
                }
                if (sch == "http" || sch == "https" || sch == "about" || sch == "data" || sch == "blob") return false
                try {
                    val i = if (sch == "intent") Intent.parseUri(u.toString(), Intent.URI_INTENT_SCHEME) else Intent(Intent.ACTION_VIEW, u)
                    startActivity(i)
                } catch (e: Exception) { }
                return true
            }
            override fun onPageStarted(v: WebView, url: String, f: Bitmap?) {
                tab.url = url
                if (tab === cur()) urlBar.setText(url)
            }
            override fun onPageFinished(v: WebView, url: String) {
                tab.url = url
                tab.title = v.title ?: url
                val hh = Uri.parse(url).host ?: ""
                if (!hh.endsWith("google.com") && v.settings.userAgentString == Cfg.UA_FIREFOX) {
                    v.settings.userAgentString = if (tab.masaustu) Cfg.UA_MASAUSTU else Cfg.UA_MOBIL
                }
                if (tab === cur()) { urlBar.setText(url); prog.progress = 0 }
                if (url.startsWith("http")) st.addHistory(tab.title, url)
            }
            override fun onReceivedHttpAuthRequest(v: WebView, h: HttpAuthHandler, host: String?, realm: String?) {
                // Proxy (VPN) kimlik doğrulaması
                var kul = ""; var sif = ""
                for (i in 0 until vpnSunucular.length()) {
                    val o = vpnSunucular.getJSONObject(i)
                    if (o.optString("id") == st.vpnSecili) { kul = o.optString("kullanici"); sif = o.optString("sifre") }
                }
                if (st.vpnAcik && kul.isNotEmpty() && h.useHttpAuthUsernamePassword()) h.proceed(kul, sif) else h.cancel()
            }
        }
        w.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(v: WebView, p: Int) { if (tab === cur()) prog.progress = if (p >= 100) 0 else p }
            override fun onReceivedTitle(v: WebView, t: String?) { tab.title = t ?: tab.title }
            override fun onCreateWindow(v: WebView, d: Boolean, u: Boolean, msg: android.os.Message): Boolean {
                val nt = webOlustur(tab.masaustu)
                ekle(nt)
                val tr = msg.obj as WebView.WebViewTransport
                tr.webView = nt.web
                msg.sendToTarget()
                return true
            }
            override fun onPermissionRequest(r: PermissionRequest) { runOnUiThread { r.grant(r.resources) } }
            private var custom: View? = null
            private var customCb: CustomViewCallback? = null
            override fun onShowCustomView(v: View, cb: CustomViewCallback) {
                custom = v; customCb = cb
                holder.addView(v)
                for (t in tabs) t.web.visibility = View.GONE
                shortcutScroll.visibility = View.GONE
            }
            override fun onHideCustomView() {
                custom?.let { holder.removeView(it) }
                customCb?.onCustomViewHidden()
                custom = null
                cur()?.web?.visibility = View.VISIBLE
                kisayollariCiz()
            }
        }
        w.setDownloadListener { url, ua, cd, mime, _ ->
            try {
                val ad = URLUtil.guessFileName(url, cd, mime)
                val rq = DownloadManager.Request(Uri.parse(url))
                rq.setMimeType(mime)
                rq.addRequestHeader("User-Agent", ua)
                val ck = CookieManager.getInstance().getCookie(url)
                if (ck != null) rq.addRequestHeader("Cookie", ck)
                rq.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                rq.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, ad)
                (getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager).enqueue(rq)
                Toast.makeText(this, "İndiriliyor: $ad", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                Toast.makeText(this, "İndirilemedi", Toast.LENGTH_SHORT).show()
            }
        }
        return tab
    }

    private fun ekle(t: Tab) {
        tabs.add(t)
        holder.addView(t.web, FrameLayout.LayoutParams(-1, -1))
        sec(tabs.size - 1)
    }

    private fun yeniSekme(url: String, masaustu: Boolean = false) {
        val t = webOlustur(masaustu)
        ekle(t)
        t.web.loadUrl(url)
    }

    private fun sekmeGit(t: Tab, url: String, masaustu: Boolean) {
        if (t.masaustu != masaustu) {
            t.masaustu = masaustu
            t.web.settings.userAgentString = if (masaustu) Cfg.UA_MASAUSTU else Cfg.UA_MOBIL
        }
        t.web.loadUrl(url)
    }

    private fun sec(i: Int) {
        cur = i
        for ((k, t) in tabs.withIndex()) t.web.visibility = if (k == i) View.VISIBLE else View.GONE
        urlBar.setText(tabs[i].url)
        tabBtn?.text = tabs.size.toString()
    }

    private fun kapat(i: Int) {
        val t = tabs.removeAt(i)
        holder.removeView(t.web)
        t.web.destroy()
        if (tabs.isEmpty()) { yeniSekme(ANA); return }
        sec(Math.min(i, tabs.size - 1))
    }

    private fun sekmeler() {
        val isim = ArrayList<String>()
        for ((i, t) in tabs.withIndex()) isim.add((if (i == cur) "● " else "") + t.title)
        AlertDialog.Builder(this)
            .setTitle("Sekmeler (${tabs.size})")
            .setItems(isim.toTypedArray()) { _, i -> sec(i) }
            .setPositiveButton("Yeni sekme") { _, _ -> yeniSekme(ANA) }
            .setNegativeButton("Bu sekmeyi kapat") { _, _ -> kapat(cur) }
            .show()
    }

    private fun git(girdi: String) {
        val g = girdi.trim()
        if (g.isEmpty()) return
        val u: String = if (g.startsWith("http://") || g.startsWith("https://")) g
        else if (!g.contains(" ") && g.contains(".")) "https://$g"
        else "https://www.google.com/search?q=" + Uri.encode(g)
        cur()?.web?.loadUrl(u)
        urlBar.clearFocus()
        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as android.view.inputmethod.InputMethodManager
        imm.hideSoftInputFromWindow(urlBar.windowToken, 0)
    }

    // ---------------- menü ----------------
    private fun menu() {
        val t = cur()
        val d = android.app.Dialog(this)
        d.requestWindowFeature(android.view.Window.FEATURE_NO_TITLE)
        val kutu = LinearLayout(this)
        kutu.orientation = LinearLayout.VERTICAL
        val arka = GradientDrawable()
        arka.setColor(pal.bar)
        arka.cornerRadius = dp(18).toFloat()
        kutu.background = arka
        kutu.setPadding(0, dp(6), 0, dp(6))
        val sv = ScrollView(this)
        sv.addView(kutu)
        d.setContentView(sv)

        fun ayirac() {
            val v = View(this)
            v.setBackgroundColor(pal.field)
            val lp = LinearLayout.LayoutParams(-1, dp(1))
            lp.setMargins(dp(14), dp(4), dp(14), dp(4))
            kutu.addView(v, lp)
        }
        fun satir(ikon: String, ad: String, f: () -> Unit) {
            val r = LinearLayout(this)
            r.orientation = LinearLayout.HORIZONTAL
            r.gravity = Gravity.CENTER_VERTICAL
            r.setPadding(dp(18), dp(12), dp(18), dp(12))
            val ic = TextView(this); ic.text = ikon; ic.textSize = 18f; ic.setTextColor(pal.fg)
            ic.gravity = Gravity.CENTER
            val tx = TextView(this); tx.text = ad; tx.textSize = 16f; tx.setTextColor(pal.fg)
            r.addView(ic, LinearLayout.LayoutParams(dp(32), -2))
            val lp = LinearLayout.LayoutParams(0, -2, 1f); lp.leftMargin = dp(10)
            r.addView(tx, lp)
            r.setOnClickListener { d.dismiss(); f() }
            kutu.addView(r, LinearLayout.LayoutParams(-1, -2))
        }
        fun anahtar(ikon: String, ad: String, acik: Boolean, f: (Boolean) -> Unit) {
            val r = LinearLayout(this)
            r.orientation = LinearLayout.HORIZONTAL
            r.gravity = Gravity.CENTER_VERTICAL
            r.setPadding(dp(18), dp(6), dp(14), dp(6))
            val ic = TextView(this); ic.text = ikon; ic.textSize = 18f; ic.setTextColor(pal.fg)
            ic.gravity = Gravity.CENTER
            val tx = TextView(this); tx.text = ad; tx.textSize = 16f; tx.setTextColor(pal.fg)
            val cb = CheckBox(this)
            cb.isChecked = acik
            cb.buttonTintList = ColorStateList.valueOf(pal.accent)
            cb.setOnCheckedChangeListener { _, v -> f(v) }
            r.addView(ic, LinearLayout.LayoutParams(dp(32), -2))
            val lp = LinearLayout.LayoutParams(0, -2, 1f); lp.leftMargin = dp(10)
            r.addView(tx, lp)
            r.addView(cb)
            r.setOnClickListener { cb.toggle() }
            kutu.addView(r, LinearLayout.LayoutParams(-1, -2))
        }

        // üst ikon şeridi (geri, ileri, yer imi, indir, yenile)
        val ust = LinearLayout(this)
        ust.orientation = LinearLayout.HORIZONTAL
        ust.setPadding(dp(8), dp(2), dp(8), dp(2))
        fun ikonDugme(s: String, f: () -> Unit) {
            val b = TextView(this)
            b.text = s; b.textSize = 22f; b.gravity = Gravity.CENTER; b.setTextColor(pal.fg)
            b.setPadding(0, dp(10), 0, dp(10))
            b.setOnClickListener { d.dismiss(); f() }
            ust.addView(b, LinearLayout.LayoutParams(0, -2, 1f))
        }
        val imli = t != null && st.isBookmarked(t.url)
        ikonDugme("←") { cur()?.web?.let { if (it.canGoBack()) it.goBack() } }
        ikonDugme("→") { cur()?.web?.let { if (it.canGoForward()) it.goForward() } }
        ikonDugme(if (imli) "★" else "☆") {
            t?.let { val e = st.toggleBookmark(it.title, it.url); Toast.makeText(this, if (e) "Yer imi eklendi" else "Yer imi kaldırıldı", Toast.LENGTH_SHORT).show() }
        }
        ikonDugme("⬇") { startActivity(Intent(DownloadManager.ACTION_VIEW_DOWNLOADS)) }
        ikonDugme("⟳") { cur()?.web?.reload() }
        kutu.addView(ust, LinearLayout.LayoutParams(-1, -2))
        ayirac()

        satir("＋", "Yeni sekme") { yeniSekme(ANA) }
        satir("▣", "Sekmeler (${tabs.size})") { sekmeler() }
        ayirac()
        satir("🕘", "Geçmiş") { listeGoster("Geçmiş", "gecmis") }
        satir("★", "Yer imleri") { listeGoster("Yer imleri", "yerimleri") }
        satir("📝", "Notlarım") { startActivity(Intent(this, NotesActivity::class.java)) }
        satir("↗", "Paylaş") {
            t?.let {
                val i = Intent(Intent.ACTION_SEND)
                i.type = "text/plain"
                i.putExtra(Intent.EXTRA_TEXT, it.url)
                startActivity(Intent.createChooser(i, "Paylaş"))
            }
        }
        ayirac()
        anahtar("🖥", "Masaüstü sitesi", t?.masaustu == true) { v ->
            t?.let { sekmeGit(it, it.url.ifEmpty { ANA }, v) }
        }
        anahtar("🛡", "Reklam engelleyici", st.reklamEngel) { v -> st.reklamEngel = v; cur()?.web?.reload() }
        anahtar("⚡", "Kısayol şeridi", st.seritGoster) { v -> st.seritGoster = v; kisayollariCiz() }
        anahtar("🔒", "VPN", st.vpnAcik) { v -> vpnDegistir(v) }
        if (vpnSunucular.length() > 1) satir("🌍", "VPN sunucusu seç") { vpnMenu() }
        if (st.vpnAcik) satir("🔎", "VPN testi (IP ve ülke)") { yeniSekme("https://www.cloudflare.com/cdn-cgi/trace") }
        ayirac()
        satir("🎨", "Tema") { temaMenu() }
        satir("🔔", "Duyurular (${duyurular.length()})") { duyuruGoster() }
        if (st.token.isEmpty()) satir("👤", "Giriş yap") { girisGoster() }
        else {
            satir("🌐", "Siteye giriş yapmış olarak git") { sso() }
            satir("⎋", "Çıkış (${st.kullaniciAdi})") { cikis() }
        }

        d.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        val lp = d.window?.attributes
        if (lp != null) {
            lp.gravity = Gravity.TOP or Gravity.END
            lp.x = dp(8)
            lp.y = dp(56)
            lp.width = dp(300)
            lp.height = android.view.ViewGroup.LayoutParams.WRAP_CONTENT
            d.window?.attributes = lp
        }
        d.show()
    }

    private fun vpnDegistir(ac: Boolean) {
        if (!ac) { st.vpnAcik = false; vpnUygula(); cur()?.web?.reload(); return }
        if (!WebViewFeature.isFeatureSupported(WebViewFeature.PROXY_OVERRIDE)) {
            Toast.makeText(this, "Bu cihazın WebView sürümü VPN'i desteklemiyor", Toast.LENGTH_LONG).show(); return
        }
        if (vpnSunucular.length() == 0) {
            Toast.makeText(this, if (st.token.isEmpty()) "VPN için giriş yapın" else "Size atanmış VPN sunucusu yok", Toast.LENGTH_LONG).show(); return
        }
        var var_ok = false
        for (i in 0 until vpnSunucular.length()) if (vpnSunucular.getJSONObject(i).optString("id") == st.vpnSecili) var_ok = true
        if (!var_ok) st.vpnSecili = vpnSunucular.getJSONObject(0).optString("id")
        st.vpnAcik = true
        vpnUygula()
        cur()?.web?.reload()
        Toast.makeText(this, "VPN açıldı", Toast.LENGTH_SHORT).show()
    }

    private fun listeGoster(baslik: String, key: String) {
        val a = st.arr(key)
        if (a.length() == 0) { Toast.makeText(this, "Boş", Toast.LENGTH_SHORT).show(); return }
        val n = Math.min(a.length(), 200)
        val isim = Array(n) { a.getJSONObject(it).optString("t") }
        AlertDialog.Builder(this).setTitle(baslik)
            .setItems(isim) { _, i -> cur()?.web?.loadUrl(a.getJSONObject(i).optString("u")) }
            .setNeutralButton("Temizle") { _, _ -> st.putArr(key, JSONArray()) }
            .setNegativeButton("Kapat", null)
            .show()
    }

    private fun temaMenu() {
        val ad = ArrayList<String>(); val id = ArrayList<String>()
        ad.add("Sistem"); id.add("sistem")
        ad.add("Açık"); id.add("acik")
        ad.add("Koyu"); id.add("koyu")
        for (t in Themes.TAKIMLAR) { ad.add(t[1]); id.add("takim:" + t[0]) }
        AlertDialog.Builder(this).setTitle("Tema")
            .setItems(ad.toTypedArray()) { _, i ->
                val v = id[i]
                if (v.startsWith("takim:")) st.takim = v.substring(6) else { st.takim = ""; st.temaModu = v }
                recreate()
            }.show()
    }

    // ---------------- VPN ----------------
    private fun vpnMenu() {
        if (!WebViewFeature.isFeatureSupported(WebViewFeature.PROXY_OVERRIDE)) {
            Toast.makeText(this, "Bu cihazın WebView sürümü VPN'i desteklemiyor", Toast.LENGTH_LONG).show(); return
        }
        if (vpnSunucular.length() == 0) {
            Toast.makeText(this, if (st.token.isEmpty()) "VPN için giriş yapın" else "Size atanmış VPN sunucusu yok", Toast.LENGTH_LONG).show(); return
        }
        val isim = ArrayList<String>()
        isim.add("Kapat")
        for (i in 0 until vpnSunucular.length()) isim.add(vpnSunucular.getJSONObject(i).optString("ad"))
        AlertDialog.Builder(this).setTitle("VPN")
            .setItems(isim.toTypedArray()) { _, i ->
                if (i == 0) st.vpnAcik = false
                else { st.vpnAcik = true; st.vpnSecili = vpnSunucular.getJSONObject(i - 1).optString("id") }
                vpnUygula()
                cur()?.web?.reload()
            }.show()
    }

    private fun vpnUygula() {
        if (!WebViewFeature.isFeatureSupported(WebViewFeature.PROXY_OVERRIDE)) return
        val ex = java.util.concurrent.Executor { r -> ui.post(r) }
        if (!st.vpnAcik) { ProxyController.getInstance().clearProxyOverride(ex) { }; return }
        var hedef: JSONObject? = null
        for (i in 0 until vpnSunucular.length()) {
            val o = vpnSunucular.getJSONObject(i)
            if (o.optString("id") == st.vpnSecili) hedef = o
        }
        if (hedef == null) return
        val sch = when (hedef.optString("tur")) { "socks5" -> "socks5"; "http" -> "http"; else -> "https" }
        val kural = "$sch://${hedef.optString("host")}:${hedef.optInt("port")}"
        try {
            val cfg = ProxyConfig.Builder().addProxyRule(kural).build()
            ProxyController.getInstance().setProxyOverride(cfg, ex) { }
        } catch (e: Exception) {
            Toast.makeText(this, "VPN ayarlanamadı", Toast.LENGTH_SHORT).show()
        }
    }

    // ---------------- hesap / sunucu ----------------
    private fun girisGoster() {
        val lay = LinearLayout(this)
        lay.orientation = LinearLayout.VERTICAL
        lay.setPadding(dp(20), dp(8), dp(20), 0)
        val k = EditText(this); k.hint = "Kullanıcı adı veya e-posta"; k.setSingleLine()
        val s = EditText(this); s.hint = "Şifre"; s.setSingleLine()
        s.inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD
        lay.addView(k); lay.addView(s)
        AlertDialog.Builder(this).setTitle("Turkuaz hesabı")
            .setView(lay)
            .setPositiveButton("Giriş") { _, _ ->
                val body = JSONObject()
                body.put("kullanici", k.text.toString()); body.put("sifre", s.text.toString())
                body.put("cihaz", "Android " + Build.MODEL); body.put("surum", surum)
                io.execute {
                    val r = Net.call("giris.php", body, "", surum)
                    ui.post {
                        if (r.optBoolean("ok")) {
                            st.token = r.optString("token")
                            st.kullaniciAdi = r.optJSONObject("kullanici")?.optString("ad") ?: ""
                            Toast.makeText(this, "Giriş yapıldı", Toast.LENGTH_SHORT).show()
                            senkron()
                        } else Toast.makeText(this, r.optString("hata", "Giriş başarısız"), Toast.LENGTH_LONG).show()
                    }
                }
            }
            .setNegativeButton("Şimdi değil") { _, _ -> st.girisAtla = true }
            .show()
    }

    private fun cikis() {
        val t = st.token
        io.execute { Net.call("cikis.php", JSONObject(), t, surum) }
        st.token = ""; st.kullaniciAdi = ""; st.vpnAcik = false
        vpnSunucular = JSONArray(); duyurular = JSONArray(); st.putArr("vpnListe", JSONArray())
        vpnUygula()
        Toast.makeText(this, "Çıkış yapıldı", Toast.LENGTH_SHORT).show()
    }

    private fun sso() {
        val t = st.token
        io.execute {
            val r = Net.call("sso_bilet.php", JSONObject(), t, surum)
            ui.post {
                if (r.optBoolean("ok")) yeniSekme(r.optString("url"))
                else Toast.makeText(this, r.optString("hata", "Başarısız"), Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun senkron() {
        ui.removeCallbacks(tick)
        ui.postDelayed(tick, Cfg.SYNC_MS)
        val t = st.token
        if (t.isEmpty()) return
        io.execute {
            val r = Net.call("esitle.php", null, t, surum)
            ui.post {
                if (r.optInt("_kod") == 401 || r.optInt("_kod") == 403) {
                    st.token = ""; st.vpnAcik = false; vpnSunucular = JSONArray(); st.putArr("vpnListe", JSONArray()); vpnUygula(); return@post
                }
                if (!r.optBoolean("ok")) return@post
                duyurular = r.optJSONArray("duyurular") ?: JSONArray()
                val v = r.optJSONObject("vpn")
                vpnSunucular = v?.optJSONArray("sunucular") ?: JSONArray()
                st.putArr("vpnListe", vpnSunucular)
                if (st.vpnAcik && vpnSunucular.length() == 0) st.vpnAcik = false
                vpnUygula()
                st.kullaniciAdi = r.optJSONObject("kullanici")?.optString("ad") ?: st.kullaniciAdi
                val apk = r.optJSONObject("apk")
                if (apk != null && yeniMi(apk.optString("son"), surum)) {
                    banner.text = "Yeni sürüm ${apk.optString("son")} hazır — güncellemek için dokunun"
                    banner.visibility = View.VISIBLE
                    val link = apk.optString("indir")
                    banner.setOnClickListener {
                        startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(link)))
                    }
                } else banner.visibility = View.GONE
            }
        }
    }
    private val tick = Runnable { senkron() }

    private fun yeniMi(a: String, b: String): Boolean {
        val x = a.split(".").map { it.toIntOrNull() ?: 0 }
        val y = b.split(".").map { it.toIntOrNull() ?: 0 }
        for (i in 0 until Math.max(x.size, y.size)) {
            val p = x.getOrElse(i) { 0 }; val q = y.getOrElse(i) { 0 }
            if (p != q) return p > q
        }
        return false
    }

    private fun duyuruGoster() {
        if (duyurular.length() == 0) { Toast.makeText(this, "Duyuru yok", Toast.LENGTH_SHORT).show(); return }
        val n = duyurular.length()
        val isim = Array(n) { duyurular.getJSONObject(it).optString("baslik") }
        AlertDialog.Builder(this).setTitle("Duyurular")
            .setItems(isim) { _, i ->
                val d = duyurular.getJSONObject(i)
                val ab = AlertDialog.Builder(this).setTitle(d.optString("baslik")).setMessage(d.optString("aciklama"))
                    .setNegativeButton("Kapat", null)
                if (d.optString("link").startsWith("http")) ab.setPositiveButton("Aç") { _, _ -> yeniSekme(d.optString("link")) }
                ab.show()
                val tk = st.token
                val body = JSONObject(); body.put("id", d.optInt("id"))
                io.execute { Net.call("okundu.php", body, tk, surum) }
            }.setNegativeButton("Kapat", null).show()
    }

    // ---------------- sistem ----------------
    override fun onKeyDown(code: Int, e: KeyEvent): Boolean {
        if (code == KeyEvent.KEYCODE_BACK) {
            val t = cur()
            if (t != null && t.web.canGoBack()) { t.web.goBack(); return true }
            if (tabs.size > 1) { kapat(cur); return true }
        }
        return super.onKeyDown(code, e)
    }

    override fun onNewIntent(i: Intent) {
        super.onNewIntent(i)
        i.data?.toString()?.let { yeniSekme(it) }
    }

    override fun onResume() { super.onResume(); tabs.forEach { it.web.onResume() } }
    override fun onPause() { super.onPause(); CookieManager.getInstance().flush() }
    override fun onDestroy() { ui.removeCallbacks(tick); super.onDestroy() }
}
