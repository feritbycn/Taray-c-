package com.turkuaz.tarayici

import android.app.Activity
import android.app.AlertDialog
import android.app.DownloadManager
import android.content.Context
import android.content.Intent
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.content.res.ColorStateList
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import android.webkit.*
import android.widget.*
import android.view.ViewGroup
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import androidx.webkit.ProxyConfig
import androidx.webkit.ProxyController
import androidx.webkit.WebViewCompat
import androidx.webkit.WebViewFeature
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.Executors

class Tab(val web: WebView) {
    var thumb: Bitmap? = null
    var title: String = "Yeni sekme"
    var url: String = ""
    var masaustu: Boolean = false
    var oto: Boolean = false
}

class MainActivity : Activity() {
    companion object {
        fun paletteOf(ctx: Context, st: Store): Pal {
            if (st.takim.isNotEmpty()) Themes.takim(st.takim)?.let { return it }
            val sistemKoyu = (ctx.resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
            val koyu = when (st.temaModu) { "koyu" -> true; "acik" -> false; else -> sistemKoyu }
            return Themes.temel(koyu)
        }
    }

    private lateinit var st: Store
    private val ANA: String get() = st.anaSayfa
    private lateinit var pal: Pal
    private val io = Executors.newSingleThreadExecutor()
    private val ui = Handler(Looper.getMainLooper())
    private val tabs = ArrayList<Tab>()
    private var cur = -1
    private var surum = "0.0.0"

    private lateinit var rootView: LinearLayout
    private lateinit var band: TextView
    private lateinit var urlBar: EditText
    private lateinit var prog: ProgressBar
    private lateinit var holder: FrameLayout
    private lateinit var refresh: SwipeRefreshLayout
    private lateinit var shortcuts: LinearLayout
    private lateinit var shortcutScroll: HorizontalScrollView
    private lateinit var okIc: ImageView
    private lateinit var okKapV: View
    private lateinit var banner: TextView
    private var tabBtn: Button? = null

    private var duyurular = JSONArray()
    private var vpnSunucular = JSONArray()
    private var eklentiler = JSONArray()
    private lateinit var motor: EklentiMotoru
    private lateinit var oneriScroll: ScrollView
    private lateinit var oneriKutu: LinearLayout
    private lateinit var bulKutu: LinearLayout
    private lateinit var bulEdit: EditText
    private lateinit var bulSay: TextView
    private lateinit var ekAlan: LinearLayout
    private lateinit var vpnKalkan: FrameLayout
    private lateinit var vpnKalkanIc: ImageView
    private lateinit var vpnKalkanYazi: TextView
    private val rtcScript = HashMap<WebView, androidx.webkit.ScriptHandler>()

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        st = Store(this)
        Cfg.uaKur(this)
        Adblock.load(this)
        surum = try { packageManager.getPackageInfo(packageName, 0).versionName ?: "0.0.0" } catch (e: Exception) { "0.0.0" }
        pal = paletteOf(this, st)
        vpnSunucular = st.arr("vpnListe")
        eklentiler = st.arr("eklentiListe")
        motor = EklentiMotoru(this, ui, io, { st.token }, { surum },
            { tabs.mapIndexed { i, t -> SekmeBilgi(System.identityHashCode(t.web), t.url, t.title, i == cur) } },
            { id -> tabs.firstOrNull { System.identityHashCode(it.web) == id }?.web },
            { u -> yeniSekme(u) },
            { id, u -> tabs.firstOrNull { System.identityHashCode(it.web) == id }?.let { sekmeGit(it, u, it.masaustu) } },
            { tabs.map { it.web } })
        kur()
        motor.dinleyici = { ekCiz() }
        motor.yerelYukle()
        val link = intent?.data?.toString()
        yeniSekme(link ?: ANA)
        vpnUygula()
        motor.senkron(eklentiler)
        if (st.token.isEmpty() && !st.girisAtla) girisGoster()
        senkron()
        ui.postDelayed({ ekIntent(intent) }, 600)
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    // ---------------- arayüz ----------------
    private fun kur() {
        window.statusBarColor = pal.bar
        window.navigationBarColor = pal.bar
        val lightBars = !pal.dark
        window.decorView.systemUiVisibility = if (lightBars && Build.VERSION.SDK_INT >= 26)
            View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        else if (lightBars) View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR else 0

        rootView = LinearLayout(this)
        rootView.orientation = LinearLayout.VERTICAL
        rootView.setBackgroundColor(pal.page)

        // takım bandı
        band = TextView(this)
        band.gravity = Gravity.CENTER
        band.textSize = 11f
        band.setTextColor(pal.bandText)
        if (pal.takim != null) {
            band.text = pal.takim
            val g = android.graphics.drawable.GradientDrawable(
                android.graphics.drawable.GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(pal.bandA, pal.bandB))
            band.background = g
            rootView.addView(band, LinearLayout.LayoutParams(-1, dp(18)))
        }

        // üst çubuk
        val top = LinearLayout(this)
        top.orientation = LinearLayout.HORIZONTAL
        top.setBackgroundColor(pal.bar)
        top.gravity = Gravity.CENTER_VERTICAL
        top.setPadding(dp(8), dp(6), dp(8), dp(6))

        urlBar = EditText(this)
        urlBar.setSingleLine()
        urlBar.hint = "Ara veya adres yaz"
        urlBar.setTextColor(pal.fg)
        urlBar.setHintTextColor(pal.muted)
        urlBar.setBackgroundColor(pal.field)
        urlBar.setPadding(dp(12), dp(8), dp(12), dp(8))
        urlBar.textSize = 14f
        urlBar.imeOptions = EditorInfo.IME_ACTION_GO
        urlBar.setOnEditorActionListener { _, _, _ -> git(urlBar.text.toString()); true }
        urlBar.setOnFocusChangeListener { _, f -> if (f) { urlBar.selectAll(); oneriler("") } else oneriGizle() }
        urlBar.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: android.text.Editable?) {
                if (urlBar.hasFocus()) oneriler(s?.toString() ?: "")
            }
        })
        top.addView(urlBar, LinearLayout.LayoutParams(0, -2, 1f))

        vpnKalkan = FrameLayout(this)
        vpnKalkanIc = ImageView(this)
        vpnKalkanIc.setImageResource(R.drawable.ic_kalkan)
        vpnKalkan.addView(vpnKalkanIc, FrameLayout.LayoutParams(dp(32), dp(32), Gravity.CENTER))
        vpnKalkanYazi = TextView(this)
        vpnKalkanYazi.text = "VPN"
        vpnKalkanYazi.textSize = 7.5f
        vpnKalkanYazi.setTypeface(null, android.graphics.Typeface.BOLD)
        vpnKalkanYazi.gravity = Gravity.CENTER
        val kyl = FrameLayout.LayoutParams(-2, -2, Gravity.CENTER)
        kyl.bottomMargin = dp(1)
        vpnKalkan.addView(vpnKalkanYazi, kyl)
        vpnKalkan.setOnClickListener {
            vpnDegistir(!st.vpnAcik)
            vpnCiz()
        }
        top.addView(vpnKalkan, LinearLayout.LayoutParams(dp(40), dp(40)))
        vpnCiz()

        ekAlan = LinearLayout(this)
        ekAlan.orientation = LinearLayout.HORIZONTAL
        top.addView(ekAlan, LinearLayout.LayoutParams(-2, -2))
        val ekB = ImageView(this)
        ekB.setImageResource(R.drawable.ic_eklenti)
        ekB.setColorFilter(pal.fg)
        ekB.setPadding(dp(8), dp(8), dp(8), dp(8))
        ekB.setOnClickListener { eklentiGoster() }
        top.addView(ekB, LinearLayout.LayoutParams(dp(40), dp(40)))

        tabBtn = ikon("1") { sekmeler() }
        tabBtn?.let { b ->
            val cg = GradientDrawable(); cg.setColor(Color.TRANSPARENT); cg.cornerRadius = dp(8).toFloat(); cg.setStroke(dp(2), pal.fg)
            b.background = cg
            b.minWidth = 0; b.minimumWidth = 0; b.minHeight = 0; b.minimumHeight = 0
            b.setPadding(0, 0, 0, 0)
            b.textSize = 13f
            val lp = LinearLayout.LayoutParams(dp(32), dp(32))
            lp.setMargins(dp(6), 0, dp(4), 0)
            top.addView(b, lp)
        }
        top.addView(ikon("⋮") { menu() })
        rootView.addView(top, LinearLayout.LayoutParams(-1, -2))

        prog = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal)
        prog.max = 100
        prog.progressTintList = android.content.res.ColorStateList.valueOf(pal.accent)
        rootView.addView(prog, LinearLayout.LayoutParams(-1, dp(3)))

        // şeridi açıp kapatan modern düğme (yuvarlak hap + ok)
        val okKap = FrameLayout(this)
        okKap.setBackgroundColor(pal.bar)
        val hap = LinearLayout(this)
        hap.orientation = LinearLayout.HORIZONTAL
        hap.gravity = Gravity.CENTER_VERTICAL
        hap.setPadding(dp(12), 0, dp(14), 0)
        val hapBg = GradientDrawable()
        hapBg.setColor(pal.field)
        hapBg.cornerRadius = dp(16).toFloat()
        hap.background = hapBg
        okIc = ImageView(this)
        okIc.setImageResource(R.drawable.ic_ok)
        okIc.setColorFilter(pal.accent)
        hap.addView(okIc, LinearLayout.LayoutParams(dp(18), dp(18)))
        val okYaz = TextView(this)
        okYaz.text = "Kısayollar"
        okYaz.textSize = 12.5f
        okYaz.setTextColor(pal.fg)
        okYaz.typeface = android.graphics.Typeface.DEFAULT_BOLD
        val yl = LinearLayout.LayoutParams(-2, -2)
        yl.leftMargin = dp(4)
        hap.addView(okYaz, yl)
        okKap.addView(hap, FrameLayout.LayoutParams(-2, dp(28), Gravity.CENTER))
        okKapV = okKap
        okKap.setOnClickListener { seritAyarla(!st.seritGoster, true) }
        hap.setOnClickListener { seritAyarla(!st.seritGoster, true) }
        rootView.addView(okKap, LinearLayout.LayoutParams(-1, dp(36)))

        // adres çubuğunun altındaki kısayol / yer imi şeridi
        shortcutScroll = HorizontalScrollView(this)
        shortcutScroll.setBackgroundColor(pal.bar)
        shortcutScroll.isHorizontalScrollBarEnabled = false
        shortcuts = LinearLayout(this)
        shortcuts.orientation = LinearLayout.HORIZONTAL
        shortcuts.setPadding(dp(6), dp(2), dp(6), dp(2))
        shortcutScroll.addView(shortcuts)
        rootView.addView(shortcutScroll, LinearLayout.LayoutParams(-1, 0))

        banner = TextView(this)
        banner.setBackgroundColor(pal.accent)
        banner.setTextColor(Themes.textOn(pal.accent))
        banner.setPadding(dp(12), dp(8), dp(12), dp(8))
        banner.visibility = View.GONE
        rootView.addView(banner, LinearLayout.LayoutParams(-1, -2))

        holder = FrameLayout(this)
        refresh = SwipeRefreshLayout(this)
        refresh.addView(holder, ViewGroup.LayoutParams(-1, -1))
        refresh.setColorSchemeColors(pal.accent)
        refresh.setProgressBackgroundColorSchemeColor(pal.bar)
        // Sayfa en üstteyken aşağı çekince yenile; WhatsApp/Telegram gibi iç kaydırmalı sitelerde kapalı
        refresh.setOnChildScrollUpCallback { _, _ ->
            val t = cur()
            val h = Uri.parse(t?.url ?: "").host ?: ""
            if (t == null) true
            else if (h.contains("whatsapp") || h.contains("telegram")) true
            else t.web.canScrollVertically(-1)
        }
        refresh.setOnRefreshListener {
            cur()?.web?.reload()
            ui.postDelayed({ refresh.isRefreshing = false }, 2500)
        }
        val govde = FrameLayout(this)
        govde.addView(refresh, FrameLayout.LayoutParams(-1, -1))
        oneriKutu = LinearLayout(this)
        oneriKutu.orientation = LinearLayout.VERTICAL
        oneriScroll = ScrollView(this)
        val oBg = GradientDrawable()
        oBg.setColor(pal.bar)
        oBg.cornerRadius = dp(16).toFloat()
        oBg.setStroke(dp(1), pal.field)
        oneriScroll.background = oBg
        oneriScroll.clipToOutline = true
        oneriScroll.elevation = dp(10).toFloat()
        oneriScroll.visibility = View.GONE
        oneriScroll.addView(oneriKutu)
        val oLp = FrameLayout.LayoutParams(-1, -2)
        oLp.setMargins(dp(8), dp(4), dp(8), 0)
        govde.addView(oneriScroll, oLp)

        bulKutu = LinearLayout(this)
        bulKutu.orientation = LinearLayout.HORIZONTAL
        bulKutu.gravity = Gravity.CENTER_VERTICAL
        val bBg = GradientDrawable()
        bBg.setColor(pal.bar); bBg.cornerRadius = dp(16).toFloat(); bBg.setStroke(dp(1), pal.field)
        bulKutu.background = bBg
        bulKutu.elevation = dp(10).toFloat()
        bulKutu.setPadding(dp(14), dp(4), dp(6), dp(4))
        bulKutu.visibility = View.GONE
        bulEdit = EditText(this)
        bulEdit.hint = "Sayfada bul"
        bulEdit.setHintTextColor(pal.muted)
        bulEdit.setTextColor(pal.fg)
        bulEdit.setSingleLine()
        bulEdit.background = null
        bulEdit.imeOptions = EditorInfo.IME_ACTION_SEARCH
        bulSay = TextView(this)
        bulSay.setTextColor(pal.muted); bulSay.textSize = 12f
        fun bulDugme(res: Int, rot: Float, f: () -> Unit) {
            val iv = ImageView(this)
            iv.setImageResource(res); iv.setColorFilter(pal.fg); iv.rotation = rot
            iv.setPadding(dp(10), dp(10), dp(10), dp(10))
            iv.setOnClickListener { f() }
            bulKutu.addView(iv, LinearLayout.LayoutParams(dp(42), dp(42)))
        }
        bulKutu.addView(bulEdit, LinearLayout.LayoutParams(0, -2, 1f))
        bulKutu.addView(bulSay, LinearLayout.LayoutParams(-2, -2))
        bulDugme(R.drawable.ic_geri, 90f) { cur()?.web?.findNext(false) }
        bulDugme(R.drawable.ic_geri, -90f) { cur()?.web?.findNext(true) }
        bulDugme(R.drawable.ic_kapat, 0f) { bulKapat() }
        bulEdit.addTextChangedListener(object : android.text.TextWatcher {
            override fun afterTextChanged(e: android.text.Editable?) {
                val q = e?.toString() ?: ""
                if (q.isEmpty()) { cur()?.web?.clearMatches(); bulSay.text = "" } else cur()?.web?.findAllAsync(q)
            }
            override fun beforeTextChanged(a: CharSequence?, b: Int, c: Int, d: Int) {}
            override fun onTextChanged(a: CharSequence?, b: Int, c: Int, d: Int) {}
        })
        bulEdit.setOnEditorActionListener { _, _, _ -> cur()?.web?.findNext(true); true }
        val bLp = FrameLayout.LayoutParams(-1, -2)
        bLp.setMargins(dp(8), dp(4), dp(8), 0)
        govde.addView(bulKutu, bLp)
        rootView.addView(govde, LinearLayout.LayoutParams(-1, 0, 1f))

        kisayollariCiz()
        seritAyarla(st.seritGoster, false)

        setContentView(rootView)
    }

    private fun ikon(t: String, f: () -> Unit): Button {
        val bt = Button(this)
        bt.text = t
        bt.setTextColor(pal.fg)
        bt.setBackgroundColor(Color.TRANSPARENT)
        bt.minWidth = dp(44)
        bt.minimumWidth = dp(44)
        bt.setOnClickListener { f() }
        return bt
    }

    // Adres çubuğunun altındaki şeridi açar / kapatır
    private fun seritAyarla(ac: Boolean, anim: Boolean) {
        st.seritGoster = ac
        if (anim) okIc.animate().rotation(if (ac) 180f else 0f).setDuration(220).start()
        else okIc.rotation = if (ac) 180f else 0f
        val lp = shortcutScroll.layoutParams
        val hedef = if (ac) dp(76) else 0
        if (!anim) {
            lp.height = hedef
            shortcutScroll.layoutParams = lp
            return
        }
        val va = android.animation.ValueAnimator.ofInt(lp.height, hedef)
        va.duration = 220
        va.addUpdateListener {
            lp.height = it.animatedValue as Int
            shortcutScroll.layoutParams = lp
        }
        va.start()
    }

    private fun kisayollariCiz() {
        shortcuts.removeAllViews()

        fun oge(renk: Int, harf: String, ad: String, url: String, tikla: () -> Unit, uzun: (() -> Unit)?, ikonAd: String = "") {
            val kol = LinearLayout(this)
            kol.orientation = LinearLayout.VERTICAL
            kol.gravity = Gravity.CENTER_HORIZONTAL
            val bg = GradientDrawable()
            bg.shape = GradientDrawable.OVAL
            bg.setColor(renk)
            val fl = FrameLayout(this)
            fl.background = bg
            fl.clipToOutline = true
            val tv = TextView(this)
            tv.text = harf
            tv.gravity = Gravity.CENTER
            tv.textSize = 16f
            tv.setTextColor(Themes.textOn(renk))
            fl.addView(tv, FrameLayout.LayoutParams(-1, -1))
            val rid = if (ikonAd.isNotEmpty()) resources.getIdentifier(ikonAd, "drawable", packageName) else 0
            if (rid != 0) {
                bg.setColor(Color.TRANSPARENT)
                tv.visibility = View.GONE
                val iv = ImageView(this)
                iv.scaleType = ImageView.ScaleType.FIT_CENTER
                iv.setImageResource(rid)
                fl.addView(iv, FrameLayout.LayoutParams(-1, -1))
            } else if (url.startsWith("http")) {
                val iv = ImageView(this)
                iv.scaleType = ImageView.ScaleType.FIT_CENTER
                iv.setPadding(dp(7), dp(7), dp(7), dp(7))
                fl.addView(iv, FrameLayout.LayoutParams(-1, -1))
                ikonYukle(url, iv, tv, bg)
            }
            kol.addView(fl, LinearLayout.LayoutParams(dp(42), dp(42)))
            val lb = TextView(this)
            lb.text = ad
            lb.textSize = 10f
            lb.maxLines = 1
            lb.ellipsize = android.text.TextUtils.TruncateAt.END
            lb.gravity = Gravity.CENTER
            lb.setTextColor(pal.muted)
            kol.addView(lb, LinearLayout.LayoutParams(dp(56), -2))
            kol.setPadding(dp(4), dp(4), dp(4), dp(2))
            kol.setOnClickListener { tikla() }
            if (uzun != null) kol.setOnLongClickListener { uzun(); true }
            shortcuts.addView(kol, LinearLayout.LayoutParams(dp(64), -2))
        }

        // 1) Bu sayfayı yer imine ekle / kaldır
        val t0 = cur()
        val imli = t0 != null && st.isBookmarked(t0.url)
        oge(pal.accent, if (imli) "★" else "☆", if (imli) "Kayıtlı" else "Ekle", "", {
            val t = cur()
            if (t != null && t.url.startsWith("http")) {
                val e = st.toggleBookmark(t.title, t.url)
                Toast.makeText(this, if (e) "Yer imi eklendi" else "Yer imi kaldırıldı", Toast.LENGTH_SHORT).show()
                kisayollariCiz()
            }
        }, null)

        // 2) Hazır kısayollar (WhatsApp vb.)
        val a = st.apps()
        for (i in 0 until a.length()) {
            val o = a.getJSONObject(i)
            val renk = try { Color.parseColor(o.optString("renk", "#0A9D93")) } catch (e: Exception) { pal.accent }
            oge(renk, o.optString("harf", "?"), o.optString("ad"), o.optString("url"), {
                val t = cur()
                if (t != null && (t.url.isEmpty() || t.url == ANA)) sekmeGit(t, o.optString("url"), o.optBoolean("masaustu", false))
                else yeniSekme(o.optString("url"), o.optBoolean("masaustu", false))
            }, null, o.optString("ikon"))
        }

        // 3) Yer imleri
        val yi = st.bookmarks()
        for (i in 0 until yi.length()) {
            val o = yi.getJSONObject(i)
            val bas = o.optString("t")
            val url = o.optString("u")
            val ad = if (bas.isNotEmpty()) bas else (Uri.parse(url).host ?: url)
            oge(pal.field, ad.take(1).uppercase(), ad, url, {
                cur()?.web?.loadUrl(url)
            }, {
                AlertDialog.Builder(this).setTitle(ad)
                    .setMessage("Yer imi kaldırılsın mı?")
                    .setPositiveButton("Kaldır") { _, _ -> st.toggleBookmark(ad, url); kisayollariCiz() }
                    .setNegativeButton("Vazgeç", null).show()
            })
        }
    }

    // Sitenin gerçek logosunu indirip önbelleğe alır
    private fun ikonYukle(url: String, iv: ImageView, tv: TextView, bg: GradientDrawable) {
        val host = Uri.parse(url).host ?: return
        val f = java.io.File(filesDir, "ikon_" + host + ".png")
        io.execute {
            var bmp: Bitmap? = null
            try {
                if (f.exists() && f.length() > 0) bmp = BitmapFactory.decodeFile(f.path)
                if (bmp == null) {
                    val b = Net.bytes("https://www.google.com/s2/favicons?domain=" + host + "&sz=128")
                    if (b != null) {
                        bmp = BitmapFactory.decodeByteArray(b, 0, b.size)
                        if (bmp != null) f.writeBytes(b)
                    }
                }
            } catch (e: Exception) { }
            val r = bmp
            if (r != null) ui.post {
                iv.setImageBitmap(r)
                tv.visibility = View.GONE
                bg.setColor(Color.WHITE)
            }
        }
    }

    // ---------------- sekmeler ----------------
    private fun cur(): Tab? = if (cur in 0 until tabs.size) tabs[cur] else null

    private fun webOlustur(masaustu: Boolean): Tab {
        val w = WebView(this)
        val tab = Tab(w)
        tab.masaustu = masaustu
        val s = w.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = true
        s.databaseEnabled = true
        s.mediaPlaybackRequiresUserGesture = false
        s.setSupportMultipleWindows(true)
        s.javaScriptCanOpenWindowsAutomatically = true
        s.useWideViewPort = true
        s.loadWithOverviewMode = true
        s.builtInZoomControls = true
        s.displayZoomControls = false
        s.userAgentString = if (masaustu) Cfg.UA_MASAUSTU else Cfg.UA_MOBIL
        s.textZoom = st.yaziBoyutu
        koyuUygula(w)
        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(w, true)
        motor.sekmeBagla(w)
        if (WebViewFeature.isFeatureSupported(WebViewFeature.WEB_MESSAGE_LISTENER)) {
            try {
                WebViewCompat.addWebMessageListener(w, "TzNtp", setOf("https://turkuaz.local")) { _, m, _, _, _ ->
                    val tx = m.data
                    if (tx != null) ui.post { ntpMesaj(tx) }
                }
            } catch (e: Exception) { }
        }
        if (WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT)) {
            try {
                WebViewCompat.addDocumentStartJavaScript(w, Cfg.YT_JS, setOf("https://*.youtube.com"))
                WebViewCompat.addDocumentStartJavaScript(w, Cfg.CHROME_JS, setOf("*"))
                WebViewCompat.addDocumentStartJavaScript(w, Cfg.MASA_JS, setOf("*"))
                if (st.vpnAcik) rtcAyarla(w, true)
            } catch (e: Exception) { }
        }

        w.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(v: WebView, r: WebResourceRequest): WebResourceResponse? {
                if (st.reklamEngel && Adblock.blocked(r.url.host)) {
                    return WebResourceResponse("text/plain", "utf-8", java.io.ByteArrayInputStream(ByteArray(0)))
                }
                return null
            }
            override fun shouldOverrideUrlLoading(v: WebView, r: WebResourceRequest): Boolean {
                val u = r.url
                val sch = u.scheme ?: ""
                if (r.isForMainFrame && (sch == "http" || sch == "https") && otoMasa(tab, u.host ?: "")) {
                    v.loadUrl(u.toString())
                    return true
                }
                if (r.isForMainFrame && u.host == "accounts.google.com" && v.settings.userAgentString != Cfg.UA_FIREFOX) {
                    v.settings.userAgentString = Cfg.UA_FIREFOX
                    v.loadUrl(u.toString())
                    return true
                }
                if (sch == "http" || sch == "https" || sch == "about" || sch == "data" || sch == "blob") return false
                try {
                    val i = if (sch == "intent") Intent.parseUri(u.toString(), Intent.URI_INTENT_SCHEME) else Intent(Intent.ACTION_VIEW, u)
                    startActivity(i)
                } catch (e: Exception) { }
                return true
            }
            override fun onPageStarted(v: WebView, url: String, f: Bitmap?) {
                tab.url = if (url.startsWith(Ntp.BASE)) "" else url
                if (tab === cur()) urlBar.setText(tab.url)
            }
            override fun onPageFinished(v: WebView, url0: String) {
                val ntp = url0.startsWith(Ntp.BASE)
                val url = if (ntp) "" else url0
                tab.url = url
                tab.title = if (ntp) "Yeni sekme" else (v.title ?: url)
                val hh = Uri.parse(url).host ?: ""
                if (!hh.endsWith("google.com") && v.settings.userAgentString == Cfg.UA_FIREFOX) {
                    v.settings.userAgentString = if (tab.masaustu) Cfg.UA_MASAUSTU else Cfg.UA_MOBIL
                }
                if (tab === cur()) { urlBar.setText(url); prog.progress = 0; refresh.isRefreshing = false }
                if (url.startsWith("http")) st.addHistory(tab.title, url)
                if (tab === cur()) { if (st.seritGoster) kisayollariCiz(); ui.postDelayed({ yakala(tab) }, 700) }
            }
            override fun onReceivedHttpAuthRequest(v: WebView, h: HttpAuthHandler, host: String?, realm: String?) {
                // Proxy (VPN) kimlik doğrulaması
                var kul = ""; var sif = ""
                for (i in 0 until vpnSunucular.length()) {
                    val o = vpnSunucular.getJSONObject(i)
                    if (o.optString("id") == st.vpnSecili) { kul = o.optString("kullanici"); sif = o.optString("sifre") }
                }
                if (st.vpnAcik && kul.isNotEmpty() && h.useHttpAuthUsernamePassword()) h.proceed(kul, sif) else h.cancel()
            }
        }
        w.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(v: WebView, p: Int) { if (tab === cur()) prog.progress = if (p >= 100) 0 else p }
            override fun onReceivedTitle(v: WebView, t: String?) { tab.title = t ?: tab.title }
            override fun onCreateWindow(v: WebView, d: Boolean, u: Boolean, msg: android.os.Message): Boolean {
                val nt = webOlustur(tab.masaustu)
                ekle(nt)
                val tr = msg.obj as WebView.WebViewTransport
                tr.webView = nt.web
                msg.sendToTarget()
                return true
            }
            override fun onPermissionRequest(r: PermissionRequest) { runOnUiThread { r.grant(r.resources) } }
            private var custom: View? = null
            private var customCb: CustomViewCallback? = null
            override fun onShowCustomView(v: View, cb: CustomViewCallback) {
                custom = v; customCb = cb
                holder.addView(v)
                for (t in tabs) t.web.visibility = View.GONE
                shortcutScroll.visibility = View.GONE
                okKapV.visibility = View.GONE
            }
            override fun onHideCustomView() {
                custom?.let { holder.removeView(it) }
                customCb?.onCustomViewHidden()
                custom = null
                cur()?.web?.visibility = View.VISIBLE
                shortcutScroll.visibility = View.VISIBLE
                okKapV.visibility = View.VISIBLE

            }
        }
        w.setDownloadListener { url, ua, cd, mime, _ ->
            try {
                val ad = URLUtil.guessFileName(url, cd, mime)
                val rq = DownloadManager.Request(Uri.parse(url))
                rq.setMimeType(mime)
                rq.addRequestHeader("User-Agent", ua)
                val ck = CookieManager.getInstance().getCookie(url)
                if (ck != null) rq.addRequestHeader("Cookie", ck)
                rq.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                rq.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, ad)
                (getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager).enqueue(rq)
                Toast.makeText(this, "İndiriliyor: $ad", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                Toast.makeText(this, "İndirilemedi", Toast.LENGTH_SHORT).show()
            }
        }
        return tab
    }

    private fun ekle(t: Tab) {
        tabs.add(t)
        holder.addView(t.web, FrameLayout.LayoutParams(-1, -1))
        sec(tabs.size - 1)
    }

    private fun yeniSekme(url: String, masaustu0: Boolean = false) {
        val masaustu = masaustu0 || st.masaustuVarsayilan
        val t = webOlustur(masaustu)
        ekle(t)
        yukle(t, url)
    }

    private fun bulAc() {
        val t = cur() ?: return
        bulKutu.visibility = View.VISIBLE
        t.web.setFindListener { aktif, say, _ ->
            ui.post { bulSay.text = if (say == 0) (if (bulEdit.text.isEmpty()) "" else "0/0") else "${aktif + 1}/$say" }
        }
        bulEdit.requestFocus()
        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as android.view.inputmethod.InputMethodManager
        imm.showSoftInput(bulEdit, 0)
    }

    private fun bulKapat() {
        bulKutu.visibility = View.GONE
        cur()?.web?.clearMatches()
        bulEdit.setText("")
        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as android.view.inputmethod.InputMethodManager
        imm.hideSoftInputFromWindow(bulEdit.windowToken, 0)
    }

    private fun koyuUygula(w: WebView) {
        try {
            if (WebViewFeature.isFeatureSupported(WebViewFeature.ALGORITHMIC_DARKENING)) {
                androidx.webkit.WebSettingsCompat.setAlgorithmicDarkeningAllowed(w.settings, st.webKoyu)
            }
        } catch (e: Exception) { }
        try {
            if (Build.VERSION.SDK_INT < 33) {
                @Suppress("DEPRECATION")
                w.settings.forceDark = if (st.webKoyu) android.webkit.WebSettings.FORCE_DARK_ON else android.webkit.WebSettings.FORCE_DARK_OFF
            }
        } catch (e: Exception) { }
    }

    private fun cevir() {
        val t = cur() ?: return
        if (!t.url.startsWith("http")) { Toast.makeText(this, "Çevrilecek bir sayfa açık değil", Toast.LENGTH_SHORT).show(); return }
        t.web.loadUrl("https://translate.google.com/translate?sl=auto&tl=tr&u=" + Uri.encode(t.url))
    }

    private fun sayfaKisayol() {
        val t = cur() ?: return
        if (!t.url.startsWith("http")) { Toast.makeText(this, "Önce bir sayfa aç", Toast.LENGTH_SHORT).show(); return }
        try {
            val sm = getSystemService(android.content.pm.ShortcutManager::class.java)
            if (sm == null || !sm.isRequestPinShortcutSupported) {
                Toast.makeText(this, "Ana ekran kısayol eklemeyi desteklemiyor", Toast.LENGTH_LONG).show(); return
            }
            val ad = (if (t.title.isNotEmpty()) t.title else (Uri.parse(t.url).host ?: "Sayfa")).take(24)
            val bmp = Bitmap.createBitmap(192, 192, Bitmap.Config.ARGB_8888)
            val c = android.graphics.Canvas(bmp)
            val p = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG)
            p.color = pal.accent
            c.drawCircle(96f, 96f, 96f, p)
            p.color = Themes.textOn(pal.accent); p.textSize = 100f; p.textAlign = android.graphics.Paint.Align.CENTER
            c.drawText(ad.take(1).uppercase(), 96f, 96f + 35f, p)
            val i = Intent(this, MainActivity::class.java)
            i.action = Intent.ACTION_VIEW
            i.data = Uri.parse(t.url)
            val si = android.content.pm.ShortcutInfo.Builder(this, "sf_" + t.url.hashCode())
                .setShortLabel(ad).setLongLabel(ad).setIcon(android.graphics.drawable.Icon.createWithBitmap(bmp)).setIntent(i).build()
            sm.requestPinShortcut(si, null)
        } catch (e: Exception) {
            Toast.makeText(this, "Kısayol eklenemedi", Toast.LENGTH_LONG).show()
        }
    }

    // Kendi siten (turkuazads.com) masaüstü düzeniyle açılır: menü, ay, zil gibi düğmeler görünsün
    private fun otoMasa(t: Tab, host: String): Boolean {
        val site = host == "turkuazads.com" || host.endsWith(".turkuazads.com")
        if (site && !t.masaustu) {
            t.masaustu = true; t.oto = true
            t.web.settings.userAgentString = Cfg.UA_MASAUSTU
            return true
        }
        if (!site && t.oto && t.masaustu && !st.masaustuVarsayilan) {
            t.masaustu = false; t.oto = false
            t.web.settings.userAgentString = Cfg.UA_MOBIL
            return true
        }
        return false
    }

    private fun yukle(t: Tab, url: String) {
        if (url == Ntp.ISARET || url.isEmpty()) {
            if (WebViewFeature.isFeatureSupported(WebViewFeature.WEB_MESSAGE_LISTENER)) {
                t.url = ""
                t.title = "Yeni sekme"
                t.web.loadDataWithBaseURL(Ntp.BASE, Ntp.html(st, pal), "text/html", "utf-8", null)
                if (t === cur()) urlBar.setText("")
                return
            }
            t.web.loadUrl("https://www.google.com/")
            return
        }
        if (url.startsWith("http")) otoMasa(t, Uri.parse(url).host ?: "")
        t.web.loadUrl(url)
    }

    private fun ntpMesaj(msg: String) {
        try {
            val o = JSONObject(msg)
            when (o.optString("a")) {
                "git" -> git(o.optString("q"))
                "ac" -> { val u = o.optString("u"); if (u.startsWith("http")) cur()?.web?.loadUrl(u) }
                "ses" -> sesliAra()
                "gecmis" -> listeGoster("Geçmiş", "gecmis")
                "yerimi" -> listeGoster("Yer imleri", "yerimleri")
            }
        } catch (e: Exception) { }
    }

    private fun sesliAra() {
        try {
            val i = Intent(android.speech.RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            i.putExtra(android.speech.RecognizerIntent.EXTRA_LANGUAGE_MODEL, android.speech.RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            i.putExtra(android.speech.RecognizerIntent.EXTRA_LANGUAGE, "tr-TR")
            startActivityForResult(i, 4711)
        } catch (e: Exception) {
            Toast.makeText(this, "Sesli arama bu cihazda desteklenmiyor", Toast.LENGTH_LONG).show()
        }
    }

    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        if (req == 4712 && res == RESULT_OK && data?.data != null) {
            Toast.makeText(this, "Eklenti ekleniyor…", Toast.LENGTH_SHORT).show()
            motor.yerelEkle(data.data!!) { ad ->
                if (ad != null) Toast.makeText(this, "Eklendi: $ad", Toast.LENGTH_LONG).show()
                else Toast.makeText(this, "Eklenemedi: " + motor.sonHata, Toast.LENGTH_LONG).show()
            }
        }
        if (req == 4711 && res == RESULT_OK) {
            val l = data?.getStringArrayListExtra(android.speech.RecognizerIntent.EXTRA_RESULTS)
            if (l != null && l.isNotEmpty()) git(l[0])
        }
    }

    private fun sekmeGit(t: Tab, url: String, masaustu: Boolean) {
        if (t.masaustu != masaustu) {
            t.masaustu = masaustu
            t.web.settings.userAgentString = if (masaustu) Cfg.UA_MASAUSTU else Cfg.UA_MOBIL
        }
        yukle(t, url)
    }

    private fun sec(i: Int) {
        cur()?.let { yakala(it) }
        cur = i
        for ((k, t) in tabs.withIndex()) t.web.visibility = if (k == i) View.VISIBLE else View.GONE
        urlBar.setText(tabs[i].url)
        tabBtn?.text = tabs.size.toString()
    }

    private fun kapat(i: Int) {
        val t = tabs.removeAt(i)
        holder.removeView(t.web)
        motor.sekmeKapandi(t.web)
        rtcScript.remove(t.web)
        t.web.destroy()
        if (tabs.isEmpty()) { yeniSekme(ANA); return }
        sec(Math.min(i, tabs.size - 1))
    }

    // Sekmenin küçük resmini alır (sekme ızgarası için)
    private fun yakala(t: Tab) {
        try {
            val w = t.web
            if (w.width <= 0 || w.height <= 0 || w.visibility != View.VISIBLE) return
            val hedefW = 420
            val sc = hedefW.toFloat() / w.width
            val bmp = Bitmap.createBitmap(hedefW, Math.max(1, (w.height * sc).toInt()), Bitmap.Config.RGB_565)
            val c = android.graphics.Canvas(bmp)
            c.drawColor(Color.WHITE)
            c.scale(sc, sc)
            w.draw(c)
            t.thumb = bmp
        } catch (e: Exception) { }
    }

    // Chrome tarzı sekme ızgarası
    private fun sekmeler() {
        cur()?.let { yakala(it) }
        val d = android.app.Dialog(this, android.R.style.Theme_DeviceDefault_NoActionBar)
        d.window?.setBackgroundDrawable(ColorDrawable(pal.page))
        d.window?.statusBarColor = pal.page
        d.window?.navigationBarColor = pal.page

        val kok = LinearLayout(this)
        kok.orientation = LinearLayout.VERTICAL
        kok.setBackgroundColor(pal.page)

        val ust = LinearLayout(this)
        ust.orientation = LinearLayout.HORIZONTAL
        ust.gravity = Gravity.CENTER_VERTICAL
        ust.setPadding(dp(14), dp(12), dp(14), dp(10))

        val yeniB = TextView(this)
        yeniB.text = "＋"
        yeniB.textSize = 26f
        yeniB.gravity = Gravity.CENTER
        yeniB.setTextColor(Themes.textOn(pal.accent))
        val yg = GradientDrawable(); yg.setColor(pal.accent); yg.cornerRadius = dp(16).toFloat()
        yeniB.background = yg
        yeniB.setOnClickListener { d.dismiss(); yeniSekme(ANA) }
        ust.addView(yeniB, LinearLayout.LayoutParams(dp(56), dp(48)))

        val sayi = TextView(this)
        sayi.gravity = Gravity.CENTER
        sayi.textSize = 16f
        sayi.setTextColor(pal.fg)
        val sg = GradientDrawable(); sg.setColor(pal.field); sg.cornerRadius = dp(22).toFloat()
        sayi.background = sg
        sayi.setPadding(dp(22), dp(10), dp(22), dp(10))
        val sl = LinearLayout.LayoutParams(0, -2, 1f); sl.setMargins(dp(14), 0, dp(14), 0)
        ust.addView(sayi, sl)

        val hepsi = TextView(this)
        hepsi.text = "Tümünü\nkapat"
        hepsi.textSize = 12f
        hepsi.gravity = Gravity.CENTER
        hepsi.setTextColor(pal.fg)
        ust.addView(hepsi, LinearLayout.LayoutParams(dp(64), -2))
        kok.addView(ust, LinearLayout.LayoutParams(-1, -2))

        val sv = ScrollView(this)
        val izgara = LinearLayout(this)
        izgara.orientation = LinearLayout.VERTICAL
        izgara.setPadding(dp(12), dp(4), dp(12), dp(24))
        sv.addView(izgara)
        kok.addView(sv, LinearLayout.LayoutParams(-1, 0, 1f))

        fun ciz() {
            izgara.removeAllViews()
            sayi.text = "▣  " + tabs.size
            val genis = (resources.displayMetrics.widthPixels - dp(24) - dp(16)) / 2
            var sat: LinearLayout? = null
            for ((i, t) in tabs.withIndex()) {
                if (i % 2 == 0) {
                    sat = LinearLayout(this)
                    sat.orientation = LinearLayout.HORIZONTAL
                    izgara.addView(sat, LinearLayout.LayoutParams(-1, -2))
                }
                val kart = LinearLayout(this)
                kart.orientation = LinearLayout.VERTICAL
                val kg = GradientDrawable()
                kg.setColor(pal.bar)
                kg.cornerRadius = dp(20).toFloat()
                if (i == cur) kg.setStroke(dp(3), pal.accent)
                kart.background = kg
                kart.setPadding(dp(6), dp(6), dp(6), dp(6))

                val bs = LinearLayout(this)
                bs.orientation = LinearLayout.HORIZONTAL
                bs.gravity = Gravity.CENTER_VERTICAL
                val tt = TextView(this)
                tt.text = if (t.title.isNotEmpty()) t.title else "Yeni sekme"
                tt.maxLines = 1
                tt.ellipsize = android.text.TextUtils.TruncateAt.END
                tt.textSize = 13f
                tt.setTextColor(pal.fg)
                tt.setPadding(dp(8), 0, 0, 0)
                bs.addView(tt, LinearLayout.LayoutParams(0, -2, 1f))
                val x = TextView(this)
                x.text = "✕"
                x.textSize = 15f
                x.gravity = Gravity.CENTER
                x.setTextColor(pal.fg)
                x.setOnClickListener {
                    kapat(i)
                    if (tabs.size == 0) d.dismiss() else ciz()
                }
                bs.addView(x, LinearLayout.LayoutParams(dp(34), dp(34)))
                kart.addView(bs, LinearLayout.LayoutParams(-1, -2))

                val kutu = FrameLayout(this)
                val kb = GradientDrawable(); kb.setColor(pal.field); kb.cornerRadius = dp(14).toFloat()
                kutu.background = kb
                kutu.clipToOutline = true
                val th = t.thumb
                if (th != null) {
                    val iv = ImageView(this)
                    iv.adjustViewBounds = true
                    iv.scaleType = ImageView.ScaleType.FIT_XY
                    iv.setImageBitmap(th)
                    kutu.addView(iv, FrameLayout.LayoutParams(-1, -2))
                } else {
                    val ph = TextView(this)
                    ph.text = (if (t.title.isNotEmpty()) t.title else "T").take(1).uppercase()
                    ph.textSize = 34f
                    ph.gravity = Gravity.CENTER
                    ph.setTextColor(pal.muted)
                    kutu.addView(ph, FrameLayout.LayoutParams(-1, -1))
                }
                kart.addView(kutu, LinearLayout.LayoutParams(-1, dp(190)))
                kart.setOnClickListener { sec(i); d.dismiss() }

                val lp = LinearLayout.LayoutParams(genis, -2)
                lp.setMargins(dp(4), dp(4), dp(4), dp(4))
                sat?.addView(kart, lp)
            }
        }
        hepsi.setOnClickListener {
            repeat(tabs.size) { kapat(0) }
            d.dismiss()
        }
        ciz()
        d.setContentView(kok)
        d.show()
    }

    private fun aramaUrl(): String = when (st.aramaMotoru) {
        "duckduckgo" -> "https://duckduckgo.com/?q="
        "bing" -> "https://www.bing.com/search?q="
        "yandex" -> "https://yandex.com.tr/search/?text="
        else -> "https://www.google.com/search?q="
    }

    private fun git(girdi: String) {
        val g = girdi.trim()
        if (g.isEmpty()) return
        val u: String = if (g.startsWith("http://") || g.startsWith("https://")) g
        else if (!g.contains(" ") && g.contains(".")) "https://$g"
        else aramaUrl() + Uri.encode(g)
        cur()?.web?.loadUrl(u)
        oneriGizle()
        urlBar.clearFocus()
        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as android.view.inputmethod.InputMethodManager
        imm.hideSoftInputFromWindow(urlBar.windowToken, 0)
    }

    // ---------------- adres çubuğu önerileri (geçmiş + yer imleri) ----------------
    private fun oneriGizle() {
        oneriScroll.visibility = View.GONE
    }

    private fun oneriler(q0: String) {
        val q = q0.trim().lowercase()
        oneriKutu.removeAllViews()
        class Oge(val ikon: Int, val baslik: String, val url: String, val ara: Boolean)
        val liste = ArrayList<Oge>()
        val gorulen = HashSet<String>()
        if (q.isNotEmpty()) liste.add(Oge(R.drawable.ic_ara, q0.trim(), "", true))
        fun uygun(t: String, u: String): Boolean = q.isEmpty() || t.lowercase().contains(q) || u.lowercase().contains(q)
        if (q.isNotEmpty()) {
            val yi = st.bookmarks()
            for (i in 0 until yi.length()) {
                val o = yi.getJSONObject(i)
                val u = o.optString("u"); val t = o.optString("t")
                if (uygun(t, u) && gorulen.add(u) && liste.size < 9) liste.add(Oge(R.drawable.ic_yildiz, t, u, false))
            }
        }
        val gc = st.history()
        for (i in 0 until gc.length()) {
            val o = gc.getJSONObject(i)
            val u = o.optString("u"); val t = o.optString("t")
            if (uygun(t, u) && gorulen.add(u) && liste.size < 9) liste.add(Oge(R.drawable.ic_saat, t, u, false))
        }
        if (liste.isEmpty()) { oneriGizle(); return }
        for (g in liste) {
            val r = LinearLayout(this)
            r.orientation = LinearLayout.HORIZONTAL
            r.gravity = Gravity.CENTER_VERTICAL
            r.setPadding(dp(14), dp(10), dp(14), dp(10))
            val ic = ImageView(this)
            ic.setImageResource(g.ikon)
            ic.setColorFilter(if (g.ara) pal.accent else pal.muted)
            r.addView(ic, LinearLayout.LayoutParams(dp(20), dp(20)))
            val kol = LinearLayout(this)
            kol.orientation = LinearLayout.VERTICAL
            val t1 = TextView(this)
            t1.text = if (g.ara) "\"" + g.baslik + "\" ara" else g.baslik
            t1.textSize = 14f
            t1.setTextColor(pal.fg)
            t1.setSingleLine()
            t1.ellipsize = android.text.TextUtils.TruncateAt.END
            kol.addView(t1)
            if (!g.ara) {
                val t2 = TextView(this)
                t2.text = g.url
                t2.textSize = 11f
                t2.setTextColor(pal.muted)
                t2.setSingleLine()
                t2.ellipsize = android.text.TextUtils.TruncateAt.END
                kol.addView(t2)
            }
            val kl = LinearLayout.LayoutParams(0, -2, 1f)
            kl.leftMargin = dp(14)
            r.addView(kol, kl)
            r.setOnClickListener { git(if (g.ara) g.baslik else g.url) }
            oneriKutu.addView(r, LinearLayout.LayoutParams(-1, -2))
        }
        oneriScroll.visibility = View.VISIBLE
    }

    // ---------------- araç çubuğundaki eklenti simgeleri ----------------
    private fun ekCiz() {
        ekAlan.removeAllViews()
        var n = 0
        for (x in motor.liste()) {
            if (n >= 2) break
            if (motor.popupYolu(x).isEmpty()) continue
            val b = motor.ikon(x) ?: continue
            val iv = ImageView(this)
            iv.setImageBitmap(b)
            iv.scaleType = ImageView.ScaleType.FIT_CENTER
            iv.setPadding(dp(7), dp(7), dp(7), dp(7))
            iv.setOnClickListener { motor.popupAc(x) }
            ekAlan.addView(iv, LinearLayout.LayoutParams(dp(40), dp(40)))
            n++
        }
    }

    // Widget / ana ekran kısayolundan gelen "eklentiyi aç" isteği
    private fun ekIntent(i: Intent?) {
        val k = i?.getStringExtra("ek") ?: return
        if (k.isEmpty()) { eklentiGoster(); return }
        for (j in 0 until eklentiler.length()) {
            val e = eklentiler.getJSONObject(j)
            if (e.optString("anahtar") == k) { motor.ac(e); return }
        }
        Toast.makeText(this, "Eklenti bulunamadı (giriş yaptığınızdan emin olun)", Toast.LENGTH_LONG).show()
    }

    // ---------------- menü ----------------
    private fun menu() {
        val t = cur()
        val d = android.app.Dialog(this)
        d.requestWindowFeature(android.view.Window.FEATURE_NO_TITLE)
        val kutu = LinearLayout(this)
        kutu.orientation = LinearLayout.VERTICAL
        val arka = GradientDrawable()
        arka.setColor(pal.bar)
        arka.cornerRadius = dp(18).toFloat()
        kutu.background = arka
        kutu.setPadding(0, dp(6), 0, dp(6))
        val sv = ScrollView(this)
        sv.addView(kutu)
        d.setContentView(sv)

        fun ayirac() {
            val v = View(this)
            v.setBackgroundColor(pal.field)
            val lp = LinearLayout.LayoutParams(-1, dp(1))
            lp.setMargins(dp(14), dp(4), dp(14), dp(4))
            kutu.addView(v, lp)
        }
        fun satir(ikon: String, ad: String, f: () -> Unit) {
            val r = LinearLayout(this)
            r.orientation = LinearLayout.HORIZONTAL
            r.gravity = Gravity.CENTER_VERTICAL
            r.setPadding(dp(18), dp(12), dp(18), dp(12))
            val ic = TextView(this); ic.text = ikon; ic.textSize = 18f; ic.setTextColor(pal.fg)
            ic.gravity = Gravity.CENTER
            val tx = TextView(this); tx.text = ad; tx.textSize = 16f; tx.setTextColor(pal.fg)
            r.addView(ic, LinearLayout.LayoutParams(dp(32), -2))
            val lp = LinearLayout.LayoutParams(0, -2, 1f); lp.leftMargin = dp(10)
            r.addView(tx, lp)
            r.setOnClickListener { d.dismiss(); f() }
            kutu.addView(r, LinearLayout.LayoutParams(-1, -2))
        }
        fun satirRes(res: Int, ad: String, f: () -> Unit) {
            val r = LinearLayout(this)
            r.orientation = LinearLayout.HORIZONTAL
            r.gravity = Gravity.CENTER_VERTICAL
            r.setPadding(dp(18), dp(12), dp(18), dp(12))
            val ic = ImageView(this); ic.setImageResource(res); ic.setColorFilter(pal.fg)
            val tx = TextView(this); tx.text = ad; tx.textSize = 16f; tx.setTextColor(pal.fg)
            r.addView(ic, LinearLayout.LayoutParams(dp(24), dp(24)))
            val lp = LinearLayout.LayoutParams(0, -2, 1f); lp.leftMargin = dp(18)
            r.addView(tx, lp)
            r.setOnClickListener { d.dismiss(); f() }
            kutu.addView(r, LinearLayout.LayoutParams(-1, -2))
        }
        fun anahtar(ikon: String, ad: String, acik: Boolean, f: (Boolean) -> Unit): CheckBox {
            val r = LinearLayout(this)
            r.orientation = LinearLayout.HORIZONTAL
            r.gravity = Gravity.CENTER_VERTICAL
            r.setPadding(dp(18), dp(6), dp(14), dp(6))
            val ic = TextView(this); ic.text = ikon; ic.textSize = 18f; ic.setTextColor(pal.fg)
            ic.gravity = Gravity.CENTER
            val tx = TextView(this); tx.text = ad; tx.textSize = 16f; tx.setTextColor(pal.fg)
            val cb = CheckBox(this)
            cb.isChecked = acik
            cb.buttonTintList = ColorStateList.valueOf(pal.accent)
            cb.setOnCheckedChangeListener { _, v -> f(v) }
            r.addView(ic, LinearLayout.LayoutParams(dp(32), -2))
            val lp = LinearLayout.LayoutParams(0, -2, 1f); lp.leftMargin = dp(10)
            r.addView(tx, lp)
            r.addView(cb)
            r.setOnClickListener { cb.toggle() }
            kutu.addView(r, LinearLayout.LayoutParams(-1, -2))
            return cb
        }

        // üst ikon şeridi (geri, ileri, yer imi, indir, yenile) — Chrome gibi yuvarlak düğmeler
        val ust = LinearLayout(this)
        ust.orientation = LinearLayout.HORIZONTAL
        ust.setPadding(dp(12), dp(8), dp(12), dp(6))
        fun ikonDugme(res: Int, etkin: Boolean, f: () -> Unit) {
            val kap = FrameLayout(this)
            val daire = GradientDrawable()
            daire.shape = GradientDrawable.OVAL
            daire.setColor(pal.field)
            kap.background = daire
            val iv = ImageView(this)
            iv.setImageResource(res)
            iv.setColorFilter(pal.fg)
            kap.addView(iv, FrameLayout.LayoutParams(dp(22), dp(22), Gravity.CENTER))
            kap.alpha = if (etkin) 1f else 0.35f
            if (etkin) kap.setOnClickListener { d.dismiss(); f() }
            val lp = LinearLayout.LayoutParams(0, dp(44), 1f)
            lp.setMargins(dp(4), 0, dp(4), 0)
            ust.addView(kap, lp)
        }
        val imli = t != null && st.isBookmarked(t.url)
        ikonDugme(R.drawable.ic_geri, t?.web?.canGoBack() == true) { cur()?.web?.goBack() }
        ikonDugme(R.drawable.ic_ileri, t?.web?.canGoForward() == true) { cur()?.web?.goForward() }
        ikonDugme(if (imli) R.drawable.ic_yildiz else R.drawable.ic_yildiz_bos, t != null) {
            t?.let { val e = st.toggleBookmark(it.title, it.url); Toast.makeText(this, if (e) "Yer imi eklendi" else "Yer imi kaldırıldı", Toast.LENGTH_SHORT).show(); kisayollariCiz() }
        }
        ikonDugme(R.drawable.ic_indir, true) { startActivity(Intent(DownloadManager.ACTION_VIEW_DOWNLOADS)) }
        ikonDugme(R.drawable.ic_yenile, t != null) { cur()?.web?.reload() }
        kutu.addView(ust, LinearLayout.LayoutParams(-1, -2))
        ayirac()

        satir("＋", "Yeni sekme") { yeniSekme(ANA) }
        satir("▣", "Sekmeler (${tabs.size})") { sekmeler() }
        ayirac()
        satir("🕘", "Geçmiş") { listeGoster("Geçmiş", "gecmis") }
        satir("★", "Yer imleri") { listeGoster("Yer imleri", "yerimleri") }
        satir("📝", "Notlarım") { startActivity(Intent(this, NotesActivity::class.java)) }
        satir("↗", "Paylaş") {
            t?.let {
                val i = Intent(Intent.ACTION_SEND)
                i.type = "text/plain"
                i.putExtra(Intent.EXTRA_TEXT, it.url)
                startActivity(Intent.createChooser(i, "Paylaş"))
            }
        }
        satirRes(R.drawable.ic_eklenti, "Eklentiler (${eklentiler.length()})") { eklentiGoster() }
        ayirac()
        satirRes(R.drawable.ic_ara, "Sayfada bul") { bulAc() }
        satir("🌐", "Sayfayı çevir (Türkçe)") { cevir() }
        satirRes(R.drawable.ic_eve, "Ana ekrana ekle") { sayfaKisayol() }
        anahtar("🌙", "Web sayfalarını karanlık yap", st.webKoyu) { v ->
            st.webKoyu = v
            tabs.forEach { koyuUygula(it.web) }
            cur()?.web?.reload()
        }
        ayirac()
        anahtar("🖥", "Masaüstü sitesi", t?.masaustu == true) { v ->
            t?.let { sekmeGit(it, it.url.ifEmpty { ANA }, v) }
        }
        anahtar("🛡", "Reklam engelleyici", st.reklamEngel) { v -> st.reklamEngel = v; cur()?.web?.reload() }
        anahtar("⚡", "Kısayol şeridi", st.seritGoster) { v -> seritAyarla(v, true) }
        var vcb: CheckBox? = null
        vcb = anahtar("🔒", "VPN", st.vpnAcik) { v -> if (!vpnDegistir(v)) vcb?.isChecked = false }
        if (vpnSunucular.length() > 1) satir("🌍", "VPN sunucusu seç") { vpnMenu() }
        if (st.vpnAcik) satir("🔎", "VPN testi (IP ve ülke)") { yeniSekme("https://www.cloudflare.com/cdn-cgi/trace") }
        ayirac()
        satir("🎨", "Tema") { temaMenu() }
        satir("⚙", "Ayarlar") { ayarlar() }
        satir("🔔", "Duyurular (${duyurular.length()})") { duyuruGoster() }
        if (st.token.isEmpty()) satir("👤", "Giriş yap") { girisGoster() }
        else {
            satir("🌐", "Siteye giriş yapmış olarak git") { sso() }
            satir("⎋", "Çıkış (${st.kullaniciAdi})") { cikis() }
        }

        d.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        val lp = d.window?.attributes
        if (lp != null) {
            lp.gravity = Gravity.TOP or Gravity.END
            lp.x = dp(8)
            lp.y = dp(56)
            lp.width = dp(300)
            lp.height = android.view.ViewGroup.LayoutParams.WRAP_CONTENT
            d.window?.attributes = lp
        }
        d.show()
    }

    // Adres çubuğundaki VPN kalkanının rengi (açık: dolu renk, kapalı: soluk)
    private fun vpnCiz() {
        if (!::vpnKalkan.isInitialized) return
        if (st.vpnAcik) {
            vpnKalkanIc.setColorFilter(pal.accent)
            vpnKalkanIc.alpha = 1f
            vpnKalkanYazi.setTextColor(Themes.textOn(pal.accent))
        } else {
            vpnKalkanIc.setColorFilter(pal.muted)
            vpnKalkanIc.alpha = 0.45f
            vpnKalkanYazi.setTextColor(pal.fg)
        }
    }

    private fun rtcAyarla(w: WebView, ac: Boolean) {
        try {
            if (!WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT)) return
            rtcScript.remove(w)?.remove()
            if (ac) rtcScript[w] = WebViewCompat.addDocumentStartJavaScript(w, Cfg.RTC_JS, setOf("*"))
        } catch (e: Exception) { }
    }

    // true: istenen durum uygulandı, false: yapılamadı (onay kutusu geri alınır)
    private fun vpnDegistir(ac: Boolean): Boolean {
        if (!ac) {
            if (st.vpnAcik) { st.vpnAcik = false; vpnUygula(); cur()?.web?.reload() }
            return true
        }
        if (!WebViewFeature.isFeatureSupported(WebViewFeature.PROXY_OVERRIDE)) {
            Toast.makeText(this, "Bu cihazın WebView sürümü VPN'i desteklemiyor. Android System WebView'i güncelleyin.", Toast.LENGTH_LONG).show()
            return false
        }
        if (st.token.isEmpty()) {
            Toast.makeText(this, "VPN için önce giriş yapın", Toast.LENGTH_LONG).show()
            return false
        }
        if (vpnSunucular.length() == 0) {
            Toast.makeText(this, "VPN sunucusu tanımlı değil. Yönetici panelinde VPN sekmesinden sunucu ekleyip \"VPN özelliği açık\" yapılmalı.", Toast.LENGTH_LONG).show()
            senkron()
            return false
        }
        var var_ok = false
        for (i in 0 until vpnSunucular.length()) if (vpnSunucular.getJSONObject(i).optString("id") == st.vpnSecili) var_ok = true
        if (!var_ok) st.vpnSecili = vpnSunucular.getJSONObject(0).optString("id")
        st.vpnAcik = true
        vpnUygula()
        cur()?.web?.reload()
        Toast.makeText(this, "VPN açıldı", Toast.LENGTH_SHORT).show()
        return true
    }

    private fun listeGoster(baslik: String, key: String) {
        val a = st.arr(key)
        if (a.length() == 0) { Toast.makeText(this, "Boş", Toast.LENGTH_SHORT).show(); return }
        val n = Math.min(a.length(), 200)
        val isim = Array(n) { a.getJSONObject(it).optString("t") }
        AlertDialog.Builder(this).setTitle(baslik)
            .setItems(isim) { _, i -> cur()?.web?.loadUrl(a.getJSONObject(i).optString("u")) }
            .setNeutralButton("Temizle") { _, _ -> st.putArr(key, JSONArray()); kisayollariCiz() }
            .setNegativeButton("Kapat", null)
            .show()
    }

    private fun temaMenu() {
        val ad = ArrayList<String>(); val id = ArrayList<String>()
        ad.add("Sistem"); id.add("sistem")
        ad.add("Açık"); id.add("acik")
        ad.add("Koyu"); id.add("koyu")
        for (t in Themes.TAKIMLAR) { ad.add(t[1]); id.add("takim:" + t[0]) }
        AlertDialog.Builder(this).setTitle("Tema")
            .setItems(ad.toTypedArray()) { _, i ->
                val v = id[i]
                if (v.startsWith("takim:")) st.takim = v.substring(6) else { st.takim = ""; st.temaModu = v }
                recreate()
            }.show()
    }

    // ---------------- ayarlar sayfası (Chrome tarzı) ----------------
    private fun ayarlar() {
        val d = android.app.Dialog(this, android.R.style.Theme_DeviceDefault_NoActionBar)
        d.window?.setBackgroundDrawable(ColorDrawable(pal.page))
        d.window?.statusBarColor = pal.bar
        d.window?.navigationBarColor = pal.page

        val kok = LinearLayout(this)
        kok.orientation = LinearLayout.VERTICAL
        kok.setBackgroundColor(pal.page)

        val ust = LinearLayout(this)
        ust.orientation = LinearLayout.HORIZONTAL
        ust.gravity = Gravity.CENTER_VERTICAL
        ust.setBackgroundColor(pal.bar)
        ust.setPadding(dp(8), dp(10), dp(16), dp(10))
        val geri = TextView(this)
        geri.text = "←"; geri.textSize = 24f; geri.gravity = Gravity.CENTER; geri.setTextColor(pal.fg)
        geri.setOnClickListener { d.dismiss() }
        ust.addView(geri, LinearLayout.LayoutParams(dp(48), dp(40)))
        val bsl = TextView(this)
        bsl.text = "Ayarlar"; bsl.textSize = 20f; bsl.setTextColor(pal.fg)
        bsl.setTypeface(null, android.graphics.Typeface.BOLD)
        ust.addView(bsl)
        kok.addView(ust, LinearLayout.LayoutParams(-1, -2))

        val sv = ScrollView(this)
        val liste = LinearLayout(this)
        liste.orientation = LinearLayout.VERTICAL
        liste.setPadding(0, 0, 0, dp(30))
        sv.addView(liste)
        kok.addView(sv, LinearLayout.LayoutParams(-1, 0, 1f))

        fun bas(t: String) {
            val x = TextView(this)
            x.text = t; x.textSize = 13f; x.setTextColor(pal.accent)
            x.setTypeface(null, android.graphics.Typeface.BOLD)
            x.setPadding(dp(20), dp(22), dp(20), dp(6))
            liste.addView(x)
        }
        fun satir(ad: String, alt: String, f: () -> Unit) {
            val r = LinearLayout(this)
            r.orientation = LinearLayout.VERTICAL
            r.setPadding(dp(20), dp(13), dp(20), dp(13))
            val a1 = TextView(this); a1.text = ad; a1.textSize = 16f; a1.setTextColor(pal.fg)
            r.addView(a1)
            if (alt.isNotEmpty()) {
                val a2 = TextView(this); a2.text = alt; a2.textSize = 13f; a2.setTextColor(pal.muted)
                r.addView(a2)
            }
            r.setOnClickListener { f() }
            liste.addView(r, LinearLayout.LayoutParams(-1, -2))
        }
        fun anah(ad: String, alt: String, acik: Boolean, f: (Boolean) -> Unit) {
            val r = LinearLayout(this)
            r.orientation = LinearLayout.HORIZONTAL
            r.gravity = Gravity.CENTER_VERTICAL
            r.setPadding(dp(20), dp(8), dp(14), dp(8))
            val kol = LinearLayout(this)
            kol.orientation = LinearLayout.VERTICAL
            val a1 = TextView(this); a1.text = ad; a1.textSize = 16f; a1.setTextColor(pal.fg)
            kol.addView(a1)
            if (alt.isNotEmpty()) {
                val a2 = TextView(this); a2.text = alt; a2.textSize = 13f; a2.setTextColor(pal.muted)
                kol.addView(a2)
            }
            r.addView(kol, LinearLayout.LayoutParams(0, -2, 1f))
            val cb = CheckBox(this)
            cb.isChecked = acik
            cb.buttonTintList = ColorStateList.valueOf(pal.accent)
            cb.setOnCheckedChangeListener { _, v -> f(v) }
            r.addView(cb)
            r.setOnClickListener { cb.toggle() }
            liste.addView(r, LinearLayout.LayoutParams(-1, -2))
        }

        fun yenile() {
            liste.removeAllViews()
            val motorlar = arrayOf("Google", "DuckDuckGo", "Bing", "Yandex")
            val motorId = arrayOf("google", "duckduckgo", "bing", "yandex")
            val motorAd = motorlar[Math.max(0, motorId.indexOf(st.aramaMotoru))]

            bas("Genel")
            satir("Arama motoru", motorAd) {
                AlertDialog.Builder(this).setTitle("Arama motoru")
                    .setItems(motorlar) { _, i -> st.aramaMotoru = motorId[i]; yenile() }.show()
            }
            satir("Ana sayfa", if (st.anaSayfa == Ntp.ISARET) "Turkuaz yeni sekme sayfası" else st.anaSayfa) {
                val e = EditText(this)
                e.setText(if (st.anaSayfa == Ntp.ISARET) "" else st.anaSayfa); e.setSingleLine(); e.hint = "https://..."
                AlertDialog.Builder(this).setTitle("Ana sayfa").setView(e)
                    .setPositiveButton("Kaydet") { _, _ ->
                        var u = e.text.toString().trim()
                        if (u.isNotEmpty()) {
                            if (!u.startsWith("http")) u = "https://$u"
                            st.anaSayfa = u
                        }
                        yenile()
                    }
                    .setNeutralButton("Varsayılan") { _, _ -> st.anaSayfa = Ntp.ISARET; yenile() }
                    .setNegativeButton("Vazgeç", null).show()
            }
            satir("Tema", if (st.takim.isNotEmpty()) "Takım: " + st.takim else when (st.temaModu) { "koyu" -> "Koyu"; "acik" -> "Açık"; else -> "Sistem varsayılanı" }) {
                d.dismiss(); temaMenu()
            }

            bas("Gizlilik ve güvenlik")
            anah("Reklam engelleyici", "Reklam ve izleyici alan adlarını engeller; YouTube reklamlarını atlar", st.reklamEngel) { v -> st.reklamEngel = v }
            satir("Tarama verilerini sil", "Geçmiş, çerezler, önbellek") { verileriSil() }

            bas("Görünüm")
            anah("Kısayol şeridi", "Adres çubuğunun altında kısayollar ve yer imleri", st.seritGoster) { v -> seritAyarla(v, true) }
            anah("Masaüstü sitesi", "Yeni sekmeleri masaüstü sürümüyle aç", st.masaustuVarsayilan) { v -> st.masaustuVarsayilan = v }
            satir("Yazı boyutu", "%" + st.yaziBoyutu) {
                val ad = arrayOf("%80", "%90", "%100", "%115", "%130", "%150")
                val dg = intArrayOf(80, 90, 100, 115, 130, 150)
                AlertDialog.Builder(this).setTitle("Yazı boyutu")
                    .setItems(ad) { _, i ->
                        st.yaziBoyutu = dg[i]
                        for (t in tabs) t.web.settings.textZoom = dg[i]
                        yenile()
                    }.show()
            }

            bas("VPN")
            var vsecili = "Seçilmedi"
            for (i in 0 until vpnSunucular.length()) {
                val o = vpnSunucular.getJSONObject(i)
                if (o.optString("id") == st.vpnSecili) vsecili = o.optString("ad")
            }
            anah("VPN", if (vpnSunucular.length() == 0) "Tanımlı sunucu yok" else (if (st.vpnAcik) "Açık: " + vsecili else "Kapalı"), st.vpnAcik) { v ->
                vpnDegistir(v)
                ui.post { yenile() }
            }
            if (vpnSunucular.length() > 0) satir("VPN sunucusu", vsecili) { vpnMenu() }
            if (st.vpnAcik) satir("VPN testi", "IP adresini ve ülkeyi göster") { d.dismiss(); yeniSekme("https://www.cloudflare.com/cdn-cgi/trace") }

            bas("Hesap")
            if (st.token.isEmpty()) {
                satir("Giriş yap", "VPN, duyurular ve siteye otomatik giriş için") { d.dismiss(); girisGoster() }
            } else {
                satir("Hesap", st.kullaniciAdi) { }
                satir("Siteye giriş yapmış olarak git", "turkuazads.com") { d.dismiss(); sso() }
                satir("Çıkış yap", "") { cikis(); yenile() }
            }

            bas("Uygulama")
            satir("Varsayılan tarayıcı yap", "Sistem ayarlarını açar") {
                try { startActivity(Intent(android.provider.Settings.ACTION_MANAGE_DEFAULT_APPS_SETTINGS)) }
                catch (e: Exception) { Toast.makeText(this, "Ayarlar açılamadı", Toast.LENGTH_SHORT).show() }
            }
            satir("İndirilenler", "") { startActivity(Intent(DownloadManager.ACTION_VIEW_DOWNLOADS)) }
            satir("Notlarım", "") { startActivity(Intent(this, NotesActivity::class.java)) }
            satir("Duyurular", duyurular.length().toString() + " duyuru") { duyuruGoster() }

            bas("Hakkında")
            satir("Turkuaz", "Sürüm " + surum) { }
            satir("Güncellemeleri kontrol et", "") { senkron(); Toast.makeText(this, "Kontrol ediliyor…", Toast.LENGTH_SHORT).show() }
        }
        yenile()
        d.setContentView(kok)
        d.show()
    }

    private fun verileriSil() {
        val secim = booleanArrayOf(true, true, true)
        AlertDialog.Builder(this).setTitle("Tarama verilerini sil")
            .setMultiChoiceItems(arrayOf("Gezinme geçmişi", "Çerezler ve site verileri (oturumlar kapanır)", "Önbellek (resimler ve dosyalar)"), secim) { _, i, c -> secim[i] = c }
            .setPositiveButton("Sil") { _, _ ->
                if (secim[0]) st.putArr("gecmis", JSONArray())
                if (secim[1]) {
                    CookieManager.getInstance().removeAllCookies(null)
                    CookieManager.getInstance().flush()
                    WebStorage.getInstance().deleteAllData()
                }
                if (secim[2]) for (t in tabs) t.web.clearCache(true)
                Toast.makeText(this, "Silindi", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Vazgeç", null).show()
    }

    // ---------------- VPN ----------------
    private fun vpnMenu() {
        if (!WebViewFeature.isFeatureSupported(WebViewFeature.PROXY_OVERRIDE)) {
            Toast.makeText(this, "Bu cihazın WebView sürümü VPN'i desteklemiyor", Toast.LENGTH_LONG).show(); return
        }
        if (vpnSunucular.length() == 0) {
            Toast.makeText(this, if (st.token.isEmpty()) "VPN için giriş yapın" else "Size atanmış VPN sunucusu yok", Toast.LENGTH_LONG).show(); return
        }
        val isim = ArrayList<String>()
        isim.add("Kapat")
        for (i in 0 until vpnSunucular.length()) isim.add(vpnSunucular.getJSONObject(i).optString("ad"))
        AlertDialog.Builder(this).setTitle("VPN")
            .setItems(isim.toTypedArray()) { _, i ->
                if (i == 0) st.vpnAcik = false
                else { st.vpnAcik = true; st.vpnSecili = vpnSunucular.getJSONObject(i - 1).optString("id") }
                vpnUygula()
                cur()?.web?.reload()
            }.show()
    }

    private fun vpnUygula() {
        vpnCiz()
        for (t in tabs) rtcAyarla(t.web, st.vpnAcik)
        if (!WebViewFeature.isFeatureSupported(WebViewFeature.PROXY_OVERRIDE)) return
        val ex = java.util.concurrent.Executor { r -> ui.post(r) }
        if (!st.vpnAcik) { ProxyController.getInstance().clearProxyOverride(ex) { }; return }
        var hedef: JSONObject? = null
        for (i in 0 until vpnSunucular.length()) {
            val o = vpnSunucular.getJSONObject(i)
            if (o.optString("id") == st.vpnSecili) hedef = o
        }
        if (hedef == null) return
        val sch = when (hedef.optString("tur")) { "socks5" -> "socks5"; "http" -> "http"; else -> "https" }
        val kural = "$sch://${hedef.optString("host")}:${hedef.optInt("port")}"
        try {
            val cfg = ProxyConfig.Builder().addProxyRule(kural).build()
            ProxyController.getInstance().setProxyOverride(cfg, ex) { }
            Toast.makeText(this, "VPN: " + hedef.optString("ad") + "\n" + kural, Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
            Toast.makeText(this, "VPN ayarlanamadı", Toast.LENGTH_SHORT).show()
        }
    }

    // ---------------- hesap / sunucu ----------------
    private fun girisGoster() {
        val d = android.app.Dialog(this)
        d.requestWindowFeature(android.view.Window.FEATURE_NO_TITLE)
        val kart = LinearLayout(this)
        kart.orientation = LinearLayout.VERTICAL
        kart.gravity = Gravity.CENTER_HORIZONTAL
        val kb = GradientDrawable(); kb.setColor(pal.bar); kb.cornerRadius = dp(26).toFloat()
        kart.background = kb
        kart.setPadding(dp(24), dp(26), dp(24), dp(18))

        val logo = ImageView(this)
        logo.setImageResource(R.drawable.logo)
        logo.scaleType = ImageView.ScaleType.FIT_CENTER
        kart.addView(logo, LinearLayout.LayoutParams(dp(72), dp(72)))

        val bas = TextView(this)
        bas.text = "Turkuaz'a hoş geldin"
        bas.textSize = 21f
        bas.setTypeface(null, android.graphics.Typeface.BOLD)
        bas.setTextColor(pal.fg)
        val bl = LinearLayout.LayoutParams(-2, -2); bl.topMargin = dp(12)
        kart.addView(bas, bl)

        val alt = TextView(this)
        alt.text = "Hesabınla giriş yap; VPN, duyurular ve siteye otomatik giriş açılır."
        alt.textSize = 13f
        alt.gravity = Gravity.CENTER
        alt.setTextColor(pal.muted)
        val al = LinearLayout.LayoutParams(-2, -2); al.topMargin = dp(6); al.bottomMargin = dp(16)
        kart.addView(alt, al)

        fun alan(ipucu: String, sifre: Boolean): EditText {
            val e = EditText(this)
            e.hint = ipucu
            e.setSingleLine()
            e.setTextColor(pal.fg)
            e.setHintTextColor(pal.muted)
            val g = GradientDrawable(); g.setColor(pal.field); g.cornerRadius = dp(14).toFloat()
            e.background = g
            e.setPadding(dp(16), dp(13), dp(16), dp(13))
            e.textSize = 15f
            if (sifre) e.inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD
            else e.inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS
            val lp = LinearLayout.LayoutParams(-1, -2); lp.bottomMargin = dp(10)
            kart.addView(e, lp)
            return e
        }
        val k = alan("Kullanıcı adı veya e-posta", false)
        val s = alan("Şifre", true)

        val err = TextView(this)
        err.textSize = 13f
        err.setTextColor(Themes.ensure(Color.parseColor("#E5484D"), pal.bar, 3.0))
        err.visibility = View.GONE
        err.gravity = Gravity.CENTER
        kart.addView(err, LinearLayout.LayoutParams(-1, -2))

        val btn = TextView(this)
        btn.text = "Giriş yap"
        btn.gravity = Gravity.CENTER
        btn.textSize = 16f
        btn.setTypeface(null, android.graphics.Typeface.BOLD)
        btn.setTextColor(Themes.textOn(pal.accent))
        val bg = GradientDrawable(); bg.setColor(pal.accent); bg.cornerRadius = dp(14).toFloat()
        btn.background = bg
        btn.setPadding(0, dp(14), 0, dp(14))
        val bt = LinearLayout.LayoutParams(-1, -2); bt.topMargin = dp(8)
        kart.addView(btn, bt)

        val atla = TextView(this)
        atla.text = "Şimdi değil"
        atla.gravity = Gravity.CENTER
        atla.textSize = 14f
        atla.setTextColor(pal.muted)
        atla.setPadding(dp(16), dp(14), dp(16), dp(6))
        kart.addView(atla, LinearLayout.LayoutParams(-2, -2))

        btn.setOnClickListener {
            val ku = k.text.toString().trim()
            val si = s.text.toString()
            if (ku.isEmpty() || si.isEmpty()) {
                err.text = "Kullanıcı adı ve şifre gerekli."
                err.visibility = View.VISIBLE
                return@setOnClickListener
            }
            err.visibility = View.GONE
            btn.isEnabled = false
            btn.alpha = 0.6f
            btn.text = "Giriş yapılıyor…"
            val body = JSONObject()
            body.put("kullanici", ku); body.put("sifre", si)
            body.put("cihaz", "Android " + Build.MODEL); body.put("surum", surum)
            io.execute {
                val r = Net.call("giris.php", body, "", surum)
                ui.post {
                    if (r.optBoolean("ok")) {
                        st.token = r.optString("token")
                        st.kullaniciAdi = r.optJSONObject("kullanici")?.optString("ad") ?: ""
                        d.dismiss()
                        Toast.makeText(this, "Giriş yapıldı", Toast.LENGTH_SHORT).show()
                        senkron()
                    } else {
                        err.text = r.optString("hata", "Giriş başarısız")
                        err.visibility = View.VISIBLE
                        btn.isEnabled = true
                        btn.alpha = 1f
                        btn.text = "Giriş yap"
                    }
                }
            }
        }
        atla.setOnClickListener { st.girisAtla = true; d.dismiss() }
        d.setOnCancelListener { st.girisAtla = true }

        val sv = ScrollView(this)
        sv.addView(kart)
        d.setContentView(sv)
        d.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        d.window?.setSoftInputMode(android.view.WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
        val w = Math.min(dp(360), resources.displayMetrics.widthPixels - dp(32))
        d.window?.setLayout(w, android.view.ViewGroup.LayoutParams.WRAP_CONTENT)
        d.show()
    }

    private fun cikis() {
        val t = st.token
        io.execute { Net.call("cikis.php", JSONObject(), t, surum) }
        st.token = ""; st.kullaniciAdi = ""; st.vpnAcik = false
        vpnSunucular = JSONArray(); duyurular = JSONArray(); eklentiler = JSONArray(); st.putArr("vpnListe", JSONArray()); st.putArr("eklentiListe", JSONArray()); motor.senkron(eklentiler)
        vpnUygula()
        Toast.makeText(this, "Çıkış yapıldı", Toast.LENGTH_SHORT).show()
    }

    private fun sso() {
        val t = st.token
        io.execute {
            val r = Net.call("sso_bilet.php", JSONObject(), t, surum)
            ui.post {
                if (r.optBoolean("ok")) yeniSekme(r.optString("url"))
                else Toast.makeText(this, r.optString("hata", "Başarısız"), Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun senkron() {
        ui.removeCallbacks(tick)
        ui.postDelayed(tick, Cfg.SYNC_MS)
        val t = st.token
        if (t.isEmpty()) return
        io.execute {
            val r = Net.call("esitle.php", null, t, surum)
            ui.post {
                if (r.optInt("_kod") == 401 || r.optInt("_kod") == 403) {
                    st.token = ""; st.vpnAcik = false; vpnSunucular = JSONArray(); st.putArr("vpnListe", JSONArray()); vpnUygula(); return@post
                }
                if (!r.optBoolean("ok")) return@post
                duyurular = r.optJSONArray("duyurular") ?: JSONArray()
                eklentiler = r.optJSONArray("eklentiler") ?: JSONArray()
                st.putArr("eklentiListe", eklentiler)
                motor.senkron(eklentiler)
                val v = r.optJSONObject("vpn")
                vpnSunucular = v?.optJSONArray("sunucular") ?: JSONArray()
                st.putArr("vpnListe", vpnSunucular)
                if (st.vpnAcik && vpnSunucular.length() == 0) { st.vpnAcik = false; vpnUygula() }
                vpnUygula()
                st.kullaniciAdi = r.optJSONObject("kullanici")?.optString("ad") ?: st.kullaniciAdi
                val apk = r.optJSONObject("apk")
                if (apk != null && yeniMi(apk.optString("son"), surum)) {
                    banner.text = "Yeni sürüm ${apk.optString("son")} hazır — güncellemek için dokunun"
                    banner.visibility = View.VISIBLE
                    val link = apk.optString("indir")
                    banner.setOnClickListener {
                        startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(link)))
                    }
                } else banner.visibility = View.GONE
            }
        }
    }
    private val tick = Runnable { senkron() }

    private fun yeniMi(a: String, b: String): Boolean {
        val x = a.split(".").map { it.toIntOrNull() ?: 0 }
        val y = b.split(".").map { it.toIntOrNull() ?: 0 }
        for (i in 0 until Math.max(x.size, y.size)) {
            val p = x.getOrElse(i) { 0 }; val q = y.getOrElse(i) { 0 }
            if (p != q) return p > q
        }
        return false
    }

    private fun eklentiGoster() {
        val d = android.app.Dialog(this)
        d.requestWindowFeature(android.view.Window.FEATURE_NO_TITLE)
        val kutu = LinearLayout(this)
        kutu.orientation = LinearLayout.VERTICAL
        kutu.setPadding(dp(18), dp(16), dp(18), dp(12))
        val arka = GradientDrawable(); arka.setColor(pal.bar); arka.cornerRadius = dp(18).toFloat()
        kutu.background = arka
        val bas = TextView(this); bas.text = "Eklentiler"; bas.textSize = 20f; bas.setTextColor(pal.fg)
        bas.typeface = android.graphics.Typeface.DEFAULT_BOLD
        kutu.addView(bas)
        if (st.token.isEmpty()) {
            val m = TextView(this); m.text = "Hesabına atanmış eklentileri görmek için giriş yap. Elle eklediklerin girişsiz de çalışır."; m.setTextColor(pal.fg); m.setPadding(0, dp(12), 0, dp(8))
            kutu.addView(m)
        } else if (eklentiler.length() == 0) {
            val m = TextView(this); m.text = "Hesabına atanmış eklenti yok. Yönetici atadığında burada görünür."; m.setTextColor(pal.fg); m.setPadding(0, dp(12), 0, dp(8))
            kutu.addView(m)
        }
        for (i in 0 until eklentiler.length()) {
            val e = eklentiler.getJSONObject(i)
            val kart = LinearLayout(this)
            kart.orientation = LinearLayout.HORIZONTAL
            kart.gravity = Gravity.CENTER_VERTICAL
            kart.setPadding(dp(12), dp(12), dp(12), dp(12))
            val kb = GradientDrawable(); kb.setColor(pal.field); kb.cornerRadius = dp(14).toFloat()
            kart.background = kb
            val ic = ImageView(this); ic.setImageResource(R.drawable.ic_eklenti); ic.setColorFilter(pal.accent)
            kart.addView(ic, LinearLayout.LayoutParams(dp(28), dp(28)))
            val kol = LinearLayout(this); kol.orientation = LinearLayout.VERTICAL
            val ad = TextView(this); ad.text = e.optString("ad") + "  v" + e.optString("surum"); ad.textSize = 16f; ad.setTextColor(pal.fg)
            ad.typeface = android.graphics.Typeface.DEFAULT_BOLD
            kol.addView(ad)
            val ac = e.optString("aciklama")
            if (ac.isNotEmpty()) { val a = TextView(this); a.text = ac; a.textSize = 13f; a.setTextColor(pal.fg); a.alpha = 0.7f; kol.addView(a) }
            val lp = LinearLayout.LayoutParams(0, -2, 1f); lp.leftMargin = dp(12)
            kart.addView(kol, lp)
            val dur = TextView(this); dur.text = "Aç ›"; dur.textSize = 14f; dur.setTextColor(pal.accent)
            dur.typeface = android.graphics.Typeface.DEFAULT_BOLD
            kart.addView(dur)
            kart.setOnClickListener { d.dismiss(); motor.ac(e) }
            val klp = LinearLayout.LayoutParams(-1, -2); klp.topMargin = dp(10)
            kutu.addView(kart, klp)
        }
        for (x in motor.liste()) {
            if (!motor.yerelMi(x.key)) continue
            val kart = LinearLayout(this)
            kart.orientation = LinearLayout.HORIZONTAL
            kart.gravity = Gravity.CENTER_VERTICAL
            kart.setPadding(dp(12), dp(12), dp(12), dp(12))
            val kb = GradientDrawable(); kb.setColor(pal.field); kb.cornerRadius = dp(14).toFloat()
            kart.background = kb
            val simge = motor.ikon(x)
            val ic = ImageView(this)
            if (simge != null) ic.setImageBitmap(simge) else { ic.setImageResource(R.drawable.ic_eklenti); ic.setColorFilter(pal.accent) }
            kart.addView(ic, LinearLayout.LayoutParams(dp(30), dp(30)))
            val kol = LinearLayout(this); kol.orientation = LinearLayout.VERTICAL
            val ad = TextView(this); ad.text = x.ad; ad.textSize = 16f; ad.setTextColor(pal.fg)
            ad.typeface = android.graphics.Typeface.DEFAULT_BOLD
            kol.addView(ad)
            val a2 = TextView(this); a2.text = "Elle eklendi · silmek için basılı tut"; a2.textSize = 12f; a2.setTextColor(pal.fg); a2.alpha = 0.6f
            kol.addView(a2)
            val lp = LinearLayout.LayoutParams(0, -2, 1f); lp.leftMargin = dp(12)
            kart.addView(kol, lp)
            val dur = TextView(this); dur.text = "Aç ›"; dur.textSize = 14f; dur.setTextColor(pal.accent)
            dur.typeface = android.graphics.Typeface.DEFAULT_BOLD
            kart.addView(dur)
            kart.setOnClickListener { d.dismiss(); motor.popupAc(x) }
            kart.setOnLongClickListener {
                AlertDialog.Builder(this).setTitle(x.ad).setMessage("Bu eklenti kaldırılsın mı?")
                    .setPositiveButton("Kaldır") { _, _ -> d.dismiss(); motor.yerelSil(x.key); Toast.makeText(this, "Kaldırıldı", Toast.LENGTH_SHORT).show() }
                    .setNegativeButton("Vazgeç", null).show()
                true
            }
            val klp = LinearLayout.LayoutParams(-1, -2); klp.topMargin = dp(10)
            kutu.addView(kart, klp)
        }
        val ekleB = TextView(this)
        ekleB.text = "＋  Dosyadan eklenti ekle (.zip / .crx)"
        ekleB.textSize = 15f; ekleB.setTextColor(pal.accent); ekleB.gravity = Gravity.CENTER
        ekleB.typeface = android.graphics.Typeface.DEFAULT_BOLD
        val eb = GradientDrawable(); eb.cornerRadius = dp(14).toFloat(); eb.setStroke(dp(1), pal.accent)
        ekleB.background = eb
        ekleB.setPadding(dp(12), dp(14), dp(12), dp(14))
        ekleB.setOnClickListener {
            d.dismiss()
            try {
                val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
                i.addCategory(Intent.CATEGORY_OPENABLE)
                i.type = "*/*"
                startActivityForResult(i, 4712)
            } catch (e: Exception) { Toast.makeText(this, "Dosya seçici açılamadı", Toast.LENGTH_LONG).show() }
        }
        val elp = LinearLayout.LayoutParams(-1, -2); elp.topMargin = dp(14)
        kutu.addView(ekleB, elp)
        if (eklentiler.length() > 0) {
            val n = TextView(this)
            n.text = "Eklentiye dokununca açılır menüsü açılır. Eklentiler Android'de bir uyumluluk katmanıyla çalışır; bazı özellikleri (ör. sekmesiz pencere) çalışmayabilir."
            n.textSize = 12f; n.setTextColor(pal.fg); n.alpha = 0.6f; n.setPadding(0, dp(12), 0, 0)
            kutu.addView(n)
        }
        val kapat = TextView(this); kapat.text = "Kapat"; kapat.setTextColor(pal.accent); kapat.textSize = 15f
        kapat.gravity = Gravity.END; kapat.setPadding(0, dp(14), dp(4), dp(4))
        kapat.setOnClickListener { d.dismiss() }
        kutu.addView(kapat)
        val sv = ScrollView(this); sv.addView(kutu)
        d.setContentView(sv)
        d.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        d.window?.setLayout((resources.displayMetrics.widthPixels * 0.92).toInt(), ViewGroup.LayoutParams.WRAP_CONTENT)
        d.show()
    }

    private fun duyuruGoster() {
        if (duyurular.length() == 0) { Toast.makeText(this, "Duyuru yok", Toast.LENGTH_SHORT).show(); return }
        val n = duyurular.length()
        val isim = Array(n) { duyurular.getJSONObject(it).optString("baslik") }
        AlertDialog.Builder(this).setTitle("Duyurular")
            .setItems(isim) { _, i ->
                val d = duyurular.getJSONObject(i)
                val ab = AlertDialog.Builder(this).setTitle(d.optString("baslik")).setMessage(d.optString("aciklama"))
                    .setNegativeButton("Kapat", null)
                if (d.optString("link").startsWith("http")) ab.setPositiveButton("Aç") { _, _ -> yeniSekme(d.optString("link")) }
                ab.show()
                val tk = st.token
                val body = JSONObject(); body.put("id", d.optInt("id"))
                io.execute { Net.call("okundu.php", body, tk, surum) }
            }.setNegativeButton("Kapat", null).show()
    }

    // ---------------- sistem ----------------
    override fun onKeyDown(code: Int, e: KeyEvent): Boolean {
        if (code == KeyEvent.KEYCODE_BACK) {
            if (bulKutu.visibility == View.VISIBLE) { bulKapat(); return true }
            val t = cur()
            if (t != null && t.web.canGoBack()) { t.web.goBack(); return true }
            if (tabs.size > 1) { kapat(cur); return true }
        }
        return super.onKeyDown(code, e)
    }

    override fun onNewIntent(i: Intent) {
        super.onNewIntent(i)
        i.data?.toString()?.let { yeniSekme(it) }
        ekIntent(i)
    }

    override fun onResume() { super.onResume(); tabs.forEach { it.web.onResume() } }
    override fun onPause() { super.onPause(); CookieManager.getInstance().flush() }
    override fun onDestroy() { ui.removeCallbacks(tick); super.onDestroy() }
}
