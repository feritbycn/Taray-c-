package com.turkuaz.tarayici

import org.json.JSONArray
import org.json.JSONObject

/** Turkuaz yeni sekme sayfası (yerel HTML). */
object Ntp {
    const val ISARET = "turkuaz://yeni"
    const val BASE = "https://turkuaz.local/"

    private fun hex(c: Int): String = String.format("#%06X", c and 0xFFFFFF)
    private fun kac(s: String): String = s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;")

    fun html(st: Store, pal: Pal): String {
        val kis = JSONArray()
        val a = st.apps()
        for (i in 0 until a.length()) {
            val o = a.getJSONObject(i)
            kis.put(JSONObject().put("t", o.optString("ad")).put("u", o.optString("url")).put("c", o.optString("renk")))
        }
        val yi = st.bookmarks()
        for (i in 0 until Math.min(yi.length(), 8)) {
            val o = yi.getJSONObject(i)
            kis.put(JSONObject().put("t", o.optString("t")).put("u", o.optString("u")).put("c", ""))
        }
        val son = JSONArray()
        val g = st.history()
        val gor = HashSet<String>()
        var i = 0
        while (i < g.length() && son.length() < 6) {
            val o = g.getJSONObject(i)
            if (gor.add(o.optString("u"))) son.put(JSONObject().put("t", o.optString("t")).put("u", o.optString("u")))
            i++
        }
        val motor = when (st.aramaMotoru) { "duckduckgo" -> "DuckDuckGo"; "bing" -> "Bing"; "yandex" -> "Yandex"; else -> "Google" }
        val veri = JSONObject().put("kis", kis).put("son", son).toString().replace("</", "<\\/")
        return """<!doctype html><html><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<style>
:root{--bg:${hex(pal.page)};--bar:${hex(pal.bar)};--fg:${hex(pal.fg)};--mu:${hex(pal.muted)};--fl:${hex(pal.field)};--ac:${hex(pal.accent)}}
*{box-sizing:border-box;-webkit-tap-highlight-color:transparent}
body{margin:0;background:var(--bg);color:var(--fg);font-family:sans-serif;padding:28px 18px 40px;display:flex;flex-direction:column;align-items:center}
.logo{font-size:44px;font-weight:800;letter-spacing:1px;margin:34px 0 22px;color:var(--ac)}
.ara{width:100%;max-width:560px;display:flex;align-items:center;background:var(--fl);border-radius:30px;padding:0 8px 0 18px;height:52px}
.ara input{flex:1;min-width:0;background:none;border:0;outline:0;color:var(--fg);font-size:16px}
.ara input::placeholder{color:var(--mu)}
.ara button{width:42px;height:42px;border:0;border-radius:50%;background:none;color:var(--ac);font-size:20px}
.mu{color:var(--mu);font-size:12px;margin:8px 0 0}
.izgara{width:100%;max-width:560px;display:grid;grid-template-columns:repeat(4,1fr);gap:16px 6px;margin-top:30px}
.k{display:flex;flex-direction:column;align-items:center;text-decoration:none;color:var(--fg);font-size:12px;min-width:0}
.k i{width:56px;height:56px;border-radius:50%;background:var(--fl);display:flex;align-items:center;justify-content:center;overflow:hidden;font-style:normal;font-size:22px;margin-bottom:6px}
.k i img{width:30px;height:30px}
.k span{max-width:100%;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.kisa{width:100%;max-width:560px;display:flex;gap:10px;margin-top:26px}
.kisa a{flex:1;background:var(--bar);border-radius:16px;padding:14px 8px;text-align:center;color:var(--fg);font-size:14px;text-decoration:none;border:1px solid var(--fl)}
h3{width:100%;max-width:560px;font-size:13px;color:var(--mu);margin:28px 0 8px;font-weight:600}
.s{width:100%;max-width:560px;display:flex;align-items:center;padding:10px 12px;background:var(--bar);border-radius:12px;margin-bottom:6px;color:var(--fg);text-decoration:none;font-size:14px;border:1px solid var(--fl)}
.s img{width:20px;height:20px;margin-right:12px;border-radius:4px}
.s span{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
</style></head><body>
<div class="logo">Turkuaz</div>
<form class="ara" id="f"><input id="q" placeholder="${kac(motor)} ile ara veya adres yaz" autocomplete="off" autocapitalize="off"><button type="button" id="m">&#127908;</button><button type="submit">&#10148;</button></form>
<div class="mu">Arama motoru: ${kac(motor)}</div>
<div class="izgara" id="iz"></div>
<div class="kisa"><a href="#" data-a="yerimi">&#9733; Yer imleri</a><a href="#" data-a="gecmis">&#128344; Geçmiş</a></div>
<h3 id="sh" style="display:none">Son ziyaretler</h3><div id="sl" style="width:100%;max-width:560px"></div>
<script>
var D=$veri;
function P(o){try{TzNtp.postMessage(JSON.stringify(o))}catch(e){}}
function H(u){try{return new URL(u).hostname}catch(e){return ''}}
function fav(u){return 'https://www.google.com/s2/favicons?sz=64&domain='+encodeURIComponent(H(u))}
var iz=document.getElementById('iz');
D.kis.forEach(function(k){var a=document.createElement('a');a.className='k';a.href='#';
 var i=document.createElement('i');var im=document.createElement('img');im.src=fav(k.u);
 im.onerror=function(){i.textContent=(k.t||'?').charAt(0).toUpperCase()};i.appendChild(im);
 var s=document.createElement('span');s.textContent=k.t;a.appendChild(i);a.appendChild(s);
 a.onclick=function(e){e.preventDefault();P({a:'ac',u:k.u})};iz.appendChild(a)});
var sl=document.getElementById('sl');
if(D.son.length)document.getElementById('sh').style.display='block';
D.son.forEach(function(k){var a=document.createElement('a');a.className='s';a.href='#';
 var im=document.createElement('img');im.src=fav(k.u);a.appendChild(im);
 var s=document.createElement('span');s.textContent=k.t||k.u;a.appendChild(s);
 a.onclick=function(e){e.preventDefault();P({a:'ac',u:k.u})};sl.appendChild(a)});
document.getElementById('f').onsubmit=function(e){e.preventDefault();var q=document.getElementById('q').value.trim();if(q)P({a:'git',q:q})};
document.getElementById('m').onclick=function(){P({a:'ses'})};
document.querySelectorAll('[data-a]').forEach(function(x){x.onclick=function(e){e.preventDefault();P({a:x.getAttribute('data-a')})}});
</script></body></html>"""
    }
}
