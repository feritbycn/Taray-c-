package com.turkuaz.tarayici

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.IBinder

/** Uygulama arka plandayken ses/video çalmaya devam ederken sistemin uygulamayı kapatmaması için. */
class MedyaServisi : Service() {
    companion object {
        const val KANAL = "medya"

        fun baslat(ctx: Context) {
            try { ctx.startForegroundService(Intent(ctx, MedyaServisi::class.java)) } catch (e: Exception) { }
        }

        fun durdur(ctx: Context) {
            try { ctx.stopService(Intent(ctx, MedyaServisi::class.java)) } catch (e: Exception) { }
        }
    }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        try {
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(NotificationChannel(KANAL, "Arka planda oynatma", NotificationManager.IMPORTANCE_LOW))
            val ac = PendingIntent.getActivity(
                this, 0,
                Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_NEW_TASK),
                PendingIntent.FLAG_IMMUTABLE
            )
            val n = Notification.Builder(this, KANAL)
                .setSmallIcon(R.drawable.ic_kulaklik)
                .setContentTitle("Turkuaz")
                .setContentText("Arka planda oynatılıyor · dokunarak aç")
                .setContentIntent(ac)
                .setOngoing(true)
                .build()
            startForeground(77, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
        } catch (e: Exception) {
            stopSelf()
        }
        return START_NOT_STICKY
    }
}
