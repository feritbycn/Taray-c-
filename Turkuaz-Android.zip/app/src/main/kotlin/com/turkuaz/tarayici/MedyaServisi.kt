package com.turkuaz.tarayici

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.drawable.Icon
import android.media.session.MediaSession
import android.media.session.PlaybackState
import android.os.IBinder

/**
 * Arka planda ses/video çalarken: uygulamayı canlı tutar, bildirim alanında (medya kartı)
 * başlık + oynat/duraklat/geri/ileri düğmelerini gösterir.
 */
class MedyaServisi : Service() {
    companion object {
        const val KANAL = "medya"
        const val ACT = "com.turkuaz.tarayici.MEDYA"

        fun baslat(ctx: Context, baslik: String = "", caliyor: Boolean = true) {
            try {
                ctx.startForegroundService(
                    Intent(ctx, MedyaServisi::class.java).putExtra("b", baslik).putExtra("c", caliyor)
                )
            } catch (e: Exception) { }
        }

        fun durdur(ctx: Context) {
            try { ctx.stopService(Intent(ctx, MedyaServisi::class.java)) } catch (e: Exception) { }
        }
    }

    private var oturum: MediaSession? = null

    override fun onBind(i: Intent?): IBinder? = null

    private fun komut(k: String): PendingIntent =
        PendingIntent.getBroadcast(
            this, k.hashCode(),
            Intent(ACT).setPackage(packageName).putExtra("k", k),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

    private fun gonder(k: String) {
        try { sendBroadcast(Intent(ACT).setPackage(packageName).putExtra("k", k)) } catch (e: Exception) { }
    }

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        try {
            val baslik = (i?.getStringExtra("b") ?: "").ifBlank { "Turkuaz" }
            val caliyor = i?.getBooleanExtra("c", true) ?: true
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(NotificationChannel(KANAL, "Arka planda oynatma", NotificationManager.IMPORTANCE_LOW))

            if (oturum == null) {
                val o = MediaSession(this, "Turkuaz")
                o.setCallback(object : MediaSession.Callback() {
                    override fun onPlay() { gonder("oynat") }
                    override fun onPause() { gonder("durdur") }
                    override fun onSkipToNext() { gonder("ileri") }
                    override fun onSkipToPrevious() { gonder("geri") }
                    override fun onFastForward() { gonder("ileri") }
                    override fun onRewind() { gonder("geri") }
                })
                o.isActive = true
                oturum = o
            }
            val o = oturum!!
            o.setMetadata(
                android.media.MediaMetadata.Builder()
                    .putString(android.media.MediaMetadata.METADATA_KEY_TITLE, baslik)
                    .putString(android.media.MediaMetadata.METADATA_KEY_ARTIST, "Turkuaz")
                    .build()
            )
            val eylemler = PlaybackState.ACTION_PLAY or PlaybackState.ACTION_PAUSE or PlaybackState.ACTION_PLAY_PAUSE or
                PlaybackState.ACTION_SKIP_TO_NEXT or PlaybackState.ACTION_SKIP_TO_PREVIOUS or
                PlaybackState.ACTION_FAST_FORWARD or PlaybackState.ACTION_REWIND
            o.setPlaybackState(
                PlaybackState.Builder()
                    .setActions(eylemler)
                    .setState(if (caliyor) PlaybackState.STATE_PLAYING else PlaybackState.STATE_PAUSED, PlaybackState.PLAYBACK_POSITION_UNKNOWN, if (caliyor) 1f else 0f)
                    .build()
            )

            val ac = PendingIntent.getActivity(
                this, 0,
                Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_NEW_TASK),
                PendingIntent.FLAG_IMMUTABLE
            )
            val b = Notification.Builder(this, KANAL)
                .setSmallIcon(R.drawable.ic_kulaklik)
                .setContentTitle(baslik)
                .setContentText(if (caliyor) "Oynatılıyor" else "Duraklatıldı")
                .setContentIntent(ac)
                .setOngoing(caliyor)
                .setVisibility(Notification.VISIBILITY_PUBLIC)
                .addAction(Notification.Action.Builder(Icon.createWithResource(this, R.drawable.ic_geri), "Geri", komut("geri")).build())
                .addAction(
                    Notification.Action.Builder(
                        Icon.createWithResource(this, if (caliyor) R.drawable.ic_durdur else R.drawable.ic_oynat),
                        if (caliyor) "Duraklat" else "Oynat",
                        komut(if (caliyor) "durdur" else "oynat")
                    ).build()
                )
                .addAction(Notification.Action.Builder(Icon.createWithResource(this, R.drawable.ic_ileri), "İleri", komut("ileri")).build())
                .setStyle(Notification.MediaStyle().setMediaSession(o.sessionToken).setShowActionsInCompactView(0, 1, 2))
            startForeground(77, b.build(), ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
        } catch (e: Exception) {
            stopSelf()
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        try { oturum?.release() } catch (e: Exception) { }
        oturum = null
        super.onDestroy()
    }
}
