package com.turkuaz.tarayici

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.view.View
import android.widget.RemoteViews
import android.widget.Toast
import java.io.File

/**
 * Ana ekran widget'ı: eklenti penceresinin son görüntüsünü gösterir.
 * Widget'a dokununca eklentinin açılır penceresi (canlı) açılır.
 */
class EklentiWidget : AppWidgetProvider() {
    override fun onUpdate(ctx: Context, am: AppWidgetManager, ids: IntArray) {
        for (id in ids) am.updateAppWidget(id, goruntule(ctx))
    }

    companion object {
        private const val DOSYA = "widget.png"

        fun anahtar(ctx: Context): String = ctx.getSharedPreferences("widget", 0).getString("key", "") ?: ""

        fun kaydet(ctx: Context, key: String, ad: String, bmp: Bitmap) {
            try {
                val oran = if (bmp.width > 540) 540f / bmp.width else 1f
                val k = if (oran < 1f) Bitmap.createScaledBitmap(bmp, 540, Math.max(1, (bmp.height * oran).toInt()), true) else bmp
                File(ctx.filesDir, DOSYA).outputStream().use { o -> k.compress(Bitmap.CompressFormat.PNG, 100, o) }
                ctx.getSharedPreferences("widget", 0).edit().putString("key", key).putString("ad", ad).apply()
                guncelle(ctx)
            } catch (e: Exception) {
            }
        }

        fun guncelle(ctx: Context) {
            try {
                val am = AppWidgetManager.getInstance(ctx)
                val ids = am.getAppWidgetIds(ComponentName(ctx, EklentiWidget::class.java))
                for (id in ids) am.updateAppWidget(id, goruntule(ctx))
            } catch (e: Exception) {
            }
        }

        /** Ana ekrana widget eklemek için sistem penceresini açar (destekleniyorsa). */
        fun ekle(ctx: Context) {
            try {
                val am = AppWidgetManager.getInstance(ctx)
                val ids = am.getAppWidgetIds(ComponentName(ctx, EklentiWidget::class.java))
                if (ids.isNotEmpty()) return
                if (am.isRequestPinAppWidgetSupported) {
                    am.requestPinAppWidget(ComponentName(ctx, EklentiWidget::class.java), null, null)
                } else {
                    Toast.makeText(ctx, "Ana ekrana basılı tutup Widget'lar > Turkuaz'ı seçin", Toast.LENGTH_LONG).show()
                }
            } catch (e: Exception) {
            }
        }

        private fun goruntule(ctx: Context): RemoteViews {
            val rv = RemoteViews(ctx.packageName, R.layout.widget_eklenti)
            val p = ctx.getSharedPreferences("widget", 0)
            val key = p.getString("key", "") ?: ""
            val f = File(ctx.filesDir, DOSYA)
            val bmp = if (f.exists()) BitmapFactory.decodeFile(f.path) else null
            if (bmp != null) {
                rv.setImageViewBitmap(R.id.w_img, bmp)
                rv.setViewVisibility(R.id.w_img, View.VISIBLE)
                rv.setViewVisibility(R.id.w_bos, View.GONE)
            } else {
                rv.setViewVisibility(R.id.w_img, View.GONE)
                rv.setViewVisibility(R.id.w_bos, View.VISIBLE)
            }
            rv.setTextViewText(R.id.w_ad, p.getString("ad", "Turkuaz eklentisi") ?: "Turkuaz eklentisi")
            val i = Intent(ctx, MainActivity::class.java)
            i.action = "com.turkuaz.tarayici.EKLENTI"
            i.putExtra("ek", key)
            val pi = PendingIntent.getActivity(ctx, 7, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            rv.setOnClickPendingIntent(R.id.w_kok, pi)
            return rv
        }
    }
}
