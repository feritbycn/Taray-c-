package com.turkuaz.tarayici

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.view.View
import android.widget.RemoteViews
import android.widget.Toast
import java.io.File

/**
 * Ana ekran widget'ı. Her widget ayrı bir eklentiye bağlanır; kaç eklenti varsa o kadar widget eklenebilir.
 * Widget eklentinin açılır penceresinin son görüntüsünü gösterir; dokununca eklenti (canlı) açılır.
 * Eklentiye bağlanmamış (listeden elle eklenmiş) widget'a dokununca eklenti seçtirilir.
 */
open class EklentiWidget : AppWidgetProvider() {
    /** Seçicide ayrı kart olarak görünen yuva numarası (0..7); -1: genel widget (eklenti sonradan seçilir). */
    open val sira: Int get() = -1

    override fun onUpdate(ctx: Context, am: AppWidgetManager, ids: IntArray) {
        for (id in ids) {
            baglaBekleyen(ctx, id)
            if (sira >= 0 && baglananKey(ctx, id).isEmpty()) {
                val l = listeAl(ctx)
                if (sira < l.size) prefs(ctx).edit().putString("b_$id", l[sira].first).apply()
            }
            am.updateAppWidget(id, goruntule(ctx, id))
        }
    }

    override fun onDeleted(ctx: Context, ids: IntArray) {
        val e = prefs(ctx).edit()
        for (id in ids) e.remove("b_$id")
        e.apply()
    }

    override fun onReceive(ctx: Context, intent: Intent) {
        if (intent.action == PIN_OK) {
            val id = intent.getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, 0)
            if (id > 0) {
                baglaBekleyen(ctx, id)
                try { AppWidgetManager.getInstance(ctx).updateAppWidget(id, goruntule(ctx, id)) } catch (e: Exception) { }
            }
            return
        }
        super.onReceive(ctx, intent)
    }

    companion object {
        const val YUVA = 8
        private val SINIFLAR = listOf<Class<*>>(Widget1::class.java, Widget2::class.java, Widget3::class.java, Widget4::class.java,
            Widget5::class.java, Widget6::class.java, Widget7::class.java, Widget8::class.java)

        /** Widget'ı olabilecek eklentiler (anahtar, ad): sunucudan atananlar + elle eklenenler. */
        fun listeAl(ctx: Context): List<Pair<String, String>> {
            val r = ArrayList<Pair<String, String>>()
            try {
                val a = org.json.JSONArray(ctx.getSharedPreferences("turkuaz", 0).getString("eklentiListe", "[]"))
                for (i in 0 until a.length()) {
                    val o = a.getJSONObject(i)
                    if (o.optJSONObject("bayraklar")?.optBoolean("gorunur", true) == false) continue
                    val k = o.optString("anahtar")
                    if (k.isNotEmpty() && r.none { it.first == k }) r.add(Pair(k, o.optString("ad", k)))
                }
            } catch (e: Exception) { }
            try {
                val a = org.json.JSONArray(prefs(ctx).getString("liste", "[]"))
                for (i in 0 until a.length()) {
                    val o = a.getJSONObject(i)
                    val k = o.optString("k")
                    if (k.isNotEmpty() && r.none { it.first == k }) r.add(Pair(k, o.optString("a", k)))
                }
            } catch (e: Exception) { }
            return r
        }

        /** Eklenti sayısı kadar widget kartı (yuva) seçicide görünür, fazlası gizlenir. */
        fun yuvalariAyarla(ctx: Context) {
            try {
                val n = Math.min(YUVA, listeAl(ctx).size)
                val pm = ctx.packageManager
                for (i in 0 until YUVA) {
                    val durum = if (i < n) android.content.pm.PackageManager.COMPONENT_ENABLED_STATE_ENABLED
                                else android.content.pm.PackageManager.COMPONENT_ENABLED_STATE_DISABLED
                    val c = ComponentName(ctx, SINIFLAR[i])
                    if (pm.getComponentEnabledSetting(c) != durum) pm.setComponentEnabledSetting(c, durum, android.content.pm.PackageManager.DONT_KILL_APP)
                }
            } catch (e: Exception) { }
        }

        private const val PIN_OK = "com.turkuaz.tarayici.WIDGET_PIN_OK"

        private fun prefs(ctx: Context) = ctx.getSharedPreferences("widget", 0)
        private fun dosya(ctx: Context, key: String) = File(ctx.filesDir, "w_" + Integer.toHexString(key.hashCode()) + ".png")

        private fun idler(ctx: Context): IntArray {
            val l = ArrayList<Int>()
            try {
                val am = AppWidgetManager.getInstance(ctx)
                val siniflar = ArrayList<Class<*>>(SINIFLAR); siniflar.add(EklentiWidget::class.java)
                for (c in siniflar) for (id in am.getAppWidgetIds(ComponentName(ctx, c))) l.add(id)
            } catch (e: Exception) { }
            return l.toIntArray()
        }

        fun baglananKey(ctx: Context, id: Int): String = prefs(ctx).getString("b_$id", "") ?: ""

        /** Ana ekranda en az bir widget'a bağlı olan eklenti anahtarları. */
        fun anahtarlar(ctx: Context): List<String> {
            val l = ArrayList<String>()
            for (id in idler(ctx)) {
                val k = baglananKey(ctx, id)
                if (k.isNotEmpty() && !l.contains(k)) l.add(k)
            }
            return l
        }

        fun bagliMi(ctx: Context, key: String): Boolean = anahtarlar(ctx).contains(key)

        private fun baglaBekleyen(ctx: Context, id: Int) {
            val p = prefs(ctx)
            if (baglananKey(ctx, id).isNotEmpty()) return
            val k = p.getString("bekleyen", "") ?: ""
            if (k.isEmpty()) return
            p.edit().putString("b_$id", k).remove("bekleyen").apply()
        }

        /** Eklentiye bağlanmamış bir widget'ı seçilen eklentiye bağlar. */
        fun bagla(ctx: Context, id: Int, key: String) {
            prefs(ctx).edit().putString("b_$id", key).apply()
            guncelle(ctx)
        }

        fun kaydet(ctx: Context, key: String, ad: String, bmp: Bitmap) {
            try {
                val oran = if (bmp.width > 540) 540f / bmp.width else 1f
                val k = if (oran < 1f) Bitmap.createScaledBitmap(bmp, 540, Math.max(1, (bmp.height * oran).toInt()), true) else bmp
                dosya(ctx, key).outputStream().use { o -> k.compress(Bitmap.CompressFormat.PNG, 100, o) }
                prefs(ctx).edit().putString("ad_$key", ad).apply()
                guncelle(ctx)
            } catch (e: Exception) {
            }
        }

        fun guncelle(ctx: Context) {
            try {
                val am = AppWidgetManager.getInstance(ctx)
                for (id in idler(ctx)) am.updateAppWidget(id, goruntule(ctx, id))
            } catch (e: Exception) {
            }
        }

        /** Bu eklenti için ana ekrana yeni bir widget eklemek üzere sistem penceresini açar. */
        fun ekle(ctx: Context, key: String) {
            try {
                val am = AppWidgetManager.getInstance(ctx)
                if (am.isRequestPinAppWidgetSupported) {
                    prefs(ctx).edit().putString("bekleyen", key).apply()
                    val pi = PendingIntent.getBroadcast(
                        ctx, 11, Intent(ctx, EklentiWidget::class.java).setAction(PIN_OK),
                        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_MUTABLE
                    )
                    val idx = listeAl(ctx).indexOfFirst { it.first == key }
                    val sinif: Class<*> = if (idx in 0 until YUVA) SINIFLAR[idx] else EklentiWidget::class.java
                    am.requestPinAppWidget(ComponentName(ctx, sinif), null, pi)
                } else {
                    Toast.makeText(ctx, "Ana ekrana basılı tutup Widget'lar > Turkuaz'ı seçin, sonra widget'a dokunup eklentiyi seçin", Toast.LENGTH_LONG).show()
                }
            } catch (e: Exception) {
            }
        }

        private fun goruntule(ctx: Context, id: Int): RemoteViews {
            val rv = RemoteViews(ctx.packageName, R.layout.widget_eklenti)
            val key = baglananKey(ctx, id)
            val i = Intent(ctx, MainActivity::class.java)
            i.action = "com.turkuaz.tarayici.EKLENTI"
            i.putExtra("ek", key)
            i.putExtra("wid", id)
            val pi = PendingIntent.getActivity(ctx, id, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            rv.setOnClickPendingIntent(R.id.w_kok, pi)
            if (key.isEmpty()) {
                rv.setViewVisibility(R.id.w_img, View.GONE)
                rv.setViewVisibility(R.id.w_bos, View.VISIBLE)
                rv.setTextViewText(R.id.w_bos, "Eklenti seçmek için dokunun")
                rv.setTextViewText(R.id.w_ad, "Turkuaz widget")
                return rv
            }
            val f = dosya(ctx, key)
            val bmp = if (f.exists()) BitmapFactory.decodeFile(f.path) else null
            if (bmp != null) {
                rv.setImageViewBitmap(R.id.w_img, bmp)
                rv.setViewVisibility(R.id.w_img, View.VISIBLE)
                rv.setViewVisibility(R.id.w_bos, View.GONE)
            } else {
                rv.setViewVisibility(R.id.w_img, View.GONE)
                rv.setViewVisibility(R.id.w_bos, View.VISIBLE)
                rv.setTextViewText(R.id.w_bos, "Görüntü hazırlanıyor, dokunup eklentiyi açın")
            }
            rv.setTextViewText(R.id.w_ad, prefs(ctx).getString("ad_$key", "Turkuaz eklentisi") ?: "Turkuaz eklentisi")
            return rv
        }
    }
}

class Widget1 : EklentiWidget() { override val sira: Int get() = 0 }
class Widget2 : EklentiWidget() { override val sira: Int get() = 1 }
class Widget3 : EklentiWidget() { override val sira: Int get() = 2 }
class Widget4 : EklentiWidget() { override val sira: Int get() = 3 }
class Widget5 : EklentiWidget() { override val sira: Int get() = 4 }
class Widget6 : EklentiWidget() { override val sira: Int get() = 5 }
class Widget7 : EklentiWidget() { override val sira: Int get() = 6 }
class Widget8 : EklentiWidget() { override val sira: Int get() = 7 }
