package com.turkuaz.tarayici

import java.text.SimpleDateFormat
import java.util.ArrayDeque
import java.util.Date
import java.util.Locale

/** Video / küçük pencere sorunlarını bulmak için basit tanılama kaydı. */
object Tani {
    private val fmt = SimpleDateFormat("HH:mm:ss.SSS", Locale.US)
    private val kayit = ArrayDeque<String>()
    @Volatile var acik = false

    @Synchronized fun log(s: String) {
        if (!acik) return
        kayit.addLast(fmt.format(Date()) + " " + s)
        while (kayit.size > 400) kayit.removeFirst()
    }

    @Synchronized fun hepsi(): String = kayit.joinToString("\n")

    @Synchronized fun temizle() { kayit.clear() }

    /** Sayfada çalışan ölçüm: video durumu, arabellek, düşen kare, zamanlayıcı sapması, olaylar. */
    const val PROBE_JS = """(function(){try{
var v=document.querySelector('video');
if(!window.__tzI){window.__tzI=1;window.__tzEv=[];var l=performance.now();setInterval(function(){var n=performance.now();window.__tzDrift=Math.round(n-l);l=n;},200);}
if(v&&!v.__tzL){v.__tzL=1;['waiting','stalled','suspend','error','pause','playing','seeking','seeked','emptied','ratechange','ended'].forEach(function(n){v.addEventListener(n,function(){window.__tzEv.push(n+'@'+v.currentTime.toFixed(1));if(window.__tzEv.length>30)window.__tzEv.shift();},true);});}
var o={vis:document.visibilityState,hid:document.hidden,iw:innerWidth,ih:innerHeight,dpr:devicePixelRatio,drift:window.__tzDrift||0,ev:(window.__tzEv||[]).splice(0)};
if(v){var q={};try{q=v.getVideoPlaybackQuality();}catch(e){}var b=v.buffered,ah=0;try{for(var i=0;i<b.length;i++){if(v.currentTime>=b.start(i)&&v.currentTime<=b.end(i)){ah=b.end(i)-v.currentTime;}}}catch(e){}
var r=v.getBoundingClientRect();
o.v={p:v.paused,rs:v.readyState,ns:v.networkState,t:+v.currentTime.toFixed(1),ah:+ah.toFixed(1),rate:v.playbackRate,m:v.muted,vw:v.videoWidth,vh:v.videoHeight,dr:q.droppedVideoFrames,tf:q.totalVideoFrames,rect:Math.round(r.left)+','+Math.round(r.top)+' '+Math.round(r.width)+'x'+Math.round(r.height),ad:!!document.querySelector('.ad-showing'),pip:document.documentElement.classList.contains('tzpip')};}
return JSON.stringify(o);}catch(e){return JSON.stringify({err:String(e)});}})()"""
}
