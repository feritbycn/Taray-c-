package com.turkuaz.tarayici

import java.text.SimpleDateFormat
import java.util.ArrayDeque
import java.util.Date
import java.util.Locale

/** Video / küçük pencere sorunlarını bulmak için basit tanılama kaydı. */
object Tani {
    private val fmt = SimpleDateFormat("HH:mm:ss.SSS", Locale.US)
    private val kayit = ArrayDeque<String>()
    @Volatile var acik = false

    @Synchronized fun log(s: String) {
        if (!acik) return
        kayit.addLast(fmt.format(Date()) + " " + s)
        while (kayit.size > 400) kayit.removeFirst()
    }

    // Sayfa konsol hataları (her zaman tutulur, küçük)
    private val konsol = ArrayDeque<String>()
    @Synchronized fun konsolEkle(s: String) { konsol.addLast(s); while (konsol.size > 40) konsol.removeFirst() }
    @Synchronized fun konsolHepsi(): String = konsol.joinToString("\n")
    @Synchronized fun konsolTemizle() { konsol.clear() }

    /** Sayfa açılırken çalışır: betik hatalarını toplar. */
    const val ERR_JS = """(function(){try{if(window.__tzErr)return;window.__tzErr=[];function a(s){if(window.__tzErr.length<40)window.__tzErr.push(String(s).slice(0,300));}window.addEventListener('error',function(e){var t=e.target;if(t&&t!==window&&(t.src||t.href)){a('YÜKLENEMEDİ '+t.tagName+' '+(t.src||t.href));}else{a('HATA '+e.message+' @'+(e.filename||'').split('/').pop()+':'+e.lineno+':'+e.colno);}},true);window.addEventListener('unhandledrejection',function(e){var r=e.reason;a('SÖZ '+(r&&r.message?r.message:r));});
var F=window.fetch;if(F){window.fetch=function(u,o){var url=(u&&u.url)||String(u);return F.apply(this,arguments).then(function(r){if(!r.ok)a('FETCH '+r.status+' '+url);return r;},function(er){a('FETCH BAŞARISIZ '+url+' '+er);throw er;});};}
var X=XMLHttpRequest.prototype.open;XMLHttpRequest.prototype.open=function(m,u){var self=this;this.addEventListener('loadend',function(){if(self.status===0||self.status>=400)a('XHR '+self.status+' '+u);});return X.apply(this,arguments);};}catch(x){}})();"""

    /** Sayfa hata raporu: ortam, betik hataları, üst çubuktaki öğeler ve gizli olanlar. */
    const val RAPOR_JS = """(function(){try{
var o={};o.url=location.href;o.ua=navigator.userAgent;o.iw=innerWidth;o.ih=innerHeight;o.dpr=devicePixelRatio;
o.vp=(document.querySelector('meta[name=viewport]')||{}).content||'yok';
o.ozellik={Notification:typeof Notification,perm:(typeof Notification!=='undefined'?Notification.permission:'-'),chrome:typeof window.chrome,sw:('serviceWorker' in navigator),push:typeof PushManager,clip:!!navigator.clipboard,uad:!!navigator.userAgentData,ls:(function(){try{localStorage.setItem('_t','1');localStorage.removeItem('_t');return true}catch(e){return String(e)}})(),ce:navigator.cookieEnabled};
o.hatalar=window.__tzErr||['(betik hatası kaydı yok - sayfa açılırken kayıt başlamamış olabilir)'];
function bilgi(e){var r=e.getBoundingClientRect(),c=getComputedStyle(e);var n=e.tagName.toLowerCase()+(e.id?'#'+e.id:'')+(e.className&&typeof e.className==='string'?'.'+e.className.trim().split(/\s+/).slice(0,3).join('.'):'');var t=(e.getAttribute('aria-label')||e.title||e.textContent||'').trim().slice(0,20);var g='';var p=e;while(p&&p!==document.documentElement){var cs=getComputedStyle(p);if(cs.display==='none'){g='GİZLİ(display:none) '+p.tagName.toLowerCase()+(p.id?'#'+p.id:'')+(p.className&&typeof p.className==='string'?'.'+p.className.trim().split(/\s+/).slice(0,2).join('.'):'');break;}if(cs.visibility==='hidden'){g='GİZLİ(visibility)';break;}p=p.parentElement;}return n+' ['+t+'] '+Math.round(r.left)+','+Math.round(r.top)+' '+Math.round(r.width)+'x'+Math.round(r.height)+' '+g;}
var ust=[];document.querySelectorAll('button,a,[role=button],[onclick]').forEach(function(e){var r=e.getBoundingClientRect();if(r.top<230&&r.top>-40&&ust.length<25)ust.push(bilgi(e));});
o.ustCubuk=ust;
var ara=[];document.querySelectorAll('[id*=menu i],[id*=theme i],[id*=tema i],[id*=bell i],[id*=notif i],[id*=bildirim i],[id*=toggle i],[class*=hamburger i],[class*=theme i],[class*=bell i],[class*=notif i]').forEach(function(e){if(ara.length<25)ara.push(bilgi(e));});
o.adaylar=ara;
var hd=document.querySelector('header,.header,.topbar,#header,[class*=header i]');o.header=hd?bilgi(hd)+' | alt:'+hd.children.length:'header bulunamadı';
try{window.scrollTo(0,0);var el=document.elementFromPoint(Math.min(180,innerWidth/2),40);while(el&&el.parentElement){var rr=el.getBoundingClientRect();if(rr.width>=innerWidth*0.9&&rr.height>=40&&rr.height<=140)break;el=el.parentElement;}o.ustHtml=el?el.outerHTML.replace(/\s+/g,' ').slice(0,3500):'bulunamadı';}catch(e){o.ustHtml='hata '+e;}
try{var kw=/mdi-bell|mdi-menu|weather-night|mdi-theme|hamburger|sidebar|menu-btn|menuBtn|temaDegis|toggleTheme|darkMode|dark-mode|bell/i;var bl=[],ba=[];
var all=Array.prototype.slice.call(document.scripts);
all.forEach(function(sc){var txt='',ad='';if(sc.src){ad=sc.src.replace(location.origin,'');if(sc.src.indexOf(location.origin)!==0){bl.push('DIŞ '+sc.src.slice(0,90));return;}try{var x=new XMLHttpRequest();x.open('GET',sc.src,false);x.send();txt=x.responseText||'';}catch(e){bl.push('OKUNAMADI '+ad);return;}}else{txt=sc.textContent||'';ad='(satır içi '+txt.length+' kr)';}
var m=txt.search(kw);bl.push(ad+' '+(m<0?'-':'EŞLEŞTİ'));if(m>=0&&ba.length<8){ba.push(ad+' => '+txt.slice(Math.max(0,m-120),m+160).replace(/\s+/g,' '));}});
o.betikler=bl;o.betikIcerik=ba;
o.domVar={bell:document.documentElement.outerHTML.search(/mdi-bell|fa-bell/i),menu:document.documentElement.outerHTML.search(/mdi-menu|fa-bars/i),ay:document.documentElement.outerHTML.search(/weather-night|fa-moon/i)};}catch(e){o.betikHata=String(e);}
o.stil=Array.prototype.slice.call(document.styleSheets).length+' stil dosyası, '+document.scripts.length+' betik';
return JSON.stringify(o,null,1);}catch(e){return 'RAPOR HATASI '+e;}})()"""

    @Synchronized fun hepsi(): String = kayit.joinToString("\n")

    @Synchronized fun temizle() { kayit.clear() }

    /** Sayfada çalışan ölçüm: video durumu, arabellek, düşen kare, zamanlayıcı sapması, olaylar. */
    const val PROBE_JS = """(function(){try{
var v=document.querySelector('video');
if(!window.__tzI){window.__tzI=1;window.__tzEv=[];var l=performance.now();setInterval(function(){var n=performance.now();window.__tzDrift=Math.round(n-l);l=n;},200);}
if(v&&!v.__tzL){v.__tzL=1;['waiting','stalled','suspend','error','pause','playing','seeking','seeked','emptied','ratechange','ended'].forEach(function(n){v.addEventListener(n,function(){window.__tzEv.push(n+'@'+v.currentTime.toFixed(1));if(window.__tzEv.length>30)window.__tzEv.shift();},true);});}
var o={vis:document.visibilityState,hid:document.hidden,iw:innerWidth,ih:innerHeight,dpr:devicePixelRatio,drift:window.__tzDrift||0,blk:window.__tzBlk||0,keep:!!window.__tzKeep,ev:(window.__tzEv||[]).splice(0)};
if(v){var q={};try{q=v.getVideoPlaybackQuality();}catch(e){}var b=v.buffered,ah=0;try{for(var i=0;i<b.length;i++){if(v.currentTime>=b.start(i)&&v.currentTime<=b.end(i)){ah=b.end(i)-v.currentTime;}}}catch(e){}
var r=v.getBoundingClientRect();
o.v={p:v.paused,rs:v.readyState,ns:v.networkState,t:+v.currentTime.toFixed(1),ah:+ah.toFixed(1),rate:v.playbackRate,m:v.muted,vw:v.videoWidth,vh:v.videoHeight,dr:q.droppedVideoFrames,tf:q.totalVideoFrames,rect:Math.round(r.left)+','+Math.round(r.top)+' '+Math.round(r.width)+'x'+Math.round(r.height),ad:!!document.querySelector('.ad-showing'),pip:document.documentElement.classList.contains('tzpip')};}
return JSON.stringify(o);}catch(e){return JSON.stringify({err:String(e)});}})()"""
}
