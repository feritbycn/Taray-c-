package com.turkuaz.tarayici

import android.app.Activity
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject

class NotesActivity : Activity() {
    private lateinit var st: Store
    private lateinit var pal: Pal
    private lateinit var list: LinearLayout
    private var notes = JSONArray()

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        st = Store(this)
        pal = MainActivity.paletteOf(this, st)
        window.statusBarColor = pal.bar
        notes = st.arr("notlar")

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(pal.page)
        root.setPadding(dp(16), dp(36), dp(16), dp(12))

        val head = TextView(this)
        head.text = "Notlarım"
        head.textSize = 22f
        head.setTextColor(pal.fg)
        root.addView(head)

        val ekle = Button(this)
        ekle.text = "+ Yeni not"
        ekle.setOnClickListener { duzenle(-1) }
        root.addView(ekle)

        val sv = ScrollView(this)
        list = LinearLayout(this)
        list.orientation = LinearLayout.VERTICAL
        sv.addView(list)
        root.addView(sv, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
        yenile()
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun yenile() {
        list.removeAllViews()
        if (notes.length() == 0) {
            val t = TextView(this)
            t.text = "Henüz not yok."
            t.setTextColor(pal.muted)
            t.setPadding(0, dp(16), 0, 0)
            list.addView(t)
        }
        for (i in 0 until notes.length()) {
            val n = notes.getJSONObject(i)
            val kart = LinearLayout(this)
            kart.orientation = LinearLayout.VERTICAL
            kart.setBackgroundColor(pal.field)
            kart.setPadding(dp(12), dp(10), dp(12), dp(10))
            val lp = LinearLayout.LayoutParams(-1, -2)
            lp.topMargin = dp(8)
            val bs = TextView(this)
            bs.text = n.optString("b", "").ifEmpty { "Başlıksız" }
            bs.textSize = 16f
            bs.setTextColor(pal.fg)
            val ic = TextView(this)
            ic.text = n.optString("m", "")
            ic.maxLines = 4
            ic.setTextColor(pal.muted)
            kart.addView(bs); kart.addView(ic)
            kart.setOnClickListener { duzenle(i) }
            list.addView(kart, lp)
        }
    }

    private fun duzenle(i: Int) {
        val mevcut: JSONObject? = if (i >= 0) notes.getJSONObject(i) else null
        val lay = LinearLayout(this)
        lay.orientation = LinearLayout.VERTICAL
        lay.setPadding(dp(16), dp(8), dp(16), 0)
        val b = EditText(this); b.hint = "Başlık"; b.setText(mevcut?.optString("b", "") ?: "")
        val m = EditText(this); m.hint = "Not"; m.minLines = 5; m.gravity = Gravity.TOP
        m.setText(mevcut?.optString("m", "") ?: "")
        lay.addView(b); lay.addView(m)
        val ad = android.app.AlertDialog.Builder(this)
            .setView(lay)
            .setPositiveButton("Kaydet") { _, _ ->
                val o = JSONObject()
                o.put("b", b.text.toString()); o.put("m", m.text.toString()); o.put("t", System.currentTimeMillis())
                val out = JSONArray()
                if (i < 0) { out.put(o); for (k in 0 until notes.length()) out.put(notes.get(k)) }
                else for (k in 0 until notes.length()) out.put(if (k == i) o else notes.get(k))
                notes = out
                st.putArr("notlar", notes)
                yenile()
            }
            .setNegativeButton("İptal", null)
        if (i >= 0) ad.setNeutralButton("Sil") { _, _ ->
            val out = JSONArray()
            for (k in 0 until notes.length()) if (k != i) out.put(notes.get(k))
            notes = out
            st.putArr("notlar", notes)
            yenile()
        }
        ad.show()
    }
}
