package com.turkuaz.tarayici

object Cfg {
    const val SITE = "https://turkuazads.com/vuslat"
    const val API = SITE + "/tarayici/api"
    const val INDIR = SITE + "/tarayici/indir/"
    const val SYNC_MS = 180000L

    const val UA_MOBIL =
        "Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Mobile Safari/537.36"
    const val UA_MASAUSTU =
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36"

    const val UA_FIREFOX =
        "Mozilla/5.0 (Android 13; Mobile; rv:126.0) Gecko/126.0 Firefox/126.0"

    // YouTube reklam temizleyici (sayfa açılmadan önce enjekte edilir)
    const val YT_JS = """
(function(){
  function strip(o){
    try{
      if(!o||typeof o!=='object')return o;
      if(o.adPlacements)o.adPlacements=[];
      if(o.playerAds)o.playerAds=false;
      if(o.adSlots)o.adSlots=[];
      if(o.playerResponse)strip(o.playerResponse);
      if(o.response)strip(o.response);
    }catch(e){}
    return o;
  }
  try{
    var P=JSON.parse;
    JSON.parse=function(t,r){return strip(P.call(this,t,r));};
  }catch(e){}
  try{
    var J=Response.prototype.json;
    Response.prototype.json=function(){return J.call(this).then(strip);};
  }catch(e){}
  try{
    var _v;
    Object.defineProperty(window,'ytInitialPlayerResponse',{
      get:function(){return _v;},
      set:function(v){_v=strip(v);},
      configurable:true
    });
  }catch(e){}
  function css(){
    var s=document.createElement('style');
    s.textContent='ytd-ad-slot-renderer,ytm-promoted-sparkles-web-renderer,ytm-promoted-video-renderer,ytm-companion-ad-renderer,ytd-promoted-sponsor-renderer,ytd-display-ad-renderer,ytd-in-feed-ad-layout-renderer,.ytp-ad-overlay-container,.ytp-ad-module,.ad-container,#player-ads,ytm-mealbar-promo-renderer,ytd-mealbar-promo-renderer,ytm-statement-banner-renderer,ytm-brand-video-singleton-renderer{display:none!important}';
    (document.head||document.documentElement).appendChild(s);
  }
  css();
  function atla(){
    try{
      var pl=document.querySelector('.html5-video-player');
      var v=document.querySelector('video');
      var ad=document.querySelector('.ad-showing,.ad-interrupting');
      if(ad&&v){
        v.muted=true;
        try{v.playbackRate=16;}catch(e){}
        if(isFinite(v.duration)&&v.duration>0){v.currentTime=v.duration;}
        if(pl)pl.style.visibility='hidden';
      }else if(pl&&pl.style.visibility==='hidden'){
        pl.style.visibility='';
        if(v){try{v.playbackRate=1;}catch(e){} v.muted=false;}
      }
      var b=document.querySelector('.ytp-ad-skip-button,.ytp-ad-skip-button-modern,.ytp-skip-ad-button,.ytp-ad-skip-button-container button');
      if(b)b.click();
    }catch(e){}
  }
  setInterval(atla,100);
  try{
    new MutationObserver(atla).observe(document.documentElement,{attributes:true,subtree:true,attributeFilter:['class']});
  }catch(e){}
})();
"""
}
