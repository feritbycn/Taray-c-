package com.turkuaz.tarayici

object Cfg {
    const val SITE = "https://turkuazads.com/vuslat"
    const val API = SITE + "/tarayici/api"
    const val INDIR = SITE + "/tarayici/indir/"
    const val SYNC_MS = 180000L

    const val UA_MOBIL =
        "Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Mobile Safari/537.36"
    const val UA_MASAUSTU =
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36"
}
