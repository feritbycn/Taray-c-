package com.turkuaz.tarayici

object Cfg {
    const val SITE = "https://turkuazads.com/vuslat"
    const val API = SITE + "/tarayici/api"
    const val INDIR = SITE + "/tarayici/indir/"
    const val SYNC_MS = 180000L

    // Gerçek WebView sürümünden türetilir (Cloudflare gibi doğrulamalar sürüm uyuşmazlığını reddeder)
    var UA_MOBIL =
        "Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Mobile Safari/537.36"
    var UA_MASAUSTU =
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36"

    fun uaKur(ctx: android.content.Context) {
        try {
            val d = android.webkit.WebSettings.getDefaultUserAgent(ctx)
            val m = Regex("Chrome/([0-9.]+)").find(d) ?: return
            UA_MOBIL = d.replace("; wv", "").replace(Regex("Version/[0-9.]+ "), "")
            UA_MASAUSTU = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/" + m.groupValues[1] + " Safari/537.36"
        } catch (e: Exception) { }
    }

    // Sayfalarda eksik olan window.chrome ve Notification nesnelerini ekler (WebView'de yoktur;
    // siteler bunları denetlemeden kullanınca betik hata verip menü düğmeleri hiç oluşmayabilir)
    // Masaüstü sitesi modunda sayfanın "mobil görünüm" (meta viewport) ayarını yok sayar
    const val MASA_JS = "(function(){try{if(/Android|Mobile/.test(navigator.userAgent))return;function f(){var m=document.querySelector('meta[name=viewport]');if(!m){m=document.createElement('meta');m.name='viewport';(document.head||document.documentElement).appendChild(m);}if(m.getAttribute('content')!=='width=1024')m.setAttribute('content','width=1024');}f();new MutationObserver(function(l){for(var i=0;i<l.length;i++){var a=l[i].addedNodes;for(var j=0;j<a.length;j++){if(a[j].nodeName==='META'||a[j].nodeName==='HEAD'){f();return;}}}}).observe(document,{childList:true,subtree:true});document.addEventListener('DOMContentLoaded',f);}catch(e){}})();"
    // VPN açıkken WebRTC ile gerçek IP sızmasın
    const val RTC_JS = "(function(){try{['RTCPeerConnection','webkitRTCPeerConnection','mozRTCPeerConnection'].forEach(function(k){try{Object.defineProperty(window,k,{value:undefined,configurable:true,writable:true});}catch(e){}});}catch(e){}})();"
    // Pencere içinde kaydırılabilir bir alana (ör. YouTube yorum paneli) dokunulursa "aşağı çekip yenile" kapanır
    const val SCROLL_JS = "(function(){function sc(e){var n=e;while(n&&n!==document.body&&n!==document.documentElement){if(n.nodeType===1){var cs=getComputedStyle(n);var oy=cs.overflowY;if((oy==='auto'||oy==='scroll'||oy==='overlay')&&n.scrollHeight>n.clientHeight+2)return true;}n=n.parentNode||n.host;}return false;}document.addEventListener('touchstart',function(e){var v=sc(e.target)?'1':'0';try{TzScroll.postMessage(v);}catch(x){}},{capture:true,passive:true});})();"
    // Hangi sekmede ses/video oynuyor (1v: video, 1a: ses, 0: yok)
    const val MEDYA_JS = "(function(){function p(e){var t=e.target;if(!t||!t.tagName)return;var g=t.tagName;if(g!=='VIDEO'&&g!=='AUDIO')return;var on=(e.type==='play'||e.type==='playing')&&!t.muted;try{TzMedia.postMessage(on?(g==='VIDEO'?'1v':'1a'):'0');}catch(x){}}['play','playing','pause','ended'].forEach(function(n){document.addEventListener(n,p,true);});})();"
    // Uygulama arka plana alınınca YouTube vb. sitelerin oynatmayı durdurmaması için sayfa hep "görünür" sayılır
    const val BG_JS = "(function(){try{[['hidden',false],['webkitHidden',false],['visibilityState','visible'],['webkitVisibilityState','visible']].forEach(function(a){try{Object.defineProperty(document,a[0],{get:function(){return a[1];},configurable:true});}catch(e){}});['visibilitychange','webkitvisibilitychange'].forEach(function(n){document.addEventListener(n,function(e){e.stopImmediatePropagation();},true);window.addEventListener(n,function(e){e.stopImmediatePropagation();},true);});['pagehide','freeze','blur'].forEach(function(n){window.addEventListener(n,function(e){e.stopImmediatePropagation();},true);});document.hasFocus=function(){return true;};}catch(e){}})();"
    // Küçük pencerede (PiP) videoyu tüm pencereye yay
    const val PIP_AC_JS = "(function(){var s=document.getElementById('__tzpip');if(!s){s=document.createElement('style');s.id='__tzpip';s.textContent='video{position:fixed!important;top:0!important;left:0!important;width:100vw!important;height:100vh!important;z-index:2147483647!important;object-fit:contain!important;background:#000!important}body{overflow:hidden!important}';document.documentElement.appendChild(s);}})();"
    const val PIP_KAPAT_JS = "(function(){var s=document.getElementById('__tzpip');if(s)s.remove();})();"
    const val CHROME_JS = "(function(){try{if(!window.chrome){window.chrome={app:{isInstalled:false},loadTimes:function(){return {};},csi:function(){return {};}};}}catch(e){}try{if(typeof window.Notification==='undefined'){var N=function(t,o){this.title=t;this.body=o&&o.body;};N.permission='default';N.maxActions=0;N.requestPermission=function(cb){var p=Promise.resolve('denied');if(typeof cb==='function'){cb('denied');}return p;};N.prototype.close=function(){};N.prototype.addEventListener=function(){};window.Notification=N;}}catch(e){}})();"

    const val UA_FIREFOX =
        "Mozilla/5.0 (Android 13; Mobile; rv:126.0) Gecko/126.0 Firefox/126.0"

    // YouTube reklam temizleyici (sayfa açılmadan önce enjekte edilir)
    const val YT_JS = """
(function(){
  function strip(o){
    try{
      if(!o||typeof o!=='object')return o;
      if(o.adPlacements)o.adPlacements=[];
      if(o.playerAds)o.playerAds=false;
      if(o.adSlots)o.adSlots=[];
      if(o.playerResponse)strip(o.playerResponse);
      if(o.response)strip(o.response);
    }catch(e){}
    return o;
  }
  try{
    var P=JSON.parse;
    JSON.parse=function(t,r){return strip(P.call(this,t,r));};
  }catch(e){}
  try{
    var J=Response.prototype.json;
    Response.prototype.json=function(){return J.call(this).then(strip);};
  }catch(e){}
  try{
    var _v;
    Object.defineProperty(window,'ytInitialPlayerResponse',{
      get:function(){return _v;},
      set:function(v){_v=strip(v);},
      configurable:true
    });
  }catch(e){}
  function css(){
    var s=document.createElement('style');
    s.textContent='ytd-ad-slot-renderer,ytm-promoted-sparkles-web-renderer,ytm-promoted-video-renderer,ytm-companion-ad-renderer,ytd-promoted-sponsor-renderer,ytd-display-ad-renderer,ytd-in-feed-ad-layout-renderer,.ytp-ad-overlay-container,.ytp-ad-module,.ad-container,#player-ads,ytm-mealbar-promo-renderer,ytd-mealbar-promo-renderer,ytm-statement-banner-renderer,ytm-brand-video-singleton-renderer{display:none!important}';
    (document.head||document.documentElement).appendChild(s);
  }
  css();
  function atla(){
    try{
      var pl=document.querySelector('.html5-video-player');
      var v=document.querySelector('video');
      var ad=document.querySelector('.ad-showing,.ad-interrupting');
      if(ad&&v){
        v.muted=true;
        try{v.playbackRate=16;}catch(e){}
        if(isFinite(v.duration)&&v.duration>0){v.currentTime=v.duration;}
        if(pl)pl.style.visibility='hidden';
      }else if(pl&&pl.style.visibility==='hidden'){
        pl.style.visibility='';
        if(v){try{v.playbackRate=1;}catch(e){} v.muted=false;}
      }
      var b=document.querySelector('.ytp-ad-skip-button,.ytp-ad-skip-button-modern,.ytp-skip-ad-button,.ytp-ad-skip-button-container button');
      if(b)b.click();
    }catch(e){}
  }
  setInterval(atla,100);
  try{
    new MutationObserver(atla).observe(document.documentElement,{attributes:true,subtree:true,attributeFilter:['class']});
  }catch(e){}
})();
"""
}
